ekart-template-springboot

What? 
Template Project for SpringBoot Maven based applications. 

Inclusions: 
1) Config Service
2) AuthN Integration
3) Logsvc
4) Deployment Kit
5) Jenkins Job Template


Change to be Done after creating project

1) Config Service
    Change BucketName in application.properties

2) AuthN Integration
    PutDown environment AuthN URL, PrivateKey File and ClientId in application.properties
3) Logsvc
4) Deployment Kit
    Added needed bundling and push to deb repo functions.
5) Jenkins Job Template
    Create a New Job by copying from https://jenkins-master-scp.nm.flipkart.com/job/ekart-template-springboot/

package com.ekart.template.service;

import com.ekart.template.core.response.HelloWorldResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Created by dinesh.rathore on 08/02/16.
 */

@Component
public interface HelloWorldService {

    public HelloWorldResponse getHelloMessage() throws Exception;
}
package com.ekart.template.impl;

import com.ekart.template.core.response.HelloWorldResponse;
import com.ekart.template.manager.GetHelloWorldManager;
import com.ekart.template.service.HelloWorldService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.stereotype.Service;

/**
 * Created by dinesh.rathore on 30/12/15.
 */
@Service
public class HelloWorldImpl implements HelloWorldService{
    private final Logger LOGGER = LoggerFactory.getLogger(HelloWorldImpl.class);

    @Autowired
    private GetHelloWorldManager getHelloWorldManager;

    public GetHelloWorldManager getGetHelloWorldManager() {
        return getHelloWorldManager;
    }

    public void setGetHelloWorldManager(GetHelloWorldManager getHelloWorldManager) {
        this.getHelloWorldManager = getHelloWorldManager;
    }

    public HelloWorldResponse getHelloMessage() throws Exception {
        LOGGER.info("Get HelloWorld Request");
        try {
            String helloWorld = getGetHelloWorldManager().getHelloWorld();
            HelloWorldResponse response = new HelloWorldResponse();
            response.setMessage(helloWorld);

            return response;

        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            throw e;
//            return Response.status(HttpStatus.INTERNAL_SERVER_ERROR.value())
//                    .entity(e.getMessage()).build();
        }
    }
}

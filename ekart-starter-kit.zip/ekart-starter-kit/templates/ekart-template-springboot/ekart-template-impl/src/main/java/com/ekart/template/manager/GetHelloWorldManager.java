package com.ekart.template.manager;

/**
 * Created by dinesh.rathore on 30/12/15.
 */
public interface GetHelloWorldManager {
    public String getHelloWorld();
}

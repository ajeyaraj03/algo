package com.ekart.template.manager.impl;


import com.ekart.template.core.ConfigService;
import com.ekart.template.manager.GetHelloWorldManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by dinesh.rathore on 30/12/15.
 */
@Service
public class GetHelloWorldManagerImpl implements GetHelloWorldManager {

    @Autowired
    private ConfigService configService;

    @Override
    public String getHelloWorld() {

        return configService.getProperty("test");
    }
}

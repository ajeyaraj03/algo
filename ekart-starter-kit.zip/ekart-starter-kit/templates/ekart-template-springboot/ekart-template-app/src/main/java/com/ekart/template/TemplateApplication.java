package com.ekart.template;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


/**
 * Created by dinesh.rathore on 08/02/16.
 */
@SpringBootApplication
public class TemplateApplication {

    public static void main(String[] args) throws Exception {
        SpringApplication.run(TemplateApplication.class, args);
    }


}
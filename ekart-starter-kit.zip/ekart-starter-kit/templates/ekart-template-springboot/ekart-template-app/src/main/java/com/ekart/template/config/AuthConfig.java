package com.ekart.template.config;

import com.flipkart.kloud.authn.filter.AuthnFilterBuilder;
import com.flipkart.kloud.authn.filter.PreAuthAuthenticationProvider;
import com.flipkart.kloud.authn.filter.PreAuthProcessingFilter;
import com.flipkart.kloud.filter.SecurityContextPersistenceFilter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.Http403ForbiddenEntryPoint;
import org.springframework.security.web.authentication.LoginUrlAuthenticationEntryPoint;
import org.springframework.security.web.authentication.logout.LogoutFilter;

import javax.servlet.Filter;

/**
* Created by dinesh.rathore on 08/02/16.
*/
@Configuration
public class AuthConfig extends WebSecurityConfigurerAdapter {
    @Value("${authn.authnUrl}")
    private String authnUrl;

    @Value("${authn.clientId}")
    private String clientId;

    @Value("${authn.privateKeyPath}")
    private String privateKeyPath;

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.authenticationProvider(new PreAuthAuthenticationProvider());
    }

    @Override
    public void configure(HttpSecurity http) throws Exception {

        http.authorizeRequests()
                .anyRequest()
                .authenticated()
                .and()
                .addFilterBefore(authnFilter(), SecurityContextPersistenceFilter.class)
                .addFilterAfter(preAuthFilter(), LogoutFilter.class)
                .exceptionHandling()
                .authenticationEntryPoint(new Http403ForbiddenEntryPoint());

    }

    private Filter preAuthFilter() throws Exception {
        PreAuthProcessingFilter filter = new PreAuthProcessingFilter();
        filter.setAuthenticationManager(authenticationManager());
        return filter;
    }

    private Filter authnFilter() {
        return new AuthnFilterBuilder()
                .setAuthnUrl(authnUrl)
                .setClientId(clientId)
                .setPrivateKeyPath(privateKeyPath)
                .enableSystemAuth()
                .enableUIAuth()
                .build();
    }
}
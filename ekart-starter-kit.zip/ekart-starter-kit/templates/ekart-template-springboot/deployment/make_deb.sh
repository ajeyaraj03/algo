#! /bin/sh -e

set -x
#JAVA_HOME needs to be set
#gem install buildr requires sudo and also JAVA_HOME

PACKAGE=ekart-template-app
PACKAGE_ROOT="./ekart-template-app"
DEPLOYMENT_DIR=deployment/deb/DEBIAN

if [ $VERSION_PREFIX ]; then
    VERSION=$GO_PIPELINE_LABEL
    VERSION=$VERSION_PREFIX.$VERSION #Also change the version in the control file
else
  VERSION='5.'$GO_PIPELINE_LABEL #Also change the version in the control file
fi

ARCH=all

JAVA_HOME=/usr/lib/jvm/java-7-oracle
export JAVA_HOME=$JAVA_HOME


if [ -z $JAVA_HOME ]; then
  echo "JAVA_HOME env variable is not set. For sun jdk it could be something like /usr/lib/jvm/java-7-oracle"
  exit 255
fi

if dpkg -l $COMPILE_DEPS; then

  mkdir -p $PACKAGE_ROOT
  mkdir -p $PACKAGE_ROOT/DEBIAN
  mkdir -p $PACKAGE_ROOT/var/log/flipkart/supply-chain/$PACKAGE
  mkdir -p $PACKAGE_ROOT/etc/$PACKAGE
  mkdir -p $PACKAGE_ROOT/etc/init.d
  mkdir -p $PACKAGE_ROOT/usr/share/$PACKAGE
  mkdir -p $PACKAGE_ROOT/var/lib/$PACKAGE

  perl -p -i -e "s/Version.*/Version: $VERSION/ig" $DEPLOYMENT_DIR/control

  cp $DEPLOYMENT_DIR/control $PACKAGE_ROOT/DEBIAN/control
  cp $DEPLOYMENT_DIR/postinst $PACKAGE_ROOT/DEBIAN/postinst
  cp $DEPLOYMENT_DIR/postrm $PACKAGE_ROOT/DEBIAN/postrm
  cp $DEPLOYMENT_DIR/preinst $PACKAGE_ROOT/DEBIAN/preinst
  cp $DEPLOYMENT_DIR/prerm $PACKAGE_ROOT/DEBIAN/prerm
  cp $DEPLOYMENT_DIR/service.sh $PACKAGE_ROOT/etc/init.d/$PACKAGE
  chmod -R 775 $PACKAGE_ROOT/etc/$PACKAGE/


  cp -r ekart-template-app/target/ekart-template-app-*.jar $PACKAGE_ROOT/var/lib/$PACKAGE/ekart-template-app.jar

  dpkg-deb -b $PACKAGE_ROOT
  echo "Moving the package to ${PACKAGE}_${VERSION}_${ARCH}"
  mv $PACKAGE_ROOT.deb ${PACKAGE}_${VERSION}_${ARCH}.deb
#  rm -rf ekl-ironthrone

else
  echo "Please run apt-get install $COMPILE_DEPS"
  exit -1
fi

BASE_DIR=.
FILE=${PACKAGE}_${VERSION}_${ARCH}.deb
TEMP_DIR=/tmp/apt-repo
DEPLOYMENT_ENV=$DEPLOYMENT_ENV
echo $FILE
echo $DEPLOYMENT_ENV

if [ $DEPLOYMENT_ENV = 'LOCAL' ]; then
HOSTS="flo-apt-repo.nm.flipkart.com"
elif [ $DEPLOYMENT_ENV = 'STAGING' ]; then
HOSTS="stage-build1.nm.flipkart.com stage-build1.ch.flipkart.com"
elif [ $DEPLOYMENT_ENV = 'PRODUCTION' ]; then
HOSTS="prod-build1.nm.flipkart.com"
else
echo "Unkown environment specified!"
exit 255;
fi

if [ -f $BASE_DIR/$FILE ];
then
# Create the tmp dir
mkdir -p $TEMP_DIR

# Copy the file to temp dir and generate md5
cp $BASE_DIR/$FILE $TEMP_DIR/
cd $TEMP_DIR
BASE_FILE_NAME=`basename $FILE`

# Create an md5 file in current dir
openssl md5 $BASE_FILE_NAME | cut -f 2 -d " " > $BASE_FILE_NAME.md5

#echo 'Upload starting for $FILE'
# Upload the file and md5

for HOST in $HOSTS
do
  echo "Uploading $FILE to $HOST"
ftp $HOST<<END_SCRIPT
  lcd $TEMP_DIR
  put $BASE_FILE_NAME
  put $BASE_FILE_NAME.md5
END_SCRIPT
  echo "Disconnected from ftp server - $HOST. Upload Complete for $FILE"
done


# Delete the md5 file and .deb file
#rm -f $TEMP_DIR/$BASE_FILE_NAME
#rm -f $TEMP_DIR/$BASE_FILE_NAME.md5
else
echo "File $BASE_DIR/$FILE does not exist."
exit 255 #error exit code.
fi
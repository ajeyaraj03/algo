#!/bin/bash

PACKAGE=__PACKAGE__
USERNAME=__PACKAGE_USER__
LOG_DIR=__LOG_DIR__
LOG_FILENAME=__LOG_FILENAME__
LOG_FILEPATH=__LOG_FILEPATH__
GC_LOG_FILEPATH=__GC_LOG_FILEPATH__
PACKAGE_LIB=/var/lib/$PACKAGE

start() {
	ulimit -n 10000

    sudo chown -R $USERNAME:$GROUPNAME $LOG_DIR
    sudo -u $USERNAME touch $LOG_FILEPATH

    cd $PACKAGE_LIB
    sudo -u $USERNAME java 	-jar -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -Xloggc:$GC_LOG_FILEPATH -Dcom.sun.management.jmxremote -Dcom.sun.management.jmxremote.port=27746 -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false -Xms1024m -Xmx2048m -XX:MaxPermSize=512M -XX:ReservedCodeCacheSize=128m -Xss512k -XX:NewRatio=2 -XX:+UseConcMarkSweepGC -XX:SurvivorRatio=4 -XX:CompileThreshold=100 -cp /etc/$PACKAGE/:$PACKAGE_LIB/$PACKAGE.jar:$PACKAGE_LIB/lib/*:/usr/lib/jvm/j2sdk1.7-oracle/lib/*:.  > $LOG_FILEPATH &
}

stop() {
	pkill -9 -f "org.minnal.Bootstrap"
}

case "$1" in
  start)
    start
  ;;
  stop|force_kill)
    stop
  ;;
  restart)
  	stop
  	start
  ;;
  *)
    echo "USAGE: $0 start|stop|restart"
    exit 3
  ;;
esac
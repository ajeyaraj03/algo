package com.ekart.template.core.util;

import com.flipkart.restbus.MqClient;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;

/**
 * Created by dinesh.rathore on 04/01/16.
 */
public class RestbusUtil {
    public static void pushToOutboundMessage(String requestType, Connection connection, String url, String payload, String groupId, Map<String, String> options, String exchangeName, String exchangeType) throws SQLException {
       MqClient mqClient = new MqClient(connection, exchangeName, exchangeType, options);
       mqClient.sendMessage(requestType, url, payload, groupId, options);
    }
}

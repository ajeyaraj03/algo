package com.ekart.template.core;

import com.flipkart.kloud.config.ConfigClient;
import com.flipkart.kloud.config.DynamicBucket;
import com.flipkart.kloud.config.error.ConfigServiceException;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.util.List;

/**
 * Created by dinesh.rathore on 08/02/16.
 */
@Service
public class ConfigService {

    private static Logger logger = Logger.getLogger(ConfigService.class);
    private static ConfigService conf = new ConfigService();
    private static DynamicBucket bucket = null;

    @Autowired
    private Environment environment;


    @PostConstruct
    public void init() {
        String configServiceHost = environment.getProperty("CONFIG_SERVICE_HOST");
        int configServicePort = Integer.parseInt(environment.getProperty("CONFIG_SERVICE_PORT"));
        int configServiceApiVersion = Integer.parseInt(environment.getProperty("CONFIG_SERVICE_API_VERSION"));
        int configServiceConnectionTimeout = Integer.parseInt(environment.getProperty("CONFIG_SERVICE_CONNECTION_TIMEOUT"));

        try {
            // Create the client instance
            ConfigClient client = new ConfigClient(configServiceHost, configServicePort, configServiceApiVersion, configServiceConnectionTimeout);

            // Instance of dynamic bucket object which will be auto-updated.
            String bucketName = environment.getProperty("BUCKET_NAME");

            bucket = client.getDynamicBucket(bucketName);
            logger.info(bucket.toString());
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage());
        } catch (ConfigServiceException e) {
            throw new RuntimeException(e.getMessage());
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }

    }

    public static ConfigService getInstance() {
        return conf;
    }

    public String getProperty(String key) {
        return bucket.getString(key);
    }

    public List<String> getListProperty(String key){
        return bucket.getStringArray(key);
    }

}

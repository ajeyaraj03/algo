package com.ekart.template.core.util.impl;


/**
 * Created by dinesh.rathore on 04/01/16.
 */
public class JsonUtil {

    public static String serializeJson(Object messageBody) {
        return null;
    }
}

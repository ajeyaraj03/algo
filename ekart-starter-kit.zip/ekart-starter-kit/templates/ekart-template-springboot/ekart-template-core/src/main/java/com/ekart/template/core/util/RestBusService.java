package com.ekart.template.core.util;

import java.sql.Connection;

/**
 * Created by dinesh.rathore on 04/01/16.
 */
public interface RestBusService {

    public void queueMessage(Connection connection, String httpUri, String httpMethod, String exchangeName, String groupId, Object messageBody) throws Exception;

    public void publishTopic(Connection connections, String topicName, Object messageBody) throws Exception;
}

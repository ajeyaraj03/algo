package com.ekart.template.core.util.impl;

import com.ekart.template.core.util.RestBusService;
import com.ekart.template.core.util.RestbusUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;

/**
 * Created by dinesh.rathore on 04/01/16.
 */
public class RestbusServiceImpl implements RestBusService {

    private static final Logger logger = LoggerFactory.getLogger(RestbusServiceImpl.class);


    @Override
    public void queueMessage(final Connection connection, final String httpUri, final String httpMethod, final String exchangeName, final String groupId, Object messageBody) throws Exception {
        final String payload = JsonUtil.serializeJson(messageBody);
            logger.info("Going to queue message {}", payload);
            try {
                RestbusUtil.pushToOutboundMessage(httpMethod, connection, httpUri, payload, groupId, (new HashMap<String, String>()), exchangeName, "queue");
            } catch (SQLException e) {
                logger.error("Error in pushing outbound message ", e);
            }

    }

    @Override
    public void publishTopic(final Connection connection, final String topicName, Object messageBody) throws Exception {
        final String payload = JsonUtil.serializeJson(messageBody);
            logger.info("Going to queue topic {}", payload);
            try {
                RestbusUtil.pushToOutboundMessage(null, connection, null, payload, null, (new HashMap<String, String>()), topicName, "topic");
            } catch (SQLException e) {
                logger.error("Error in pushing outbound message ", e);
            }

    }
}

package com.ekart.template.core.response;

import java.io.Serializable;

/**
 * Created by dinesh.rathore on 30/12/15.
 */
public class HelloWorldResponse implements Serializable {

    private String message;


    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}

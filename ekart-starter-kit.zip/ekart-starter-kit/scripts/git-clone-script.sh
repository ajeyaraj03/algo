dir=$1
gitUrl=$2

echo $dir

cd $dir

echo "next:Cloning project"
git clone $gitUrl;
project_path=$1

echo $project_path

cd $project_path

echo "next:Adding all new changes"
git add -A

echo "next:Commiting.. "
git commit -m "Created Project Structure through EKL Starter Kit"

echo "next:Pushing.."
git push
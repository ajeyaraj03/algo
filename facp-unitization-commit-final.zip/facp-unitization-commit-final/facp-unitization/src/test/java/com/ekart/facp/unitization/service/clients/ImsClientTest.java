package com.ekart.facp.unitization.service.clients;

import com.ekart.facp.unitization.apis.dtos.ErrorMessage;
import com.ekart.facp.unitization.apis.mapper.ServiceEntityToClientRequestMapper;
import com.ekart.facp.unitization.service.dtos.*;
import com.ekart.facp.unitization.service.dtos.clients.ims.request.*;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.GetItemResponse;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.Item;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.ItemCreationResponse;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.ItemsCreationResponse;
import com.ekart.facp.unitization.service.exceptions.clients.ims.ImsBadRequestException;
import com.ekart.facp.unitization.service.exceptions.clients.ims.ImsClientException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

import static com.ekart.facp.unitization.apis.constants.ApiConstants.DELETED_VALUE;
import static com.ekart.facp.unitization.apis.constants.ApiConstants.MODIFIED_VALUE;
import static com.ekart.facp.unitization.common.ErrorCode.UNKNOWN_ERROR;
import static com.ekart.facp.unitization.service.utility.TestUtils.newHeader;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.mockito.Mockito.when;
import static org.springframework.http.HttpStatus.*;
import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

/**
 * Created by anurag.gupta on 06/06/16.
 */
@RunWith(MockitoJUnitRunner.class)
public class ImsClientTest {

    private final String baseUrl = "baseUrl";

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private ServiceEntityToClientRequestMapper mapper;

    @Mock
    private HttpHeaders header;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private ItemToUpdate mockItemToUpdate;

    @Mock
    private ItemAddRequest mockItemAddRequest;

    @Mock
    private ItemUpdateRequest mockItemUpdateRequest;

    @Mock
    private ItemMoveRequest mockItemMoveRequest;

    private ImsClient imsClient;
    private static final String STATUS = "STATUS";
    private static final String PROCESS_OWNER = "PROCESS_OWNER";
    private static final String APP_ID = "UNITIZATION_APP_ID";
    private static final String FACILITY_ID = "FACILITY_ID";
    private static final boolean IS_TRANSIENT = true;
    private static final String ATTRIBUTE_NAME = "ATTRIBUTE_NAME";
    private static final String ATTRIBUTE_VALUE = "ATTRIBUTE_VALUE";
    private static final String CONTAINER_ID = "CONTAINER_ID";
    private static final String LABEL_NAME = "LABEL_NAME";
    private static final String LABEL_VALUE = "LABEL_VALUE";
    private static final String LABEL_TYPE = "labelType";
    private static final String LABEL_VALUES_STRING = "LABEL_VALUES_STRING";
    private String createItemUrl;
    private String updateItemUrl;
    private String getItemByLabelsUrl;
    private String getItemByIdsUrl;
    private ItemLabel itemLabel;
    private ItemAttribute itemAttribute;
    private Container createItem;
    private UpdateRequest updateRequest;
    private AddRequest addRequest;
    private ItemCreationRequest itemCreationRequest;
    private ItemCreationRequestAttributes itemCreationAttributes;

    @Before
    public void setUp() throws Exception {
        imsClient = new ImsClient(restTemplate, baseUrl, mapper, objectMapper);
        createItemUrl = "http://" + baseUrl + "/api/v1/{rootContainerId}/item";
        updateItemUrl = "http://" + baseUrl + "/api/v1/{rootContainerId}/item";
        getItemByIdsUrl = "http://" + baseUrl + "/api/v1/{rootContainerId}/item/{itemIds}";
        getItemByLabelsUrl =
                "http://" + baseUrl + "/api/v1/{rootContainerId}/item/labels/{labelValue}?labelType={labelType}";
        createItem = new Container();
        itemLabel = new ItemLabel();
        itemCreationRequest = new ItemCreationRequest();
        itemLabel.setType(LABEL_NAME);
        itemLabel.setValue(LABEL_VALUE);
        itemLabel.setType(LABEL_NAME);
        itemLabel.setValue(LABEL_VALUE);
        itemAttribute = new ItemAttribute(ATTRIBUTE_NAME, ATTRIBUTE_VALUE);
        createItem.setAttributes(Lists.newArrayList());
        createItem.setAppId(APP_ID);
        createItem.setLabel(itemLabel);
        createItem.setTransient(IS_TRANSIENT);
        createItem.setFacilityId(FACILITY_ID);
        itemCreationAttributes = new ItemCreationRequestAttributes();
        itemCreationAttributes.setAttributes(Lists.newArrayList(itemAttribute));
        updateRequest = new UpdateRequest();
        addRequest = new AddRequest();
    }

    @Test(expected = NullPointerException.class)
    public void shouldRaiseExceptionIfRestTemplateIsNull() {
        new ImsClient(null, baseUrl, mapper, objectMapper);
    }

    @Test(expected = NullPointerException.class)
    public void shouldRaiseExceptionIfBaseUrlIsNull() {
        new ImsClient(restTemplate, null, mapper, objectMapper);
    }

    @Test(expected = NullPointerException.class)
    public void shouldRaiseExceptionIfMapperIsNull() {
        new ImsClient(restTemplate, baseUrl, null, objectMapper);
    }

    @Test
    public void shouldCreateItemWhenCreateItemIsInvoked() throws IOException {
        int itemVersion = 1;
        int oldItemVersion = 0;
        ItemCreationResponse itemCreationResponse = new ItemCreationResponse(CONTAINER_ID, itemVersion, oldItemVersion);
        ItemsCreationResponse itemsCreationResponse = new ItemsCreationResponse(
                Lists.newArrayList(itemCreationResponse), Lists.newArrayList());
        ResponseEntity<String> response = new ResponseEntity<>(itemsCreationResponse.toString(), HttpStatus.CREATED);

        when(mapper.unitizationToItemCreationRequest(createItem)).thenReturn(itemCreationRequest);
        when(mapper.unitizationToItemCreationRequestAttributes(createItem)).thenReturn(itemCreationAttributes);
        when(restTemplate.exchange(Mockito.eq(createItemUrl), Mockito.eq(HttpMethod.POST),
                Mockito.<HttpEntity<ItemCreationRequest>>any(), Mockito.eq(String.class),
                Mockito.eq(FACILITY_ID))).thenReturn((ResponseEntity)response);
        when(objectMapper.readValue(Mockito.anyString(), Mockito.eq(ItemsCreationResponse.class)))
                .thenReturn(itemsCreationResponse);

        assertThat(imsClient.createItem(STATUS, PROCESS_OWNER, createItem), is(CONTAINER_ID));
    }

    @Test(expected = ImsBadRequestException.class)
    public void shouldThrowImsBadRequestExceptionWhenCreateItemIsInvoked() throws IOException {
        ErrorMessage badRequestResponse = new ErrorMessage("mockMessage", UNKNOWN_ERROR.name());
        ResponseEntity<String> response = new ResponseEntity<>(badRequestResponse.toString(), BAD_REQUEST);

        when(mapper.unitizationToItemCreationRequest(createItem)).thenReturn(itemCreationRequest);
        when(mapper.unitizationToItemCreationRequestAttributes(createItem)).thenReturn(itemCreationAttributes);
        when(restTemplate.exchange(Mockito.eq(createItemUrl), Mockito.eq(HttpMethod.POST),
                Mockito.<HttpEntity<ItemCreationRequest>>any(), Mockito.eq(String.class),
                Mockito.eq(FACILITY_ID))).thenReturn((ResponseEntity)response);
        when(objectMapper.readValue(Mockito.anyString(), Mockito.eq(ErrorMessage.class))).
                thenReturn(badRequestResponse);

        imsClient.createItem(STATUS, PROCESS_OWNER, createItem);
    }

    @Test(expected = ImsClientException.class)
    public void shouldThrowImsClientExceptionWhenCreateItemIsInvoked() throws IOException {
        ErrorMessage badRequestResponse = new ErrorMessage("mockMessage", UNKNOWN_ERROR.name());
        ResponseEntity<String> response = new ResponseEntity<>(badRequestResponse.toString(), INTERNAL_SERVER_ERROR);

        when(mapper.unitizationToItemCreationRequest(createItem)).thenReturn(itemCreationRequest);
        when(mapper.unitizationToItemCreationRequestAttributes(createItem)).thenReturn(itemCreationAttributes);
        when(restTemplate.exchange(Mockito.eq(createItemUrl), Mockito.eq(HttpMethod.POST),
                Mockito.<HttpEntity<ItemCreationRequest>>any(), Mockito.eq(String.class),
                Mockito.eq(FACILITY_ID))).thenReturn((ResponseEntity)response);
        when(objectMapper.readValue(Mockito.anyString(), Mockito.eq(ErrorMessage.class))).
                thenReturn(badRequestResponse);

        imsClient.createItem(STATUS, PROCESS_OWNER, createItem);
    }

    @Test
    public void shouldPrepareContainerToUpdateAttributes() {
        ItemAddRequest itemAddRequest = new ItemAddRequest(CONTAINER_ID, 1L, ImmutableMap.of(MODIFIED_VALUE,
                Lists.newArrayList(new ItemAttribute("attributeKey", "attributeValue"))), ImmutableMap.of());
        Item container = new Item(CONTAINER_ID, null, null, null, null, null, null, null, null, null, null, null, null,
                null, 1L, 1, 1);
        assertReflectionEquals(itemAddRequest, imsClient.prepareContainerToUpdate(container,
                ImmutableMap.of("attributeKey", "attributeValue"), ImmutableMap.of(), ImmutableMap.of()));
    }

    @Test
    public void shouldPrepareContainerToDeleteAttributes() {
        ItemAddRequest itemAddRequest = new ItemAddRequest(CONTAINER_ID, 1L, ImmutableMap.of(DELETED_VALUE,
                Lists.newArrayList(new ItemAttribute("attributeKey", "attributeValue"))), ImmutableMap.of());
        Item container = new Item(CONTAINER_ID, null, null, null, null, null, null, null, null, null, null, null, null,
                null, 1L, 1, 1);
        assertReflectionEquals(itemAddRequest, imsClient.prepareContainerToUpdate(container,
                ImmutableMap.of(), ImmutableMap.of("attributeKey", "attributeValue"), ImmutableMap.of()));
    }

    @Test
    public void shouldPrepareItemToUpdateAttributes() {
        ItemToUpdate itemToUpdate = new ItemToUpdate(CONTAINER_ID, 1L,
                ImmutableMap.of(MODIFIED_VALUE, Lists.newArrayList(new ItemAttribute("attributeKey",
                        "attributeValue"))),
                ImmutableMap.of(), ImmutableMap.of());
        Item item = new Item(CONTAINER_ID, null, null, null, null, null, null, null, null, null, null, null, null,
                null, 1L, 1, 1);
        assertReflectionEquals(itemToUpdate, imsClient.prepareItemToUpdate(item,
                ImmutableMap.of("attributeKey", "attributeValue"), ImmutableMap.of(), ImmutableMap.of()));
    }

    @Test
    public void shouldPrepareItemToAddLabels() {
        ItemToUpdate itemToUpdate = new ItemToUpdate(CONTAINER_ID, 1L, ImmutableMap.of(),
                ImmutableMap.of(MODIFIED_VALUE, Lists.newArrayList(new ItemLabel("attributeKey", "attributeValue"))),
                ImmutableMap.of());
        Item item = new Item(CONTAINER_ID, null, null, null, null, null, null, null, null, null, null, null, null,
                null, 1L, 1, 1);
        assertReflectionEquals(itemToUpdate, imsClient.prepareItemToUpdate(item,
                ImmutableMap.of(), ImmutableMap.of("attributeKey", "attributeValue"), ImmutableMap.of()));
    }

    @Test
    public void shouldPrepareItemToAddStatuses() {
        ItemToUpdate itemToUpdate = new ItemToUpdate(CONTAINER_ID, 1L, ImmutableMap.of(), ImmutableMap.of(),
                ImmutableMap.of(MODIFIED_VALUE, Lists.newArrayList(new ItemStatus("attributeKey", "attributeValue"))));
        Item item = new Item(CONTAINER_ID, null, null, null, null, null, null, null, null, null, null, null, null,
                null, 1L, 1, 1);
        assertReflectionEquals(itemToUpdate, imsClient.prepareItemToUpdate(item,
                ImmutableMap.of(), ImmutableMap.of(), ImmutableMap.of("attributeKey", "attributeValue")));
    }

    @Test
    public void shouldPrepareItemsToMoveAndUpdateItemAttributes() {
        ItemAddRequest itemAddRequest = new ItemAddRequest("id", 1L, CONTAINER_ID, 1L, ImmutableMap.of(MODIFIED_VALUE,
                Lists.newArrayList(new ItemAttribute("attributeKey", "attributeValue"))),
                ImmutableMap.of(MODIFIED_VALUE, Lists.newArrayList(new ItemStatus("owner", "value"))));
        Item container = new Item(CONTAINER_ID, null, null, null, null, null, null, null, null, null, null, null, null,
                null, 1L, 1, 1);
        Item item = new Item("id", null, null, null, null, null, null, null, null, null, null, null, null,
                null, 1L, 1, 1);
        assertReflectionEquals(itemAddRequest, imsClient.prepareItemsToMove(Lists.newArrayList(item), container,
                ImmutableMap.of("attributeKey", "attributeValue"), ImmutableMap.of(),
                ImmutableMap.of("id", new com.ekart.facp.unitization.service.dtos.clients.ims.response.ItemStatus(
                        "owner", "value"))).get(0));
    }

    @Test
    public void shouldPrepareItemsToMoveAndDeleteItemAttributes() {
        ItemAddRequest itemAddRequest = new ItemAddRequest("id", 1L, CONTAINER_ID, 1L, ImmutableMap.of(DELETED_VALUE,
                Lists.newArrayList(new ItemAttribute("attributeKey", "attributeValue"))),
                ImmutableMap.of(MODIFIED_VALUE, Lists.newArrayList(new ItemStatus("owner", "value"))));
        Item container = new Item(CONTAINER_ID, null, null, null, null, null, null, null, null, null, null, null, null,
                null, 1L, 1, 1);
        Item item = new Item("id", null, null, null, null, null, null, null, null, null, null, null, null,
                null, 1L, 1, 1);
        assertReflectionEquals(itemAddRequest, imsClient.prepareItemsToMove(Lists.newArrayList(item), container,
                ImmutableMap.of(), ImmutableMap.of("attributeKey", "attributeValue"),
                ImmutableMap.of("id", new com.ekart.facp.unitization.service.dtos.clients.ims.response.ItemStatus(
                        "owner", "value"))).get(0));
    }

    @Test
    public void shouldMoveItemsWhenMoveItemIsInvoked() throws IOException {
        ResponseEntity<String> response = new ResponseEntity<>("response", OK);
        addRequest.setFacilityId(FACILITY_ID);
        when(mapper.unitizationMoveRequestToItemMoveRequest(addRequest, Lists.newArrayList(mockItemAddRequest)))
                .thenReturn(mockItemMoveRequest);
        when(restTemplate.exchange(updateItemUrl, HttpMethod.PUT, new HttpEntity<>(mockItemMoveRequest, newHeader()),
                String.class, FACILITY_ID)).thenReturn(response);

        imsClient.moveItems(addRequest, Lists.newArrayList(mockItemAddRequest));
    }

    @Test(expected = ImsBadRequestException.class)
    public void shouldThrowImsBadRequestExceptionWhenMoveItemsIsInvoked() throws IOException {
        ErrorMessage badRequestResponse = new ErrorMessage("mockMessage", UNKNOWN_ERROR.name());
        ResponseEntity<String> response = new ResponseEntity<>(badRequestResponse.toString(), BAD_REQUEST);
        addRequest.setFacilityId(FACILITY_ID);
        when(mapper.unitizationMoveRequestToItemMoveRequest(addRequest, Lists.newArrayList(mockItemAddRequest)))
                .thenReturn(mockItemMoveRequest);
        when(restTemplate.exchange(updateItemUrl, HttpMethod.PUT, new HttpEntity<>(mockItemMoveRequest, newHeader()),
                String.class, FACILITY_ID)).thenReturn(response);
        when(objectMapper.readValue(response.getBody(), ErrorMessage.class)).
                thenReturn(badRequestResponse);

        imsClient.moveItems(addRequest, Lists.newArrayList(mockItemAddRequest));
    }

    @Test(expected = ImsClientException.class)
    public void shouldThrowImsClientExceptionWhenMoveItemsIsInvoked() throws IOException {
        ErrorMessage badRequestResponse = new ErrorMessage("mockMessage", UNKNOWN_ERROR.name());
        ResponseEntity<String> response = new ResponseEntity<>(badRequestResponse.toString(), INTERNAL_SERVER_ERROR);
        addRequest.setFacilityId(FACILITY_ID);
        when(mapper.unitizationMoveRequestToItemMoveRequest(addRequest, Lists.newArrayList(mockItemAddRequest)))
                .thenReturn(mockItemMoveRequest);
        when(restTemplate.exchange(updateItemUrl, HttpMethod.PUT, new HttpEntity<>(mockItemMoveRequest, newHeader()),
                String.class, FACILITY_ID)).thenReturn(response);
        when(objectMapper.readValue(response.getBody(), ErrorMessage.class)).thenReturn(badRequestResponse);

        imsClient.moveItems(addRequest, Lists.newArrayList(mockItemAddRequest));
    }

    @Test
    public void shouldUpdateItemWhenUpdateItemIsInvoked() throws IOException {
        ResponseEntity<String> response = new ResponseEntity<>("response", OK);
        updateRequest.setFacilityId(FACILITY_ID);
        when(mapper.unitizationUpdateRequestToItemUpdateRequest(updateRequest, Lists.newArrayList(mockItemToUpdate)))
                .thenReturn(mockItemUpdateRequest);
        when(restTemplate.exchange(updateItemUrl, HttpMethod.PUT, new HttpEntity<>(mockItemUpdateRequest, newHeader()),
                String.class, FACILITY_ID)).thenReturn(response);

        imsClient.updateItem(updateRequest, Lists.newArrayList(mockItemToUpdate));
    }

    @Test(expected = ImsBadRequestException.class)
    public void shouldThrowImsBadRequestExceptionWhenUpdateItemIsInvoked() throws IOException {
        ErrorMessage badRequestResponse = new ErrorMessage("mockMessage", UNKNOWN_ERROR.name());
        ResponseEntity<String> response = new ResponseEntity<>(badRequestResponse.toString(), BAD_REQUEST);
        updateRequest.setFacilityId(FACILITY_ID);
        when(mapper.unitizationUpdateRequestToItemUpdateRequest(updateRequest, Lists.newArrayList(mockItemToUpdate)))
                .thenReturn(mockItemUpdateRequest);
        when(restTemplate.exchange(updateItemUrl, HttpMethod.PUT, new HttpEntity<>(mockItemUpdateRequest, newHeader()),
                String.class, FACILITY_ID)).thenReturn(response);
        when(objectMapper.readValue(response.getBody(), ErrorMessage.class)).thenReturn(badRequestResponse);

        imsClient.updateItem(updateRequest, Lists.newArrayList(mockItemToUpdate));
    }

    @Test(expected = ImsClientException.class)
    public void shouldThrowImsClientExceptionWhenUpdateItemIsInvoked() throws IOException {
        ErrorMessage badRequestResponse = new ErrorMessage("mockMessage", UNKNOWN_ERROR.name());
        ResponseEntity<String> response = new ResponseEntity<>(badRequestResponse.toString(), INTERNAL_SERVER_ERROR);
        updateRequest.setFacilityId(FACILITY_ID);
        when(mapper.unitizationUpdateRequestToItemUpdateRequest(updateRequest, Lists.newArrayList(mockItemToUpdate)))
                .thenReturn(mockItemUpdateRequest);
        when(restTemplate.exchange(updateItemUrl, HttpMethod.PUT, new HttpEntity<>(mockItemUpdateRequest, newHeader()),
                String.class, FACILITY_ID)).thenReturn(response);
        when(objectMapper.readValue(response.getBody(), ErrorMessage.class)).thenReturn(badRequestResponse);

        imsClient.updateItem(updateRequest, Lists.newArrayList(mockItemToUpdate));
    }

    @Test(expected = ImsClientException.class)
    public void shouldThrowImsClientExceptionWhenUpdateItemInvokedAndResponseIsNotInProperFormat() throws IOException {

        ResponseEntity<String> response = new ResponseEntity<>("unknown_response", INTERNAL_SERVER_ERROR);
        updateRequest.setFacilityId(FACILITY_ID);
        when(mapper.unitizationUpdateRequestToItemUpdateRequest(updateRequest, Lists.newArrayList(mockItemToUpdate)))
                .thenReturn(mockItemUpdateRequest);
        when(restTemplate.exchange(updateItemUrl, HttpMethod.PUT, new HttpEntity<>(mockItemUpdateRequest, newHeader()),
                String.class, FACILITY_ID)).thenReturn(response);
        when(objectMapper.readValue(response.getBody(), ErrorMessage.class)).thenThrow(new IOException());

        imsClient.updateItem(updateRequest, Lists.newArrayList(mockItemToUpdate));
    }

    @Test(expected = ImsClientException.class)
    public void shouldThrowImsClientExceptionWhenFetchingItemsAndResponseIsNotInProperFormat() throws IOException {

        ResponseEntity<String> response = new ResponseEntity<>("unknown_response", OK);

        when(restTemplate.exchange(getItemByLabelsUrl, HttpMethod.GET, new HttpEntity<>(newHeader()), String.class,
                FACILITY_ID, LABEL_VALUES_STRING, LABEL_TYPE)).thenReturn(response);
        when(objectMapper.readValue(response.getBody(), GetItemResponse.class)).thenThrow(new IOException());

        imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(LABEL_VALUES_STRING));
    }

    @Test(expected = ImsBadRequestException.class)
    public void shouldThrowImsBadRequestExceptionWhenFetchingItems() throws IOException {

        ErrorMessage badRequestResponse = new ErrorMessage("mockMessage", UNKNOWN_ERROR.name());
        ResponseEntity<String> response = new ResponseEntity<>(badRequestResponse.toString(), BAD_REQUEST);

        when(restTemplate.exchange(getItemByLabelsUrl, HttpMethod.GET, new HttpEntity<>(newHeader()), String.class,
                FACILITY_ID, LABEL_VALUES_STRING, LABEL_TYPE)).thenReturn(response);
        when(objectMapper.readValue(response.getBody(), ErrorMessage.class)).thenReturn(badRequestResponse);

        imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(LABEL_VALUES_STRING));
    }

    @Test(expected = ImsClientException.class)
    public void shouldThrowImsClientExceptionWhenFetchingItems() throws IOException {

        ErrorMessage badRequestResponse = new ErrorMessage("mockMessage", UNKNOWN_ERROR.name());
        ResponseEntity<String> response = new ResponseEntity<>(badRequestResponse.toString(), INTERNAL_SERVER_ERROR);

        when(restTemplate.exchange(getItemByLabelsUrl, HttpMethod.GET, new HttpEntity<>(newHeader()), String.class,
                FACILITY_ID, LABEL_VALUES_STRING, LABEL_TYPE)).thenReturn(response);
        when(objectMapper.readValue(response.getBody(), ErrorMessage.class)).thenReturn(badRequestResponse);

        imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(LABEL_VALUES_STRING));
    }

    @Test
    public void shouldFetchingItemsFromItems() throws IOException {

        GetItemResponse itemResponse = new GetItemResponse(Lists.newArrayList());
        ResponseEntity<String> response = new ResponseEntity<>(itemResponse.toString(), OK);

        when(restTemplate.exchange(getItemByLabelsUrl, HttpMethod.GET, new HttpEntity<>(newHeader()), String.class,
                FACILITY_ID, LABEL_VALUES_STRING, LABEL_TYPE)).thenReturn(response);
        when(objectMapper.readValue(response.getBody(), GetItemResponse.class)).thenReturn(itemResponse);

        imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(LABEL_VALUES_STRING));
    }

    @Test(expected = ImsClientException.class)
    public void shouldThrowImsClientExceptionWhenFetchingItemsByIdAndResponseIsNotInProperFormat() throws IOException {

        ResponseEntity<String> response = new ResponseEntity<>("unknown_response", OK);

        when(restTemplate.exchange(getItemByIdsUrl, HttpMethod.GET,
                new HttpEntity<>(newHeader()), String.class, FACILITY_ID, "id")).thenReturn(response);
        when(objectMapper.readValue(response.getBody(), GetItemResponse.class)).thenThrow(new IOException());

        imsClient.getItemsByIds(FACILITY_ID, Lists.newArrayList("id"));
    }

    @Test(expected = ImsBadRequestException.class)
    public void shouldThrowImsBadRequestExceptionWhenFetchingItemsById() throws IOException {

        ErrorMessage badRequestResponse = new ErrorMessage("mockMessage", UNKNOWN_ERROR.name());
        ResponseEntity<String> response = new ResponseEntity<>(badRequestResponse.toString(), BAD_REQUEST);

        when(restTemplate.exchange(getItemByIdsUrl, HttpMethod.GET,
                new HttpEntity<>(newHeader()), String.class, FACILITY_ID, "id")).thenReturn(response);
        when(objectMapper.readValue(response.getBody(), ErrorMessage.class)).thenReturn(badRequestResponse);

        imsClient.getItemsByIds(FACILITY_ID, Lists.newArrayList("id"));
    }

    @Test(expected = ImsClientException.class)
    public void shouldThrowImsClientExceptionWhenFetchingItemsById() throws IOException {

        ErrorMessage badRequestResponse = new ErrorMessage("mockMessage", UNKNOWN_ERROR.name());
        ResponseEntity<String> response = new ResponseEntity<>(badRequestResponse.toString(), INTERNAL_SERVER_ERROR);

        when(restTemplate.exchange(getItemByIdsUrl, HttpMethod.GET,
                new HttpEntity<>(newHeader()), String.class, FACILITY_ID, "id")).thenReturn(response);
        when(objectMapper.readValue(response.getBody(), ErrorMessage.class)).thenReturn(badRequestResponse);

        imsClient.getItemsByIds(FACILITY_ID, Lists.newArrayList("id"));
    }

    @Test
    public void shouldFetchingItemsFromItemsById() throws IOException {

        GetItemResponse itemResponse = new GetItemResponse(Lists.newArrayList());
        ResponseEntity<String> response = new ResponseEntity<>(itemResponse.toString(), OK);

        when(restTemplate.exchange(getItemByIdsUrl, HttpMethod.GET,
                new HttpEntity<>(newHeader()), String.class, FACILITY_ID, "id")).thenReturn(response);
        when(objectMapper.readValue(response.getBody(), GetItemResponse.class)).thenReturn(itemResponse);

        imsClient.getItemsByIds(FACILITY_ID, Lists.newArrayList("id"));
    }

    @Test(expected = ImsClientException.class)
    public void shouldThrowImsClientExceptionWhenIOExceptionIsInvovedWhileParsing() throws IOException {
        ErrorMessage badRequestResponse = new ErrorMessage("mockMessage", UNKNOWN_ERROR.name());
        ResponseEntity<String> response = new ResponseEntity<>(badRequestResponse.toString(), INTERNAL_SERVER_ERROR);

        when(mapper.unitizationToItemCreationRequest(createItem)).thenReturn(itemCreationRequest);
        when(mapper.unitizationToItemCreationRequestAttributes(createItem)).thenReturn(itemCreationAttributes);
        when(restTemplate.exchange(Mockito.eq(createItemUrl), Mockito.eq(HttpMethod.POST),
                Mockito.<HttpEntity<ItemCreationRequest>>any(), Mockito.eq(String.class),
                Mockito.eq(FACILITY_ID))).thenReturn((ResponseEntity)response);
        when(objectMapper.readValue(Mockito.anyString(), Mockito.eq(ErrorMessage.class))).
                thenThrow(new IOException());

        imsClient.createItem(STATUS, PROCESS_OWNER, createItem);
    }
}

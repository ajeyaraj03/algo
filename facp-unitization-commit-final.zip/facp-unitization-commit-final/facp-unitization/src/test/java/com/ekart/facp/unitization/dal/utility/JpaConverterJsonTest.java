package com.ekart.facp.unitization.dal.utility;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.HashMap;
import java.util.Map;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;


/**
 * Created by ajeya.hb on 10/06/16.
 */
@RunWith(MockitoJUnitRunner.class)
public class JpaConverterJsonTest {

    @Test
    public void shouldConvertMapToJson() {
        String actualData = "{\"key1\":\"data1\",\"key2\":\"data2\",\"key3\":\"data3\"}";
        Map<String, String> dataAttrMap = new HashMap<String, String>();
        dataAttrMap.put("key1", "data1");
        dataAttrMap.put("key2", "data2");
        dataAttrMap.put("key3", "data3");

        JpaConverterJson jpaConverterJson = new JpaConverterJson();
        String jsonString = jpaConverterJson.convertToDatabaseColumn(dataAttrMap);
        assertThat(actualData, is(jsonString));

    }


    @Test
    public void shouldConvertJsonToMap() {
        String testData = "{\"key1\":\"data1\",\"key2\":\"data2\",\"key3\":\"data3\"}";
        JpaConverterJson jpaConverterJson = new JpaConverterJson();
        Map<String, String> actualResonseMap = jpaConverterJson.convertToEntityAttribute(testData);
        assertThat(actualResonseMap, is(actualResonseMap));

    }
}

package com.ekart.facp.unitization.service;

import com.ekart.facp.unitization.service.clients.FsmClient;
import com.ekart.facp.unitization.service.clients.ImsClient;
import com.ekart.facp.unitization.service.clients.LabelServiceClient;
import com.ekart.facp.unitization.service.dtos.Container;
import com.ekart.facp.unitization.service.dtos.ItemLabel;
import com.ekart.facp.unitization.service.utility.TenantContext;
import com.ekart.facp.unitization.service.validators.SpecificationAttributesValidator;
import com.ekart.facp.unitization.service.validators.UnitizationValidator;
import com.google.common.collect.Lists;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;


/**
 * Created by anurag.gupta on 06/06/16.
 */
@RunWith(MockitoJUnitRunner.class)
public class DispensibleContainerServiceTest {

    @Mock
    private ImsClient imsClient;

    @Mock
    private FsmClient fsmClient;

    @Mock
    private LabelServiceClient labelServiceClient;

    @Mock
    private SpecificationAttributesValidator specificationAttributesValidator;

    @Mock
    private UnitizationValidator unitizationValidator;

    private static String containerId = "containerId";
    private static String stateMachineId = "stateMachineId";
    private static String appId = "appId";
    private static String status = "status";
    private static String type = "type";
    private static String flowContext = "flowContext";
    private static final String TENANT = "tenant";
    private static String createdBy = "createdBy";
    private static String idempotenceKey = "idempotenceKey";
    private static String facilityId = "facilityId";
    private static String labelType  = "labelType";
    private static String labelValue = "labelValue";


    private String processOwner;
    private DispensibleContainerService containerService;
    private Container container;
    private ItemLabel label;
    private TenantContext tenantContext;

    @Before
    public void setup() {

        containerService = new DispensibleContainerService(imsClient, fsmClient, specificationAttributesValidator
                , unitizationValidator, labelServiceClient);
        tenantContext = new TenantContext(TENANT);
        container = new Container();
        container.setStateMachineId(stateMachineId);
        container.setAppId(appId);
        container.setFlowContext(flowContext);
        container.setType(type);
        container.setIdempotenceKey(idempotenceKey);
        container.setCreatedBy(createdBy);
        container.setFacilityId(facilityId);
        label = new ItemLabel();
        label.setValue(labelValue);
        label.setType(labelType);
        container.setLabel(label);
        processOwner = String.join("_", flowContext, appId, type);
    }

    @Test
    public void shouldCallCreateItemInImsClientWhenCreateContainerIsInvoked() {
        when(fsmClient.getInitialState(stateMachineId)).thenReturn(status);
        containerService.createContainer(tenantContext, container);
        verify(labelServiceClient).createLabelMapping(TENANT, facilityId, type, createdBy, idempotenceKey,
                Lists.newArrayList(label));
        verify(imsClient).createItem(status, processOwner, container);
    }

    @Test
    public void shouldReturnContainerIdWhenCreateContainerIsInvoked() {
        when(fsmClient.getInitialState(stateMachineId)).thenReturn(status);
        when(imsClient.createItem(status, processOwner, container)).thenReturn(containerId);
        assertThat(containerService.createContainer(tenantContext, container), is(containerId));
        verify(labelServiceClient).createLabelMapping(TENANT, facilityId, type, createdBy, idempotenceKey,
                Lists.newArrayList(label));
    }

}

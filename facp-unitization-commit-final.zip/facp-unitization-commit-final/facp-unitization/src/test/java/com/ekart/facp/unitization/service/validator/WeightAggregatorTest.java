package com.ekart.facp.unitization.service.validator;

import static com.ekart.facp.unitization.common.enums.Operands.*;
import com.ekart.facp.unitization.service.RuleService;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.Item;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.ItemAttribute;
import com.ekart.facp.unitization.service.exceptions.WeightExceededException;
import com.ekart.facp.unitization.service.validators.WeightAggregator;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.Map;

import static com.ekart.facp.unitization.common.enums.clients.ims.AttributeName.MAX_WEIGHT;
import static com.ekart.facp.unitization.common.enums.clients.ims.AttributeName.UNITIZATION_CURRENT_WEIGHT;
import static com.ekart.facp.unitization.common.enums.clients.ims.AttributeName.WEIGHT;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;

/**
 * Created by avinash.r on 07/08/16.
 */

@RunWith(MockitoJUnitRunner.class)
public class WeightAggregatorTest {

    private WeightAggregator weightAggregator;
    private Item shipment;
    private Item container;
    private Map<String, String> specificationAttributes;

    @Mock
    private RuleService ruleService;

    @Before
    public void setup() {

        weightAggregator = new WeightAggregator(ruleService);
        shipment = new Item("shipment", null, null, "shipmentType", "facilityId", null, null, null, null, null,
                ImmutableMap.of(WEIGHT.name(), new ItemAttribute(WEIGHT.name(), 10.0)),
                ImmutableMap.of(), ImmutableMap.of(), null, 1L, 1, 1);
        container = new Item("container", null, null, "containerType", "facilityId", null, null, null, null, null,
                ImmutableMap.of(UNITIZATION_CURRENT_WEIGHT.name(),
                        new ItemAttribute(UNITIZATION_CURRENT_WEIGHT.name(), 20.0)),
                        ImmutableMap.of(), ImmutableMap.of(), null, 1L, 1, 1);
    }

    @Test(expected = WeightExceededException.class)
    public void shouldThrowErrorIfWeightExceededWhileAddingItemToContainer() {

        specificationAttributes = ImmutableMap.of(MAX_WEIGHT.name(), "25.0");
        when(ruleService.maxWeightRule(specificationAttributes, new BigDecimal("30.0"))).thenReturn(false);
        weightAggregator.aggregate(container, Lists.newArrayList(shipment), ADD, specificationAttributes);
    }

    @Test(expected = WeightExceededException.class)
    public void shouldThrowErrorIfWeightExceededWhileRemovingItemFromContainer() {

        specificationAttributes = ImmutableMap.of(MAX_WEIGHT.name(), "5.0");
        when(ruleService.maxWeightRule(specificationAttributes, new BigDecimal("10.0"))).thenReturn(false);
        weightAggregator.aggregate(container, Lists.newArrayList(shipment), REMOVE, specificationAttributes);
    }

    @Test
    public void shouldReturnAggregatedWeightOfContainerWhileAddingItemToContainer() {

        specificationAttributes = ImmutableMap.of(MAX_WEIGHT.name(), "50.0");
        when(ruleService.maxWeightRule(specificationAttributes, new BigDecimal("30.0"))).thenReturn(true);
        assertThat(weightAggregator.aggregate(container, Lists.newArrayList(shipment), ADD, specificationAttributes)
                        .getAggregatedWeight(), is(new BigDecimal("30.0")));
    }

    @Test
    public void shouldReturnAggregatedWeightOfContainerWhileRemovingItemToContainer() {

        specificationAttributes = ImmutableMap.of(MAX_WEIGHT.name(), "50.0");
        when(ruleService.maxWeightRule(specificationAttributes, new BigDecimal("10.0"))).thenReturn(true);
        assertThat(weightAggregator.aggregate(container, Lists.newArrayList(shipment),
                REMOVE, specificationAttributes).getAggregatedWeight(), is(new BigDecimal("10.0")));
    }

    @Test
    public void shouldReturnAggregatedWeightOfContainerWhileAddingItemToContainerAndContainerDoesNotHaveCurrWt() {

        container = new Item("container", null, null, "containerType", "facilityId", null, null, null, null, null,
                ImmutableMap.of(), ImmutableMap.of(), ImmutableMap.of(), null, 1L, 1, 1);

        specificationAttributes = ImmutableMap.of(MAX_WEIGHT.name(), "50.0");
        when(ruleService.maxWeightRule(specificationAttributes, new BigDecimal("10.0"))).thenReturn(true);
        assertThat(weightAggregator.aggregate(container, Lists.newArrayList(shipment), ADD, specificationAttributes)
                .getAggregatedWeight(), is(new BigDecimal("10.0")));
    }

    @Test
    public void shouldReturnAggregatedWeightWhenSpecificationIsNotPresent() {

        container = new Item("container", null, null, "containerType", "facilityId", null, null, null, null, null,
                ImmutableMap.of(), ImmutableMap.of(), ImmutableMap.of(), null, 1L, 1, 1);

        assertThat(weightAggregator.aggregate(container, Lists.newArrayList(shipment), ADD, ImmutableMap.of())
                .getAggregatedWeight(), is(new BigDecimal("10.0")));
    }
}

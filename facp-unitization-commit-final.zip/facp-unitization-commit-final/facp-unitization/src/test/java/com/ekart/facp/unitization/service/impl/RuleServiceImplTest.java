package com.ekart.facp.unitization.service.impl;

import static com.ekart.facp.unitization.common.enums.clients.ims.AttributeName.*;
import com.google.common.collect.ImmutableMap;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

/**
 * Created by avinash.r on 19/07/16.
 */
@RunWith(MockitoJUnitRunner.class)
public class RuleServiceImplTest {

    private RuleServiceImpl ruleService;

    @Before
    public void setup() {

        ruleService = new RuleServiceImpl();
    }

    @Test
    public void shouldReturnTrueWhileValidatingMaxWeightRule() {

        assertThat(ruleService.maxWeightRule(ImmutableMap.of(MAX_WEIGHT.name(), "100.0"), new BigDecimal(10.0)),
                is(true));
    }

    @Test
    public void shouldReturnFalseWhileValidatingMaxWeightRule() {

        assertThat(ruleService.maxWeightRule(ImmutableMap.of(MAX_WEIGHT.name(), "100.0"), new BigDecimal(1000.0)),
                is(false));
    }

    @Test
    public void shouldReturnTrueWhileValidatingMaxNoOfItemsRule() {

        assertThat(ruleService.maxNoOfItemsRule(ImmutableMap.of(MAX_NO_OF_ITEMS.name(), "100"), 10),
                is(true));
    }

    @Test
    public void shouldReturnFalseWhileValidatingMaxNoOfItemsRule() {

        assertThat(ruleService.maxNoOfItemsRule(ImmutableMap.of(MAX_NO_OF_ITEMS.name(), "100"), 1000),
                is(false));
    }
}

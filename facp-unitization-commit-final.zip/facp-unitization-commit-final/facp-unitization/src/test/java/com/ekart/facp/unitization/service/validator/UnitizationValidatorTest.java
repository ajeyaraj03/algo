package com.ekart.facp.unitization.service.validator;

import com.ekart.facp.unitization.service.dtos.Unitizable;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.Item;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.ItemAttribute;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.ItemLabel;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.ItemStatus;
import com.ekart.facp.unitization.service.exceptions.AddException;
import com.ekart.facp.unitization.service.exceptions.LabelNotFoundException;
import com.ekart.facp.unitization.service.validators.UnitizationValidator;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static com.ekart.facp.unitization.common.enums.clients.ims.AttributeName.*;
import static com.ekart.facp.unitization.service.utility.TestUtils.createUnitizableRequests;

/**
 * Created by avinash.r on 20/07/16.
 */
public class UnitizationValidatorTest {

    private Item container;
    private Item shipment;
    private UnitizationValidator unitizationValidator;

    @Before
    public void setup() {

        shipment = new Item("shipment", null, null, "shipmentType", "facilityId", null, null, null, null, null,
                ImmutableMap.of(), ImmutableMap.of(), ImmutableMap.of(), null, 1L, 1, 1);

        unitizationValidator = new UnitizationValidator();
    }

    @Test(expected = AddException.class)
    public void shouldThrowErrorIfSomeItemsHaveWeightAndSomeDoNot() {

        container = new Item("container", null, null, "nonTransientContainerType", "facilityId", null, null, null,
                null, null, ImmutableMap.of(UNITIZATION_IS_TRANSIENT.name(),
                new ItemAttribute(UNITIZATION_IS_TRANSIENT.name(), "false")),
                ImmutableMap.of(), ImmutableMap.of(), null, 1L, 1, 1);

        Item shipment1 = new Item("shipment", null, null, "shipmentType", "facilityId", null, null, null,
                null, null, ImmutableMap.of(WEIGHT.name(), new ItemAttribute(WEIGHT.name(), "10.0")),
                ImmutableMap.of(), ImmutableMap.of(), null, 1L, 1, 1);

        unitizationValidator.validateContainerAttributes(ImmutableMap.of(MAX_WEIGHT.name(), "100.0"),
                Lists.newArrayList(shipment, shipment1), container);

    }

    @Test(expected = AddException.class)
    public void shouldThrowErrorIfCanNotAddItemsWithoutWeightAttribute() {

        container = new Item("container", null, null, "nonTransientContainerType", "facilityId", null, null, null,
                null, null, ImmutableMap.of(UNITIZATION_CURRENT_WEIGHT.name(),
                new ItemAttribute(UNITIZATION_CURRENT_WEIGHT.name(), "20.0")),
                ImmutableMap.of(), ImmutableMap.of(), null, 1L, 1, 1);

        unitizationValidator.validateContainerAttributes(ImmutableMap.of(MAX_WEIGHT.name(), "100.0"),
                Lists.newArrayList(shipment), container);
    }

    @Test(expected = AddException.class)
    public void shouldThrowErrorIfCanNotAddItemsWithWeightAttribute() {

        container = new Item("container", null, null, "nonTransientContainerType", "facilityId", null, null, null,
                null, null, ImmutableMap.of(UNITIZATION_CURRENT_NO_OF_ITEMS.name(),
                new ItemAttribute(UNITIZATION_CURRENT_NO_OF_ITEMS.name(), "2")),
                ImmutableMap.of(), ImmutableMap.of(), null, 1L, 1, 1);

        shipment = new Item("shipment", null, null, "shipmentType", "facilityId", null, null, null, null, null,
                ImmutableMap.of(WEIGHT.name(), new ItemAttribute(WEIGHT.name(), "10.0")),
                ImmutableMap.of(), ImmutableMap.of(), null, 1L, 1, 1);

        unitizationValidator.validateContainerAttributes(ImmutableMap.of(MAX_WEIGHT.name(), "100.0"),
                Lists.newArrayList(shipment), container);
    }

    @Test
    public void shouldValidate() {

        container = new Item("container", null, null, "nonTransientContainerType", "facilityId", null, null, null,
                null, null, ImmutableMap.of(UNITIZATION_CURRENT_NO_OF_ITEMS.name(),
                new ItemAttribute(UNITIZATION_CURRENT_NO_OF_ITEMS.name(), "0")),
                ImmutableMap.of(), ImmutableMap.of(), null, 1L, 1, 1);

        shipment = new Item("shipment", null, null, "shipmentType", "facilityId", null, null, null, null, null,
                ImmutableMap.of(WEIGHT.name(), new ItemAttribute(WEIGHT.name(), "10.0")),
                ImmutableMap.of(), ImmutableMap.of(), null, 1L, 1, 1);

        unitizationValidator.validateContainerAttributes(ImmutableMap.of(MAX_WEIGHT.name(), "100.0"),
                Lists.newArrayList(shipment), container);
    }

    @Test(expected = AddException.class)
    public void shouldThrowErrorIfUnitizablesAreNotOfSameLabelType() {

        List<Unitizable> unitizables = createUnitizableRequests("label_type1", "type", "L1");
        unitizables.addAll(createUnitizableRequests("label_type2", "type", "L2"));
        unitizationValidator.validateUnitizables(unitizables);
    }

    @Test(expected = AddException.class)
    public void shouldThrowErrorIfDuplicateLabelsArePresentInUnitizables() {

        List<Unitizable> unitizables = createUnitizableRequests("label_type1", "type", "L1");
        unitizables.addAll(createUnitizableRequests("label_type1", "type", "L1"));
        unitizationValidator.validateUnitizables(unitizables);
    }

    @Test
    public void shouldValidateUnitizables() {

        unitizationValidator.validateUnitizables(createUnitizableRequests("label", "type1", "L1", "L2"));
    }

    @Test(expected = AddException.class)
    public void shouldThrowErrorIfUnitizablesAreNotOfSameType() {

        Item shipment1 = new Item("shipment", null, null, "shipmentType1", "facilityId", null, null, null,
                null, null, ImmutableMap.of(), ImmutableMap.of(), ImmutableMap.of(), null, 1L, 1, 1);
        unitizationValidator.validateUnitizableLabelsAndState(Lists.newArrayList(shipment, shipment1), "shipment",
               Lists.newArrayList("L1", "L2"), "flow", "appId");
    }

    @Test(expected = LabelNotFoundException.class)
    public void shouldThrowErrorIfAnyLabelIsMissing() {

        shipment = new Item("shipment", null, null, "shipmentType", "facilityId", null, null, null, null, null,
                ImmutableMap.of(),
                ImmutableMap.of("flow_appId_shipmentType", new ItemStatus("flow_appId_shipmentType", "OPEN")),
                ImmutableMap.of("shipment", new ItemLabel("shipment", "L1")), null, 1L, 1, 1);
        unitizationValidator.validateUnitizableLabelsAndState(Lists.newArrayList(shipment), "shipment",
                Lists.newArrayList("L1", "L2"), "flow", "appId");
    }

    @Test(expected = AddException.class)
    public void shouldThrowErrorIfStatusesAreDifferent() {

        shipment = new Item("shipment", null, null, "shipmentType", "facilityId", null, null, null, null, null,
                ImmutableMap.of(),
                ImmutableMap.of("flow_appId_shipmentType", new ItemStatus("flow_appId_shipmentType", "OPEN")),
                ImmutableMap.of("shipment", new ItemLabel("shipment", "L1")), null, 1L, 1, 1);
        Item shipment1 = new Item("shipment", null, null, "shipmentType", "facilityId", null, null, null, null, null,
                ImmutableMap.of(),
                ImmutableMap.of("flow_appId_shipmentType", new ItemStatus("flow_appId_shipmentType", "CLOSE")),
                ImmutableMap.of("shipment", new ItemLabel("shipment", "L2")), null, 1L, 1, 1);
        unitizationValidator.validateUnitizableLabelsAndState(Lists.newArrayList(shipment, shipment1), "shipment",
                Lists.newArrayList("L1", "L2"), "flow", "appId");
    }

    @Test
    public void shouldvalidateUnitizableLabelsAndState() {

        shipment = new Item("shipment", null, null, "shipmentType", "facilityId", null, null, null, null, null,
                ImmutableMap.of(),
                ImmutableMap.of("flow_appId_shipmentType", new ItemStatus("flow_appId_shipmentType", "OPEN")),
                ImmutableMap.of("shipment", new ItemLabel("shipment", "L1")), null, 1L, 1, 1);
        Item shipment1 = new Item("shipment", null, null, "shipmentType", "facilityId", null, null, null, null, null,
                ImmutableMap.of(),
                ImmutableMap.of("flow_appId_shipmentType", new ItemStatus("flow_appId_shipmentType", "OPEN")),
                ImmutableMap.of("shipment", new ItemLabel("shipment", "L2")), null, 1L, 1, 1);
        unitizationValidator.validateUnitizableLabelsAndState(Lists.newArrayList(shipment, shipment1), "shipment",
                Lists.newArrayList("L1", "L2"), "flow", "appId");
    }
}

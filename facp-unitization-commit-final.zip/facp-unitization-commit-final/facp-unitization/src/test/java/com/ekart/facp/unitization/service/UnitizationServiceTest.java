package com.ekart.facp.unitization.service;

import com.ekart.facp.unitization.service.clients.FsmClient;
import com.ekart.facp.unitization.service.clients.ImsClient;
import com.ekart.facp.unitization.service.clients.LabelServiceClient;
import com.ekart.facp.unitization.service.clients.SpecificationClient;
import com.ekart.facp.unitization.service.dtos.AddRequest;
import com.ekart.facp.unitization.service.dtos.Container;
import com.ekart.facp.unitization.service.dtos.UpdateRequest;
import com.ekart.facp.unitization.service.dtos.clients.ims.request.ItemAddRequest;
import com.ekart.facp.unitization.service.dtos.clients.ims.request.ItemToUpdate;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.Item;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.ItemAttribute;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.ItemLabel;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.ItemStatus;
import com.ekart.facp.unitization.service.entities.Specification;
import com.ekart.facp.unitization.service.exceptions.AddException;
import com.ekart.facp.unitization.service.exceptions.ContainerNotFoundException;
import com.ekart.facp.unitization.service.exceptions.LabelNotFoundException;
import com.ekart.facp.unitization.service.exceptions.UpdateException;
import com.ekart.facp.unitization.service.utility.TenantContext;
import com.ekart.facp.unitization.service.validators.*;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import static com.ekart.facp.unitization.apis.constants.ApiConstants.ADD_TO_CONTAINER;
import static com.ekart.facp.unitization.apis.constants.ApiConstants.ADD_UNITIZABLES;
import static com.ekart.facp.unitization.common.enums.Operands.ADD;
import static com.ekart.facp.unitization.common.enums.Operands.REMOVE;
import static com.ekart.facp.unitization.common.enums.clients.ims.AttributeName.*;
import static com.ekart.facp.unitization.service.utility.TestUtils.*;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
* Created by avinash.r on 18/07/16.
*/
@RunWith(MockitoJUnitRunner.class)
public class UnitizationServiceTest {

    @Mock
    private ImsClient imsClient;

    @Mock
    private FsmClient fsmClient;

    @Mock
    private SpecificationAttributesValidator specificationAttributesValidator;

    @Mock
    private WeightAggregator weightAggregator;

    @Mock
    private NumberOfItemsAggregator numberOfItemsAggregator;

    @Mock
    private SpecificationClient specificationClient;

    @Mock
    private ItemAddRequest itemAddRequest;

    @Mock
    private ItemToUpdate itemToUpdate;

    @Mock
    private ItemToUpdate parentContainerToUpdate;

    @Mock
    private ItemAddRequest destinationContainerToBeUpdated;

    @Mock
    private ItemAddRequest sourceContainerToBeUpdated;

    @Mock
    private UnitizationValidator unitizationValidator;

    @Mock
    private LabelServiceClient labelServiceClient;

    private static final String FACILITY_ID = "facility";
    private static final String LABEL_TYPE = "primary";
    private static final String CONTAINER_LABEL = "container";
    private static final String CONTAINER_SM = "SM_UNIT";
    private static final String SHIPMENT_SM = "SM_SHIPMENT";
    private static final String SHIPMENT = "shipment";
    private static final String NON_TRANSIENT_CONTAINER_TYPE = "nonTransientContainerType";
    private static final String TRANSIENT_CONTAINER_TYPE = "transientContainerType";
    private static final String SHIPMENT_TYPE = "shipmentType";
    private static final String FLOW = "3PL";
    private static final String SHIPMENT_OWNER = "3PL_MH_shipmentType";
    private static final String CONTAINER_OWNER = "3PL_MH_nonTransientContainerType";
    private static final String BULK_OWNER = "3PL_MH_transientContainerType";
    private static final String TENANT = "tenant";

    private UnitizationService unitizationService;
    private AddRequest addRequest;
    private UpdateRequest updateRequest;
    private Item container;
    private Item bulk;
    private Item shipment;
    private Item facility;
    private Specification specification;

    @Before
    public void setup() {

        unitizationService = new UnitizationService(imsClient, fsmClient, specificationAttributesValidator,
                unitizationValidator, labelServiceClient) {
            @Override
            public String createContainer(TenantContext tenantContext, Container container) {
                return null;
            }
        };

        facility = new Item(FACILITY_ID, null, null, TRANSIENT_CONTAINER_TYPE, FACILITY_ID, null, null, null,
                null, null, ImmutableMap.of(), ImmutableMap.of(), ImmutableMap.of(), null, 1L, 1, 1);

        container = new Item(CONTAINER_LABEL, null, null, NON_TRANSIENT_CONTAINER_TYPE, FACILITY_ID, null, null, null,
                null, null, ImmutableMap.of(UNITIZATION_CURRENT_NO_OF_ITEMS.name(),
                new ItemAttribute(UNITIZATION_CURRENT_NO_OF_ITEMS.name(), "0"), UNITIZATION_IS_TRANSIENT.name(),
                new ItemAttribute(UNITIZATION_IS_TRANSIENT.name(), "false")),
                ImmutableMap.of(CONTAINER_OWNER, new ItemStatus(CONTAINER_OWNER, "OPEN")),
                ImmutableMap.of(), null, 1L, 1, 1);

        shipment = new Item(SHIPMENT, null, null, SHIPMENT_TYPE, FACILITY_ID, null, null, null, null, null,
                ImmutableMap.of(), ImmutableMap.of(), ImmutableMap.of(), null, 1L, 1, 1);

        bulk = new Item(CONTAINER_LABEL, null, null, TRANSIENT_CONTAINER_TYPE, FACILITY_ID, null, null, null,
                null, null, ImmutableMap.of(UNITIZATION_CURRENT_NO_OF_ITEMS.name(),
                new ItemAttribute(UNITIZATION_CURRENT_NO_OF_ITEMS.name(), "0"), UNITIZATION_IS_TRANSIENT.name(),
                new ItemAttribute(UNITIZATION_IS_TRANSIENT.name(), "true")),
                ImmutableMap.of(BULK_OWNER, new ItemStatus(BULK_OWNER, "OPEN")), ImmutableMap.of(), null, 1L, 1, 1);

        specification = new Specification();
    }

    @Test(expected = ContainerNotFoundException.class)
    public void shouldRaiseErrorIfDestinationContainerNotFoundWhileAdding() {

        addRequest = createAddRequest(CONTAINER_LABEL, NON_TRANSIENT_CONTAINER_TYPE, LABEL_TYPE, FACILITY_ID, FLOW,
                CONTAINER_SM, createUnitizableRequests(LABEL_TYPE, SHIPMENT_SM, SHIPMENT));
        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(CONTAINER_LABEL)))
                .thenReturn(Lists.newArrayList());
        unitizationService.addUnitizablesToContainer(ImmutableMap.of(), addRequest);
    }


    @Test(expected = LabelNotFoundException.class)
    public void shouldRaiseErrorIfUnitizableLabelNotFoundWhileAdding() {

        addRequest = createAddRequest(CONTAINER_LABEL, NON_TRANSIENT_CONTAINER_TYPE, LABEL_TYPE, FACILITY_ID, FLOW,
                CONTAINER_SM, createUnitizableRequests(LABEL_TYPE, SHIPMENT_SM, SHIPMENT));
        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(CONTAINER_LABEL)))
                .thenReturn(Lists.newArrayList(container));
        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(SHIPMENT)))
                .thenReturn(Lists.newArrayList());
        unitizationService.addUnitizablesToContainer(ImmutableMap.of(), addRequest);

        verify(unitizationValidator).validateUnitizables(addRequest.getUnitizables());
    }

    @Test(expected = AddException.class)
    public void shouldRaiseErrorIfUnitizablesAreNotFromSameSourceContainerWhileAdding() {

        specification.setAttributes(ImmutableMap.of(MAX_NO_OF_ITEMS.name(), "10"));
        Item shipment1 = new Item(CONTAINER_LABEL, null, null, SHIPMENT_TYPE, "unknownContainer", null, null, null,
                null, null, ImmutableMap.of(WEIGHT.name(), new ItemAttribute(WEIGHT.name(), 30.0)),
                ImmutableMap.of(SHIPMENT_OWNER, new ItemStatus(SHIPMENT_OWNER, "CLOSE")),
                ImmutableMap.of(LABEL_TYPE, new ItemLabel(LABEL_TYPE, SHIPMENT)), null, 1L, 1, 1);

        shipment = new Item(SHIPMENT, null, null, SHIPMENT_TYPE, FACILITY_ID, null, null, null, null, null,
                ImmutableMap.of(WEIGHT.name(), new ItemAttribute(WEIGHT.name(), "30.0")),
                ImmutableMap.of(SHIPMENT_OWNER, new ItemStatus(SHIPMENT_OWNER, "CLOSE")),
                ImmutableMap.of(LABEL_TYPE, new ItemLabel(LABEL_TYPE, SHIPMENT)), null, 1L, 1, 1);

        addRequest = createAddRequest(CONTAINER_LABEL, NON_TRANSIENT_CONTAINER_TYPE, LABEL_TYPE, FACILITY_ID, FLOW,
                CONTAINER_SM, createUnitizableRequests(LABEL_TYPE, SHIPMENT_SM, SHIPMENT));

        List<Item> items = Lists.newArrayList(shipment, shipment1);

        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(CONTAINER_LABEL)))
                .thenReturn(Lists.newArrayList(container));
        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(SHIPMENT)))
                .thenReturn(items);
        when(specificationAttributesValidator.getWeightAggregator()).thenReturn(weightAggregator);
        when(specificationAttributesValidator.getItemsAggregator()).thenReturn(numberOfItemsAggregator);

        unitizationService.addUnitizablesToContainer(specification.getAttributes(), addRequest);

        verify(fsmClient).getNextState("OPEN", ADD_UNITIZABLES, CONTAINER_SM);
        verify(fsmClient).getNextState("CLOSE", ADD_TO_CONTAINER, SHIPMENT_SM);
        verify(unitizationValidator).validateUnitizables(addRequest.getUnitizables());
        verify(unitizationValidator).validateUnitizableLabelsAndState(items,
                LABEL_TYPE, Lists.newArrayList(SHIPMENT), FLOW, "MH");
        verify(unitizationValidator).validateContainerAttributes(specification.getAttributes(), items, container);
        verify(numberOfItemsAggregator.aggregate(container, items, ADD, specification.getAttributes()));
        verify(weightAggregator.aggregate(container, items, ADD, specification.getAttributes()));
    }

    @Test(expected = ContainerNotFoundException.class)
    public void shouldRaiseErrorIfSourceContainerIsNotPresentInImsWhileAdding() {

        shipment = new Item(SHIPMENT, null, null, SHIPMENT_TYPE, FACILITY_ID, null, null, null, null, null,
                ImmutableMap.of(WEIGHT.name(), new ItemAttribute(WEIGHT.name(), "30.0")),
                ImmutableMap.of(SHIPMENT_OWNER, new ItemStatus(SHIPMENT_OWNER, "CLOSE")),
                ImmutableMap.of(LABEL_TYPE, new ItemLabel(LABEL_TYPE, SHIPMENT)), null, 1L, 1, 1);

        addRequest = createAddRequest(CONTAINER_LABEL, NON_TRANSIENT_CONTAINER_TYPE, LABEL_TYPE, FACILITY_ID, FLOW,
                CONTAINER_SM, createUnitizableRequests(LABEL_TYPE, SHIPMENT_SM, SHIPMENT));

        List<Item> items = Lists.newArrayList(shipment);

        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(CONTAINER_LABEL)))
                .thenReturn(Lists.newArrayList(container));
        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(SHIPMENT)))
                .thenReturn(items);
        when(imsClient.getItemsByIds(FACILITY_ID, Lists.newArrayList(FACILITY_ID)))
                .thenReturn(Lists.newArrayList());
        when(specificationAttributesValidator.getWeightAggregator()).thenReturn(weightAggregator);
        when(specificationAttributesValidator.getItemsAggregator()).thenReturn(numberOfItemsAggregator);

        unitizationService.addUnitizablesToContainer(ImmutableMap.of(), addRequest);

        verify(fsmClient).getNextState("OPEN", ADD_UNITIZABLES, CONTAINER_SM);
        verify(fsmClient).getNextState("CLOSE", ADD_TO_CONTAINER, SHIPMENT_SM);
        verify(unitizationValidator).validateUnitizables(addRequest.getUnitizables());
        verify(unitizationValidator).validateUnitizableLabelsAndState(items,
                LABEL_TYPE, Lists.newArrayList(SHIPMENT), FLOW, "MH");
        verify(unitizationValidator).validateContainerAttributes(specification.getAttributes(), items, container);
        verify(numberOfItemsAggregator.aggregate(container, items, ADD, specification.getAttributes()));
        verify(weightAggregator.aggregate(container, items, ADD, specification.getAttributes()));
    }

    @Test(expected = AddException.class)
    public void shouldThrowErrorIfStateMachineIdStoredInContainerAndProvidedIsMismatched() {

        container = new Item(CONTAINER_LABEL, null, null, NON_TRANSIENT_CONTAINER_TYPE, FACILITY_ID, null, null, null,
                null, null, ImmutableMap.of(UNITIZATION_CURRENT_NO_OF_ITEMS.name(),
                new ItemAttribute(UNITIZATION_CURRENT_NO_OF_ITEMS.name(), "0"), UNITIZATION_IS_TRANSIENT.name(),
                new ItemAttribute(UNITIZATION_IS_TRANSIENT.name(), "false"), UNITIZATION_STATE_MACHINE_ID.name(),
                new ItemAttribute(UNITIZATION_STATE_MACHINE_ID.name(), "sm")),
                ImmutableMap.of(CONTAINER_OWNER, new ItemStatus(CONTAINER_OWNER, "OPEN")),
                ImmutableMap.of(), null, 1L, 1, 1);


        shipment = new Item(SHIPMENT, null, null, SHIPMENT_TYPE, FACILITY_ID, null, null, null, null, null,
                ImmutableMap.of(WEIGHT.name(), new ItemAttribute(WEIGHT.name(), "30.0")),
                ImmutableMap.of(SHIPMENT_OWNER, new ItemStatus(SHIPMENT_OWNER, "CLOSE")),
                ImmutableMap.of(LABEL_TYPE, new ItemLabel(LABEL_TYPE, SHIPMENT)), null, 1L, 1, 1);

        addRequest = createAddRequest(CONTAINER_LABEL, NON_TRANSIENT_CONTAINER_TYPE, LABEL_TYPE, FACILITY_ID, FLOW,
                CONTAINER_SM, createUnitizableRequests(LABEL_TYPE, SHIPMENT_SM, SHIPMENT));

        List<Item> items = Lists.newArrayList(shipment);

        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(CONTAINER_LABEL)))
                .thenReturn(Lists.newArrayList(container));
        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(SHIPMENT)))
                .thenReturn(items);
        when(imsClient.getItemsByIds(FACILITY_ID, Lists.newArrayList(FACILITY_ID)))
                .thenReturn(Lists.newArrayList(facility));
        when(specificationAttributesValidator.getWeightAggregator()).thenReturn(weightAggregator);
        when(specificationAttributesValidator.getItemsAggregator()).thenReturn(numberOfItemsAggregator);
        when(numberOfItemsAggregator.aggregate(container, items, ADD, ImmutableMap.of()))
                .thenReturn(new NumberOfItemsAggregationResult(1L));
        when(weightAggregator.aggregate(container, items, ADD, ImmutableMap.of()))
                .thenReturn(new WeightAggregationResult(new BigDecimal("30.0")));

        unitizationService.addUnitizablesToContainer(ImmutableMap.of(), addRequest);

        verify(fsmClient).getNextState("OPEN", ADD_UNITIZABLES, CONTAINER_SM);
        verify(fsmClient).getNextState("CLOSE", ADD_TO_CONTAINER, SHIPMENT_SM);
        verify(unitizationValidator).validateUnitizables(addRequest.getUnitizables());
        verify(unitizationValidator).validateUnitizableLabelsAndState(items,
                LABEL_TYPE, Lists.newArrayList(SHIPMENT), FLOW, "MH");
        verify(unitizationValidator).validateContainerAttributes(ImmutableMap.of(), items, container);
    }

    @Test
    public void shouldMoveItemsToNonTransientContainerAndDestinationIsNotFacilityAndStateMachineIsStored() {

        container = new Item(CONTAINER_LABEL, null, null, NON_TRANSIENT_CONTAINER_TYPE, FACILITY_ID, null, null, null,
                null, null, ImmutableMap.of(UNITIZATION_CURRENT_NO_OF_ITEMS.name(),
                new ItemAttribute(UNITIZATION_CURRENT_NO_OF_ITEMS.name(), 0), UNITIZATION_IS_TRANSIENT.name(),
                new ItemAttribute(UNITIZATION_IS_TRANSIENT.name(), false), UNITIZATION_STATE_MACHINE_ID.name(),
                new ItemAttribute(UNITIZATION_STATE_MACHINE_ID.name(), CONTAINER_SM)),
                ImmutableMap.of(CONTAINER_OWNER, new ItemStatus(CONTAINER_OWNER, "OPEN")),
                ImmutableMap.of(), null, 1L, 1, 1);

        shipment = new Item(SHIPMENT, null, null, SHIPMENT_TYPE, FACILITY_ID, null, null, null, null, null,
                ImmutableMap.of(WEIGHT.name(), new ItemAttribute(WEIGHT.name(), new BigDecimal("30.0"))),
                ImmutableMap.of(SHIPMENT_OWNER, new ItemStatus(SHIPMENT_OWNER, "CLOSE")),
                ImmutableMap.of(LABEL_TYPE, new ItemLabel(LABEL_TYPE, SHIPMENT)), null, 1L, 1, 1);

        addRequest = createAddRequest(CONTAINER_LABEL, NON_TRANSIENT_CONTAINER_TYPE, LABEL_TYPE, FACILITY_ID, FLOW,
                CONTAINER_SM, createUnitizableRequests(LABEL_TYPE, SHIPMENT_SM, SHIPMENT));

        List<Item> items = Lists.newArrayList(shipment);

        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(CONTAINER_LABEL)))
                .thenReturn(Lists.newArrayList(container));
        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(SHIPMENT)))
                .thenReturn(items);
        when(imsClient.getItemsByIds(FACILITY_ID, Lists.newArrayList(FACILITY_ID)))
                .thenReturn(Lists.newArrayList(facility));
        when(imsClient.prepareItemsToMove(eq(Lists.newArrayList(shipment)), eq(container),
                eq(ImmutableMap.of(UNITIZATION_IN_CONTAINER.name(), "true")), eq(ImmutableMap.of()),
                any())).thenReturn(Lists.newArrayList(itemAddRequest));
        when(imsClient.prepareContainerToUpdate(eq(container),
                eq(ImmutableMap.of(UNITIZATION_CURRENT_NO_OF_ITEMS.name(), 1L)),
                eq(ImmutableMap.of()), any())).thenReturn(destinationContainerToBeUpdated);
        when(specificationAttributesValidator.getWeightAggregator()).thenReturn(weightAggregator);
        when(specificationAttributesValidator.getItemsAggregator()).thenReturn(numberOfItemsAggregator);
        when(numberOfItemsAggregator.aggregate(container, items, ADD, ImmutableMap.of()))
                .thenReturn(new NumberOfItemsAggregationResult(1L));
        when(weightAggregator.aggregate(container, items, ADD, ImmutableMap.of()))
                .thenReturn(new WeightAggregationResult(new BigDecimal("30.0")));
        when(fsmClient.getNextState("OPEN", ADD_UNITIZABLES, CONTAINER_SM)).thenReturn("OPEN");
        when(fsmClient.getNextState("CLOSE", ADD_TO_CONTAINER, SHIPMENT_SM)).thenReturn("CLOSE");

        unitizationService.addUnitizablesToContainer(ImmutableMap.of(), addRequest);

        verify(imsClient).moveItems(addRequest, Lists.newArrayList(itemAddRequest, destinationContainerToBeUpdated));
        verify(unitizationValidator).validateUnitizables(addRequest.getUnitizables());
        verify(unitizationValidator).validateUnitizableLabelsAndState(items,
                LABEL_TYPE, Lists.newArrayList(SHIPMENT), FLOW, "MH");
    }

    @Test
    public void shouldMoveItemsToNonTransientContainerAndDestinationIsNotFacilityAndStateMachineIsNotStored() {

        shipment = new Item(SHIPMENT, null, null, SHIPMENT_TYPE, FACILITY_ID, null, null, null, null, null,
                ImmutableMap.of(WEIGHT.name(), new ItemAttribute(WEIGHT.name(), "30.0")),
                ImmutableMap.of(SHIPMENT_OWNER, new ItemStatus(SHIPMENT_OWNER, "CLOSE")),
                ImmutableMap.of(LABEL_TYPE, new ItemLabel(LABEL_TYPE, SHIPMENT)), null, 1L, 1, 1);

        addRequest = createAddRequest(CONTAINER_LABEL, NON_TRANSIENT_CONTAINER_TYPE, LABEL_TYPE, FACILITY_ID, FLOW,
                CONTAINER_SM, createUnitizableRequests(LABEL_TYPE, SHIPMENT_SM, SHIPMENT));
        List<Item> items = Lists.newArrayList(shipment);
        specification.setAttributes(ImmutableMap.of(MAX_WEIGHT.name(), "50.0", MAX_NO_OF_ITEMS.name(), "5"));

        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(CONTAINER_LABEL)))
                .thenReturn(Lists.newArrayList(container));
        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(SHIPMENT)))
                .thenReturn(items);
        when(imsClient.getItemsByIds(FACILITY_ID, Lists.newArrayList(FACILITY_ID)))
                .thenReturn(Lists.newArrayList(facility));
        when(imsClient.prepareItemsToMove(eq(Lists.newArrayList(shipment)), eq(container),
                eq(ImmutableMap.of(UNITIZATION_IN_CONTAINER.name(), "true")), eq(ImmutableMap.of()), any()))
                .thenReturn(Lists.newArrayList(itemAddRequest));
        when(imsClient.prepareContainerToUpdate(eq(container),
                eq(ImmutableMap.of(UNITIZATION_CURRENT_NO_OF_ITEMS.name(), 1L,
                        UNITIZATION_CURRENT_WEIGHT.name(), new BigDecimal("30.0"),
                        UNITIZATION_STATE_MACHINE_ID.name(), CONTAINER_SM)),
                eq(ImmutableMap.of()), any())).thenReturn(destinationContainerToBeUpdated);
        when(specificationAttributesValidator.getWeightAggregator()).thenReturn(weightAggregator);
        when(specificationAttributesValidator.getItemsAggregator()).thenReturn(numberOfItemsAggregator);
        when(numberOfItemsAggregator.aggregate(container, items, ADD, specification.getAttributes()))
                .thenReturn(new NumberOfItemsAggregationResult(1L));
        when(weightAggregator.aggregate(container, items, ADD, specification.getAttributes()))
                .thenReturn(new WeightAggregationResult(new BigDecimal("30.0")));
        when(fsmClient.getNextState("OPEN", ADD_UNITIZABLES, CONTAINER_SM)).thenReturn("OPEN");
        when(fsmClient.getNextState("CLOSE", ADD_TO_CONTAINER, SHIPMENT_SM)).thenReturn("CLOSE");

        unitizationService.addUnitizablesToContainer(specification.getAttributes(), addRequest);

        verify(imsClient).moveItems(addRequest, Lists.newArrayList(itemAddRequest, destinationContainerToBeUpdated));
        verify(unitizationValidator).validateUnitizables(addRequest.getUnitizables());
        verify(unitizationValidator).validateUnitizableLabelsAndState(items,
                LABEL_TYPE, Lists.newArrayList(SHIPMENT), FLOW, "MH");
        verify(unitizationValidator).validateContainerAttributes(specification.getAttributes(), items, container);
        verify(numberOfItemsAggregator).aggregate(container, items, ADD, specification.getAttributes());
        verify(weightAggregator).aggregate(container, items, ADD, specification.getAttributes());
    }

    @Test
    public void shouldMoveItemsToNonTransientContainerAndContainerAlreadyHasSomeItems() {

        container = new Item(CONTAINER_LABEL, null, null, NON_TRANSIENT_CONTAINER_TYPE, FACILITY_ID, null, null, null,
                null, null, ImmutableMap.of(UNITIZATION_CURRENT_NO_OF_ITEMS.name(),
                new ItemAttribute(UNITIZATION_CURRENT_NO_OF_ITEMS.name(), "1"), UNITIZATION_IS_TRANSIENT.name(),
                new ItemAttribute(UNITIZATION_IS_TRANSIENT.name(), "false"), UNITIZATION_CURRENT_WEIGHT.name(),
                new ItemAttribute(UNITIZATION_CURRENT_WEIGHT.name(), "1.0")),
                ImmutableMap.of(CONTAINER_OWNER, new ItemStatus(CONTAINER_OWNER, "OPEN")),
                ImmutableMap.of(), null, 1L, 1, 1);

        shipment = new Item(SHIPMENT, null, null, SHIPMENT_TYPE, FACILITY_ID, null, null, null, null, null,
                ImmutableMap.of(WEIGHT.name(), new ItemAttribute(WEIGHT.name(), "30.0")),
                ImmutableMap.of(SHIPMENT_OWNER, new ItemStatus(SHIPMENT_OWNER, "CLOSE")),
                ImmutableMap.of(LABEL_TYPE, new ItemLabel(LABEL_TYPE, SHIPMENT)), null, 1L, 1, 1);

        addRequest = createAddRequest(CONTAINER_LABEL, NON_TRANSIENT_CONTAINER_TYPE, LABEL_TYPE, FACILITY_ID, FLOW,
                CONTAINER_SM, createUnitizableRequests(LABEL_TYPE, SHIPMENT_SM, SHIPMENT));
        List<Item> items = Lists.newArrayList(shipment);
        specification.setAttributes(ImmutableMap.of(MAX_WEIGHT.name(), "50.0", MAX_NO_OF_ITEMS.name(), "5"));

        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(CONTAINER_LABEL)))
                .thenReturn(Lists.newArrayList(container));
        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(SHIPMENT)))
                .thenReturn(items);
        when(imsClient.getItemsByIds(FACILITY_ID, Lists.newArrayList(FACILITY_ID)))
                .thenReturn(Lists.newArrayList(facility));
        when(imsClient.prepareItemsToMove(eq(items), eq(container),
                eq(ImmutableMap.of(UNITIZATION_IN_CONTAINER.name(), "true")), eq(ImmutableMap.of()), any()))
                .thenReturn(Lists.newArrayList(itemAddRequest));
        when(imsClient.prepareContainerToUpdate(eq(container),
                eq(ImmutableMap.of(UNITIZATION_CURRENT_NO_OF_ITEMS.name(), 2L,
                        UNITIZATION_CURRENT_WEIGHT.name(), new BigDecimal("31.0"),
                        UNITIZATION_STATE_MACHINE_ID.name(), CONTAINER_SM)),
                eq(ImmutableMap.of()), any())).thenReturn(destinationContainerToBeUpdated);
        when(specificationAttributesValidator.getWeightAggregator()).thenReturn(weightAggregator);
        when(specificationAttributesValidator.getItemsAggregator()).thenReturn(numberOfItemsAggregator);
        when(numberOfItemsAggregator.aggregate(container, items, ADD, specification.getAttributes()))
                .thenReturn(new NumberOfItemsAggregationResult(2L));
        when(weightAggregator.aggregate(container, items, ADD, specification.getAttributes()))
                .thenReturn(new WeightAggregationResult(new BigDecimal("31.0")));
        when(fsmClient.getNextState("OPEN", ADD_UNITIZABLES, CONTAINER_SM)).thenReturn("OPEN");
        when(fsmClient.getNextState("CLOSE", ADD_TO_CONTAINER, SHIPMENT_SM)).thenReturn("CLOSE");

        unitizationService.addUnitizablesToContainer(specification.getAttributes(), addRequest);

        verify(imsClient).moveItems(addRequest, Lists.newArrayList(itemAddRequest, destinationContainerToBeUpdated));
        verify(unitizationValidator).validateUnitizables(addRequest.getUnitizables());
        verify(unitizationValidator).validateUnitizableLabelsAndState(items,
                LABEL_TYPE, Lists.newArrayList(SHIPMENT), FLOW, "MH");
        verify(unitizationValidator).validateContainerAttributes(specification.getAttributes(), items, container);
    }

    @Test
    public void shouldMoveItemsToTransientContainerAndSourceContainerIsNotFacility() {

        container = new Item(CONTAINER_LABEL, null, null, NON_TRANSIENT_CONTAINER_TYPE, FACILITY_ID, null, null, null,
                null, null, ImmutableMap.of(UNITIZATION_CURRENT_NO_OF_ITEMS.name(),
                new ItemAttribute(UNITIZATION_CURRENT_NO_OF_ITEMS.name(), 1L), UNITIZATION_STATE_MACHINE_ID.name(),
                new ItemAttribute(UNITIZATION_STATE_MACHINE_ID.name(), CONTAINER_SM), UNITIZATION_CURRENT_WEIGHT.name(),
                new ItemAttribute(UNITIZATION_CURRENT_WEIGHT.name(), new BigDecimal("40.0"))),
                ImmutableMap.of(CONTAINER_OWNER, new ItemStatus(CONTAINER_OWNER, "OPEN")),
                ImmutableMap.of(), null, 1L, 1, 1);

        shipment = new Item(SHIPMENT, null, null, SHIPMENT_TYPE, CONTAINER_LABEL, null, null, null, null, null,
                ImmutableMap.of(WEIGHT.name(), new ItemAttribute(WEIGHT.name(), new BigDecimal("30.0"))),
                ImmutableMap.of(SHIPMENT_OWNER, new ItemStatus(SHIPMENT_OWNER, "CLOSE")),
                ImmutableMap.of(LABEL_TYPE, new ItemLabel(LABEL_TYPE, SHIPMENT)), null, 1L, 1, 1);

        addRequest = createAddRequest(CONTAINER_LABEL, TRANSIENT_CONTAINER_TYPE, LABEL_TYPE, FACILITY_ID, FLOW,
                CONTAINER_SM, createUnitizableRequests(LABEL_TYPE, SHIPMENT_SM, SHIPMENT));
        List<Item> items = Lists.newArrayList(shipment);

        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(CONTAINER_LABEL)))
                .thenReturn(Lists.newArrayList(bulk));
        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(SHIPMENT)))
                .thenReturn(items);
        when(imsClient.getItemsByIds(FACILITY_ID, Lists.newArrayList(CONTAINER_LABEL)))
                .thenReturn(Lists.newArrayList(container));
        when(imsClient.prepareItemsToMove(eq(items), eq(bulk),
                eq(ImmutableMap.of()), eq(ImmutableMap.of(UNITIZATION_IN_CONTAINER.name(), "true")), any()))
                .thenReturn(Lists.newArrayList(itemAddRequest));
        when(imsClient.prepareContainerToUpdate(eq(container),
                eq(ImmutableMap.of(UNITIZATION_CURRENT_NO_OF_ITEMS.name(), 0L)),
                eq(ImmutableMap.of(UNITIZATION_STATE_MACHINE_ID.name(), CONTAINER_SM,
                        UNITIZATION_CURRENT_WEIGHT.name(), new BigDecimal("40.0"))), any()))
                .thenReturn(sourceContainerToBeUpdated);
        when(imsClient.prepareContainerToUpdate(eq(bulk), eq(ImmutableMap.of(UNITIZATION_CURRENT_NO_OF_ITEMS.name(), 1L,
                UNITIZATION_STATE_MACHINE_ID.name(), CONTAINER_SM)), eq(ImmutableMap.of()), any()))
                .thenReturn(destinationContainerToBeUpdated);
        when(specificationAttributesValidator.getItemsAggregator()).thenReturn(numberOfItemsAggregator);
        when(specificationAttributesValidator.getWeightAggregator()).thenReturn(weightAggregator);
        when(numberOfItemsAggregator.aggregate(container, items, REMOVE, ImmutableMap.of()))
                .thenReturn(new NumberOfItemsAggregationResult(0L));
        when(weightAggregator.aggregate(container, items, REMOVE, ImmutableMap.of()))
                .thenReturn(new WeightAggregationResult(new BigDecimal("10.0")));
        when(numberOfItemsAggregator.aggregate(bulk, items, ADD, ImmutableMap.of()))
                .thenReturn(new NumberOfItemsAggregationResult(1L));
        when(weightAggregator.aggregate(bulk, items, ADD, ImmutableMap.of()))
                .thenReturn(new WeightAggregationResult(BigDecimal.ZERO));
        when(fsmClient.getNextState("OPEN", ADD_UNITIZABLES, CONTAINER_SM)).thenReturn("OPEN");
        when(fsmClient.getNextState("CLOSE", ADD_TO_CONTAINER, SHIPMENT_SM)).thenReturn("CLOSE");

        unitizationService.addUnitizablesToContainer(ImmutableMap.of(), addRequest);

        verify(imsClient).moveItems(addRequest, Lists.newArrayList(itemAddRequest, sourceContainerToBeUpdated,
                destinationContainerToBeUpdated));
        verify(unitizationValidator).validateUnitizables(addRequest.getUnitizables());
        verify(unitizationValidator).validateUnitizableLabelsAndState(items,
                LABEL_TYPE, Lists.newArrayList(SHIPMENT), FLOW, "MH");
    }

    @Test
    public void shouldMoveItemsToTransientContainerHavingMaxWeightInSpecificationAndSourceContainerIsNotFacility() {

        container = new Item(CONTAINER_LABEL, null, null, NON_TRANSIENT_CONTAINER_TYPE, FACILITY_ID, null, null, null,
                null, null, ImmutableMap.of(UNITIZATION_CURRENT_NO_OF_ITEMS.name(),
                new ItemAttribute(UNITIZATION_CURRENT_NO_OF_ITEMS.name(), 1L), UNITIZATION_STATE_MACHINE_ID.name(),
                new ItemAttribute(UNITIZATION_STATE_MACHINE_ID.name(), CONTAINER_SM)),
                ImmutableMap.of(CONTAINER_OWNER, new ItemStatus(CONTAINER_OWNER, "OPEN")),
                ImmutableMap.of(), null, 1L, 1, 1);

        shipment = new Item(SHIPMENT, null, null, SHIPMENT_TYPE, CONTAINER_LABEL, null, null, null, null, null,
                ImmutableMap.of(WEIGHT.name(), new ItemAttribute(WEIGHT.name(), new BigDecimal("30.0"))),
                ImmutableMap.of(SHIPMENT_OWNER, new ItemStatus(SHIPMENT_OWNER, "CLOSE")),
                ImmutableMap.of(LABEL_TYPE, new ItemLabel(LABEL_TYPE, SHIPMENT)), null, 1L, 1, 1);

        addRequest = createAddRequest(CONTAINER_LABEL, TRANSIENT_CONTAINER_TYPE, LABEL_TYPE, FACILITY_ID, FLOW,
                CONTAINER_SM, createUnitizableRequests(LABEL_TYPE, SHIPMENT_SM, SHIPMENT));
        List<Item> items = Lists.newArrayList(shipment);
        specification.setAttributes(ImmutableMap.of(MAX_WEIGHT.name(), "1000.0"));

        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(CONTAINER_LABEL)))
                .thenReturn(Lists.newArrayList(bulk));
        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(SHIPMENT)))
                .thenReturn(Lists.newArrayList(shipment));
        when(imsClient.getItemsByIds(FACILITY_ID, Lists.newArrayList(CONTAINER_LABEL)))
                .thenReturn(Lists.newArrayList(container));
        when(imsClient.prepareItemsToMove(eq(Lists.newArrayList(shipment)), eq(bulk),
                eq(ImmutableMap.of()), eq(ImmutableMap.of(UNITIZATION_IN_CONTAINER.name(), "true")), any()))////////
                .thenReturn(Lists.newArrayList(itemAddRequest));
        when(imsClient.prepareContainerToUpdate(eq(container),
                eq(ImmutableMap.of(UNITIZATION_CURRENT_NO_OF_ITEMS.name(), 0L)),
                eq(ImmutableMap.of(UNITIZATION_STATE_MACHINE_ID.name(), CONTAINER_SM)), any()))////////////
                .thenReturn(sourceContainerToBeUpdated);
        when(imsClient.prepareContainerToUpdate(eq(bulk), eq(ImmutableMap.of(UNITIZATION_CURRENT_NO_OF_ITEMS.name(), 1L,
                UNITIZATION_STATE_MACHINE_ID.name(), CONTAINER_SM)), eq(ImmutableMap.of()), any()))////////////
                .thenReturn(destinationContainerToBeUpdated);
        when(specificationAttributesValidator.getItemsAggregator()).thenReturn(numberOfItemsAggregator);
        when(specificationAttributesValidator.getWeightAggregator()).thenReturn(weightAggregator);
        when(numberOfItemsAggregator.aggregate(container, items, REMOVE, specification.getAttributes()))
                .thenReturn(new NumberOfItemsAggregationResult(0L));
        when(weightAggregator.aggregate(container, items, REMOVE, specification.getAttributes()))
                .thenReturn(new WeightAggregationResult(new BigDecimal("10.0")));
        when(numberOfItemsAggregator.aggregate(bulk, items, ADD, specification.getAttributes()))
                .thenReturn(new NumberOfItemsAggregationResult(1L));
        when(weightAggregator.aggregate(bulk, items, ADD, specification.getAttributes()))
                .thenReturn(new WeightAggregationResult(BigDecimal.ZERO));
        when(fsmClient.getNextState("OPEN", ADD_UNITIZABLES, CONTAINER_SM)).thenReturn("OPEN");
        when(fsmClient.getNextState("CLOSE", ADD_TO_CONTAINER, SHIPMENT_SM)).thenReturn("CLOSE");

        unitizationService.addUnitizablesToContainer(specification.getAttributes(), addRequest);

        verify(imsClient).moveItems(addRequest, Lists.newArrayList(itemAddRequest, sourceContainerToBeUpdated,
                destinationContainerToBeUpdated));
        verify(unitizationValidator).validateContainerAttributes(specification.getAttributes(), items, bulk);
        verify(unitizationValidator).validateUnitizables(addRequest.getUnitizables());
        verify(unitizationValidator).validateUnitizableLabelsAndState(items,
                LABEL_TYPE, Lists.newArrayList(SHIPMENT), FLOW, "MH");
    }

    @Test
    public void shouldMoveItemsToTransientContainerAndSourceContainerIsNotFacilityAndHasMoreThanOneItem() {

        container = new Item(CONTAINER_LABEL, null, null, NON_TRANSIENT_CONTAINER_TYPE, FACILITY_ID, null, null, null,
                null, null, ImmutableMap.of(UNITIZATION_CURRENT_NO_OF_ITEMS.name(),
                new ItemAttribute(UNITIZATION_CURRENT_NO_OF_ITEMS.name(), 2L), UNITIZATION_CURRENT_WEIGHT.name(),
                new ItemAttribute(UNITIZATION_CURRENT_WEIGHT.name(), new BigDecimal("50.0")),
                UNITIZATION_STATE_MACHINE_ID.name(),
                new ItemAttribute(UNITIZATION_STATE_MACHINE_ID.name(), CONTAINER_SM)),
                ImmutableMap.of(CONTAINER_OWNER, new ItemStatus(CONTAINER_OWNER, "OPEN")),
                ImmutableMap.of(), null, 1L, 1, 1);

        shipment = new Item(SHIPMENT, null, null, SHIPMENT_TYPE, CONTAINER_LABEL, null, null, null, null, null,
                ImmutableMap.of(WEIGHT.name(), new ItemAttribute(WEIGHT.name(), new BigDecimal("30.0"))),
                ImmutableMap.of(SHIPMENT_OWNER, new ItemStatus(SHIPMENT_OWNER, "CLOSE")),
                ImmutableMap.of(LABEL_TYPE, new ItemLabel(LABEL_TYPE, SHIPMENT)), null, 1L, 1, 1);

        addRequest = createAddRequest(CONTAINER_LABEL, TRANSIENT_CONTAINER_TYPE, LABEL_TYPE, FACILITY_ID, FLOW,
                CONTAINER_SM, createUnitizableRequests(LABEL_TYPE, SHIPMENT_SM, SHIPMENT));

        List<Item> items = Lists.newArrayList(shipment);

        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(CONTAINER_LABEL)))
                .thenReturn(Lists.newArrayList(bulk));
        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(SHIPMENT)))
                .thenReturn(items);
        when(imsClient.getItemsByIds(FACILITY_ID, Lists.newArrayList(CONTAINER_LABEL)))
                .thenReturn(Lists.newArrayList(container));
        when(imsClient.prepareItemsToMove(eq(items), eq(bulk),
                eq(ImmutableMap.of()), eq(ImmutableMap.of(UNITIZATION_IN_CONTAINER.name(), "true")),
                any())).thenReturn(Lists.newArrayList(itemAddRequest));
        when(imsClient.prepareContainerToUpdate(eq(container),
                eq(ImmutableMap.of(UNITIZATION_CURRENT_NO_OF_ITEMS.name(), 1L,
                        UNITIZATION_CURRENT_WEIGHT.name(), new BigDecimal("20.0"))), eq(ImmutableMap.of()),
                any())).thenReturn(sourceContainerToBeUpdated);
        when(imsClient.prepareContainerToUpdate(eq(bulk), eq(ImmutableMap.of(UNITIZATION_CURRENT_NO_OF_ITEMS.name(), 1L,
                UNITIZATION_STATE_MACHINE_ID.name(), CONTAINER_SM)), eq(ImmutableMap.of()), any()))
                .thenReturn(destinationContainerToBeUpdated);
        when(specificationAttributesValidator.getItemsAggregator()).thenReturn(numberOfItemsAggregator);
        when(specificationAttributesValidator.getWeightAggregator()).thenReturn(weightAggregator);
        when(numberOfItemsAggregator.aggregate(container, items, REMOVE, ImmutableMap.of()))
                .thenReturn(new NumberOfItemsAggregationResult(1L));
        when(weightAggregator.aggregate(container, items, REMOVE, ImmutableMap.of()))
                .thenReturn(new WeightAggregationResult(new BigDecimal("20.0")));
        when(weightAggregator.aggregate(bulk, items, ADD, ImmutableMap.of()))
                .thenReturn(new WeightAggregationResult(BigDecimal.ZERO));
        when(numberOfItemsAggregator.aggregate(bulk, items, ADD, ImmutableMap.of()))
                .thenReturn(new NumberOfItemsAggregationResult(1L));
        when(fsmClient.getNextState("OPEN", ADD_UNITIZABLES, CONTAINER_SM)).thenReturn("OPEN");
        when(fsmClient.getNextState("CLOSE", ADD_TO_CONTAINER, SHIPMENT_SM)).thenReturn("CLOSE");

        unitizationService.addUnitizablesToContainer(ImmutableMap.of(), addRequest);

        verify(imsClient).moveItems(addRequest, Lists.newArrayList(itemAddRequest, sourceContainerToBeUpdated,
                destinationContainerToBeUpdated));
        verify(unitizationValidator).validateUnitizables(addRequest.getUnitizables());
        verify(unitizationValidator).validateUnitizableLabelsAndState(items,
                LABEL_TYPE, Lists.newArrayList(SHIPMENT), FLOW, "MH");
    }


    //update

    @Test(expected = LabelNotFoundException.class)
    public void shouldRaiseErrorIfLabelNotFoundWhileUpdating() {

        updateRequest = createUpdateRequest(SHIPMENT_TYPE, SHIPMENT, FACILITY_ID, FLOW, LABEL_TYPE, SHIPMENT_SM,
                "update");

        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(SHIPMENT)))
                .thenReturn(Lists.newArrayList());
        unitizationService.updateItem(specificationClient, TENANT, updateRequest);
    }

    @Test
    public void shouldUpdateItemWeightIfParentContainerIsFacility() {

        updateRequest = createUpdateRequest(SHIPMENT_TYPE, SHIPMENT, FACILITY_ID, FLOW, LABEL_TYPE, SHIPMENT_SM,
                "update");
        updateRequest.getUpdateRequestItems().get(0).setAttributes(
                Lists.newArrayList(new com.ekart.facp.unitization.service.dtos.ItemAttribute(
                        WEIGHT.name(), "50.0")));

        shipment = new Item(SHIPMENT, null, null, SHIPMENT_TYPE, FACILITY_ID, null, null, null, null, null,
                ImmutableMap.of(WEIGHT.name(), new ItemAttribute(WEIGHT.name(), "20.0")),
                ImmutableMap.of(SHIPMENT_OWNER, new ItemStatus(SHIPMENT_OWNER, "CLOSE")),
                ImmutableMap.of(), null, 1L, 1, 1);

        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(SHIPMENT)))
                .thenReturn(Lists.newArrayList(shipment));
        when(fsmClient.getNextState("CLOSE", "update", SHIPMENT_SM)).thenReturn("CLOSE");
        when(imsClient.prepareItemToUpdate(shipment, ImmutableMap.of(WEIGHT.name(), "50.0"), ImmutableMap.of(
                updateRequest.getUpdateRequestItems().get(0).getLabelsToBeAdded().get(0).getType(),
                updateRequest.getUpdateRequestItems().get(0).getLabelsToBeAdded().get(0).getValue()),
                ImmutableMap.of(SHIPMENT_OWNER, "CLOSE"))).thenReturn(itemToUpdate);

        unitizationService.updateItem(specificationClient, TENANT, updateRequest);

        verify(labelServiceClient).createLabelMapping(TENANT, FACILITY_ID,
                updateRequest.getUpdateRequestItems().get(0).getType(),
                updateRequest.getRequestedBy(),
                updateRequest.getIdempotenceKey(),
                updateRequest.getUpdateRequestItems().get(0).getLabelsToBeAdded());
        verify(imsClient).updateItem(updateRequest, Lists.newArrayList(itemToUpdate));
    }

    @Test
    public void shouldUpdateItemStatusIfParentContainerIsFacility() {

        updateRequest = createUpdateRequest(SHIPMENT_TYPE, SHIPMENT, FACILITY_ID, FLOW, LABEL_TYPE, SHIPMENT_SM,
                "dispatch");

        shipment = new Item(SHIPMENT, null, null, SHIPMENT_TYPE, FACILITY_ID, null, null, null, null, null,
                ImmutableMap.of(), ImmutableMap.of(SHIPMENT_OWNER, new ItemStatus(SHIPMENT_OWNER, "CLOSE")),
                ImmutableMap.of(), null, 1L, 1, 1);

        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(SHIPMENT)))
                .thenReturn(Lists.newArrayList(shipment));
        when(fsmClient.getNextState("CLOSE", "dispatch", SHIPMENT_SM)).thenReturn("DISPATCH");
        when(imsClient.prepareItemToUpdate(shipment, ImmutableMap.of(), ImmutableMap.of(
                updateRequest.getUpdateRequestItems().get(0).getLabelsToBeAdded().get(0).getType(),
                updateRequest.getUpdateRequestItems().get(0).getLabelsToBeAdded().get(0).getValue()),
                ImmutableMap.of(SHIPMENT_OWNER, "DISPATCH"))).thenReturn(itemToUpdate);

        unitizationService.updateItem(specificationClient, TENANT, updateRequest);

        verify(labelServiceClient).createLabelMapping(TENANT, FACILITY_ID,
                updateRequest.getUpdateRequestItems().get(0).getType(),
                updateRequest.getRequestedBy(),
                updateRequest.getIdempotenceKey(),
                updateRequest.getUpdateRequestItems().get(0).getLabelsToBeAdded());
        verify(imsClient).updateItem(updateRequest, Lists.newArrayList(itemToUpdate));
    }

    @Test
    public void shouldUpdateItemAttributeIfParentContainerIsFacility() {

        updateRequest = createUpdateRequest(SHIPMENT_TYPE, SHIPMENT, FACILITY_ID, FLOW, LABEL_TYPE, SHIPMENT_SM,
                "update");
        updateRequest.getUpdateRequestItems().get(0).setAttributes(
                Lists.newArrayList(new com.ekart.facp.unitization.service.dtos.ItemAttribute(
                        "x", "y")));

        shipment = new Item(SHIPMENT, null, null, SHIPMENT_TYPE, FACILITY_ID, null, null, null, null, null,
                ImmutableMap.of(), ImmutableMap.of(SHIPMENT_OWNER, new ItemStatus(SHIPMENT_OWNER, "CLOSE")),
                ImmutableMap.of(), null, 1L, 1, 1);

        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(SHIPMENT)))
                .thenReturn(Lists.newArrayList(shipment));
        when(fsmClient.getNextState("CLOSE", "update", SHIPMENT_SM)).thenReturn("CLOSE");
        when(imsClient.prepareItemToUpdate(shipment, ImmutableMap.of("x", "y"), ImmutableMap.of(
                updateRequest.getUpdateRequestItems().get(0).getLabelsToBeAdded().get(0).getType(),
                updateRequest.getUpdateRequestItems().get(0).getLabelsToBeAdded().get(0).getValue()),
                ImmutableMap.of(SHIPMENT_OWNER, "CLOSE"))).thenReturn(itemToUpdate);

        unitizationService.updateItem(specificationClient, TENANT, updateRequest);

        verify(labelServiceClient).createLabelMapping(TENANT, FACILITY_ID,
                updateRequest.getUpdateRequestItems().get(0).getType(),
                updateRequest.getRequestedBy(),
                updateRequest.getIdempotenceKey(),
                updateRequest.getUpdateRequestItems().get(0).getLabelsToBeAdded());
        verify(imsClient).updateItem(updateRequest, Lists.newArrayList(itemToUpdate));
    }

    @Test(expected = ContainerNotFoundException.class)
    public void shouldRaiseErrorIfParentContainerDoesNotExistWhileUpdatingWeightAttr() {

        container = new Item(CONTAINER_LABEL, null, null, NON_TRANSIENT_CONTAINER_TYPE, FACILITY_ID, null, null, null,
                null, null, ImmutableMap.of(UNITIZATION_CURRENT_NO_OF_ITEMS.name(),
                new ItemAttribute(UNITIZATION_CURRENT_NO_OF_ITEMS.name(), "2")),
                ImmutableMap.of(CONTAINER_OWNER, new ItemStatus(CONTAINER_OWNER, "OPEN")),
                ImmutableMap.of(), null, 1L, 1, 1);
        shipment = new Item(SHIPMENT, null, null, SHIPMENT_TYPE, CONTAINER_LABEL, null, null, null, null, null,
                ImmutableMap.of(), ImmutableMap.of(SHIPMENT_OWNER, new ItemStatus(SHIPMENT_OWNER, "CLOSE")),
                ImmutableMap.of(), null, 1L, 1, 1);

        updateRequest = createUpdateRequest(SHIPMENT_TYPE, SHIPMENT, FACILITY_ID, FLOW, LABEL_TYPE, SHIPMENT_SM,
                "update");
        updateRequest.getUpdateRequestItems().get(0).setAttributes(
                Lists.newArrayList(new com.ekart.facp.unitization.service.dtos.ItemAttribute(
                        WEIGHT.name(), "20.0")));

        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(SHIPMENT)))
                .thenReturn(Lists.newArrayList(shipment));
        when(fsmClient.getNextState("CLOSE", "update", SHIPMENT_SM)).thenReturn("CLOSE");
        when(imsClient.getItemsByIds(FACILITY_ID, Lists.newArrayList(CONTAINER_LABEL)))
                .thenReturn(Lists.newArrayList());
        unitizationService.updateItem(specificationClient, TENANT, updateRequest);
    }

    @Test(expected = UpdateException.class)
    public void shouldRaiseErrorIfParentContainerIsNonTransientAndDoesNotHaveCurrentWeightAttr() {

        container = new Item(CONTAINER_LABEL, null, null, NON_TRANSIENT_CONTAINER_TYPE, FACILITY_ID, null, null, null,
                null, null, ImmutableMap.of(UNITIZATION_CURRENT_NO_OF_ITEMS.name(),
                new ItemAttribute(UNITIZATION_CURRENT_NO_OF_ITEMS.name(), "2"), UNITIZATION_IS_TRANSIENT.name(),
                new ItemAttribute(UNITIZATION_IS_TRANSIENT.name(), "false")),
                ImmutableMap.of(CONTAINER_OWNER, new ItemStatus(CONTAINER_OWNER, "OPEN")),
                ImmutableMap.of(), null, 1L, 1, 1);

        specification.setAttributes(ImmutableMap.of(MAX_WEIGHT.name(), "100.0"));

        shipment = new Item(SHIPMENT, null, null, SHIPMENT_TYPE, CONTAINER_LABEL, null, null, null, null, null,
                ImmutableMap.of(), ImmutableMap.of(SHIPMENT_OWNER, new ItemStatus(SHIPMENT_OWNER, "CLOSE")),
                ImmutableMap.of(), null, 1L, 1, 1);

        updateRequest = createUpdateRequest(SHIPMENT_TYPE, SHIPMENT, FACILITY_ID, FLOW, LABEL_TYPE, SHIPMENT_SM,
                "update");
        updateRequest.getUpdateRequestItems().get(0).setAttributes(
                Lists.newArrayList(new com.ekart.facp.unitization.service.dtos.ItemAttribute(
                        WEIGHT.name(), "20.0")));
        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(SHIPMENT)))
                .thenReturn(Lists.newArrayList(shipment));
        when(fsmClient.getNextState("CLOSE", "update", SHIPMENT_SM)).thenReturn("CLOSE");
        when(imsClient.getItemsByIds(FACILITY_ID, Lists.newArrayList(CONTAINER_LABEL)))
                .thenReturn(Lists.newArrayList(container));
        when(specificationClient.getSpecification(any(TenantContext.class), eq(NON_TRANSIENT_CONTAINER_TYPE)))
                .thenReturn(specification);

        unitizationService.updateItem(specificationClient, TENANT, updateRequest);
    }

    @Test
    public void shouldUpdateWeightIfParentContainerIsTransient() {

        bulk = new Item(CONTAINER_LABEL, null, null, TRANSIENT_CONTAINER_TYPE, FACILITY_ID, null, null, null,
                null, null, ImmutableMap.of(UNITIZATION_CURRENT_NO_OF_ITEMS.name(),
                new ItemAttribute(UNITIZATION_CURRENT_NO_OF_ITEMS.name(), "2"), UNITIZATION_IS_TRANSIENT.name(),
                new ItemAttribute(UNITIZATION_IS_TRANSIENT.name(), "true")),
                ImmutableMap.of(BULK_OWNER, new ItemStatus(BULK_OWNER, "OPEN")), ImmutableMap.of(), null, 1L, 1, 1);

        specification.setAttributes(ImmutableMap.of(MAX_WEIGHT.name(), "100.0"));

        shipment = new Item(SHIPMENT, null, null, SHIPMENT_TYPE, CONTAINER_LABEL, null, null, null, null, null,
                ImmutableMap.of(), ImmutableMap.of(SHIPMENT_OWNER, new ItemStatus(SHIPMENT_OWNER, "CLOSE")),
                ImmutableMap.of(), null, 1L, 1, 1);

        updateRequest = createUpdateRequest(SHIPMENT_TYPE, SHIPMENT, FACILITY_ID, FLOW, LABEL_TYPE, SHIPMENT_SM,
                "update");
        updateRequest.getUpdateRequestItems().get(0).setAttributes(
                Lists.newArrayList(new com.ekart.facp.unitization.service.dtos.ItemAttribute(
                        WEIGHT.name(), "20.0")));
        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(SHIPMENT)))
                .thenReturn(Lists.newArrayList(shipment));
        when(fsmClient.getNextState("CLOSE", "update", SHIPMENT_SM)).thenReturn("CLOSE");
        when(imsClient.getItemsByIds(FACILITY_ID, Lists.newArrayList(CONTAINER_LABEL)))
                .thenReturn(Lists.newArrayList(bulk));
        when(specificationClient.getSpecification(any(TenantContext.class), eq(NON_TRANSIENT_CONTAINER_TYPE)))
                .thenReturn(specification);

        unitizationService.updateItem(specificationClient, TENANT, updateRequest);
    }

    @Test
    public void shouldUpdateWeightOfShipmentAndCurrentWeightOfParentContainer() {

        Map<String, ItemAttribute> containerAttribute = Maps.newHashMap();
        containerAttribute.put(UNITIZATION_CURRENT_NO_OF_ITEMS.name(),
                new ItemAttribute(UNITIZATION_CURRENT_NO_OF_ITEMS.name(), 2));
        containerAttribute.put(UNITIZATION_CURRENT_WEIGHT.name(),
                new ItemAttribute(UNITIZATION_CURRENT_WEIGHT.name(), 50.0));
        containerAttribute.put(UNITIZATION_STATE_MACHINE_ID.name(),
                new ItemAttribute(UNITIZATION_STATE_MACHINE_ID.name(), CONTAINER_SM));

        Map<String, ItemAttribute> shipmentAttribute = Maps.newHashMap();
        shipmentAttribute.put(WEIGHT.name(), new ItemAttribute(WEIGHT.name(), 20.0));

        container = new Item(CONTAINER_LABEL, null, null, NON_TRANSIENT_CONTAINER_TYPE, FACILITY_ID, null, null, null,
                null, null, containerAttribute,
                ImmutableMap.of(CONTAINER_OWNER, new ItemStatus(CONTAINER_OWNER, "OPEN")),
                ImmutableMap.of(), null, 1L, 1, 1);
        specification.setAttributes(ImmutableMap.of(MAX_NO_OF_ITEMS.name(), "3"));
        specification.setAttributes(ImmutableMap.of(MAX_WEIGHT.name(), "1000.0"));
        shipment = new Item(SHIPMENT, null, null, SHIPMENT_TYPE, CONTAINER_LABEL, null, null, null, null, null,
                shipmentAttribute, ImmutableMap.of(SHIPMENT_OWNER, new ItemStatus(SHIPMENT_OWNER, "CLOSE")),
                ImmutableMap.of(), null, 1L, 1, 1);

        updateRequest = createUpdateRequest(SHIPMENT_TYPE, SHIPMENT, FACILITY_ID, FLOW, LABEL_TYPE, SHIPMENT_SM,
                "update");
        updateRequest.getUpdateRequestItems().get(0).setAttributes(
                Lists.newArrayList(new com.ekart.facp.unitization.service.dtos.ItemAttribute(
                        WEIGHT.name(), new BigDecimal("200.0"))));
        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(SHIPMENT)))
                .thenReturn(Lists.newArrayList(shipment));
        when(fsmClient.getNextState("CLOSE", "update", SHIPMENT_SM)).thenReturn("CLOSE");
        when(imsClient.getItemsByIds(FACILITY_ID, Lists.newArrayList(CONTAINER_LABEL)))
                .thenReturn(Lists.newArrayList(container));
        when(specificationClient.getSpecification(any(TenantContext.class), eq(NON_TRANSIENT_CONTAINER_TYPE)))
                .thenReturn(specification);

        when(specificationAttributesValidator.getWeightAggregator()).thenReturn(weightAggregator);

        when(weightAggregator.aggregate(container, Lists.newArrayList(shipment), REMOVE,
                specification.getAttributes())).thenReturn(new WeightAggregationResult(new BigDecimal("30.0")));

        //updating the shipment and parent container to decrement weight
        container.getAttributes().put(UNITIZATION_CURRENT_WEIGHT.name(),
                new ItemAttribute(UNITIZATION_CURRENT_WEIGHT.name(), 30.0));
        shipment.getAttributes().put(WEIGHT.name(), new ItemAttribute(WEIGHT.name(), 200.0));

        when(weightAggregator.aggregate(container, Lists.newArrayList(shipment), ADD, specification.getAttributes()))
                .thenReturn(new WeightAggregationResult(new BigDecimal("230.0")));

        //updating the parent container to incremented weight
        container.getAttributes().put(UNITIZATION_CURRENT_WEIGHT.name(),
                new ItemAttribute(UNITIZATION_CURRENT_WEIGHT.name(), 230.0));

        when(imsClient.prepareItemToUpdate(container, ImmutableMap.of(UNITIZATION_CURRENT_WEIGHT.name(),
                new BigDecimal("230.0")), ImmutableMap.of(), ImmutableMap.of()))
                .thenReturn(parentContainerToUpdate);
        when(imsClient.prepareItemToUpdate(shipment, ImmutableMap.of(WEIGHT.name(), new BigDecimal("200.0")),
                ImmutableMap.of(updateRequest.getUpdateRequestItems().get(0).getLabelsToBeAdded().get(0).getType(),
                        updateRequest.getUpdateRequestItems().get(0).getLabelsToBeAdded().get(0).getValue()),
                ImmutableMap.of(SHIPMENT_OWNER, "CLOSE"))).thenReturn(itemToUpdate);
        unitizationService.updateItem(specificationClient, TENANT, updateRequest);

        verify(labelServiceClient).createLabelMapping(TENANT, FACILITY_ID,
                updateRequest.getUpdateRequestItems().get(0).getType(),
                updateRequest.getRequestedBy(),
                updateRequest.getIdempotenceKey(),
                updateRequest.getUpdateRequestItems().get(0).getLabelsToBeAdded());
        verify(imsClient).updateItem(updateRequest, Lists.newArrayList(parentContainerToUpdate, itemToUpdate));
        verify(fsmClient).getNextState("OPEN", ADD_UNITIZABLES, CONTAINER_SM);
    }

    @Test
    public void shouldUpdateWeightOfContainer() {

        container = new Item(CONTAINER_LABEL, null, null, NON_TRANSIENT_CONTAINER_TYPE, FACILITY_ID, null, null, null,
                null, null, ImmutableMap.of(UNITIZATION_CURRENT_NO_OF_ITEMS.name(),
                new ItemAttribute(UNITIZATION_CURRENT_NO_OF_ITEMS.name(), "2"), UNITIZATION_CURRENT_WEIGHT.name(),
                new ItemAttribute(UNITIZATION_CURRENT_WEIGHT.name(), "50.0"), CONTAINER_OWNER,
                new ItemAttribute(CONTAINER_OWNER, "OPEN"), UNITIZATION_STATE_MACHINE_ID.name(),
                new ItemAttribute(UNITIZATION_STATE_MACHINE_ID.name(), CONTAINER_SM)),
                ImmutableMap.of(CONTAINER_OWNER, new ItemStatus(CONTAINER_OWNER, "OPEN")),
                ImmutableMap.of(), null, 1L, 1, 1);
        specification.setAttributes(ImmutableMap.of(MAX_NO_OF_ITEMS.name(), "3"));
        specification.setAttributes(ImmutableMap.of(MAX_WEIGHT.name(), "1000.0"));

        updateRequest = createUpdateRequest(NON_TRANSIENT_CONTAINER_TYPE, CONTAINER_LABEL, FACILITY_ID, FLOW,
                LABEL_TYPE, CONTAINER_SM, "update");
        updateRequest.getUpdateRequestItems().get(0).setAttributes(
                Lists.newArrayList(new com.ekart.facp.unitization.service.dtos.ItemAttribute(
                        WEIGHT.name(), "200.0")));
        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(CONTAINER_LABEL)))
                .thenReturn(Lists.newArrayList(container));
        when(fsmClient.getNextState("OPEN", "update", CONTAINER_SM)).thenReturn("OPEN");
        when(imsClient.getItemsByIds(FACILITY_ID, Lists.newArrayList(CONTAINER_LABEL)))
                .thenReturn(Lists.newArrayList(container));

        when(imsClient.prepareItemToUpdate(container, ImmutableMap.of(WEIGHT.name(), "200.0"), ImmutableMap.of(
                updateRequest.getUpdateRequestItems().get(0).getLabelsToBeAdded().get(0).getType(),
                updateRequest.getUpdateRequestItems().get(0).getLabelsToBeAdded().get(0).getValue()),
                ImmutableMap.of(CONTAINER_OWNER, "OPEN"))).thenReturn(itemToUpdate);
        unitizationService.updateItem(specificationClient, TENANT, updateRequest);

        verify(labelServiceClient).createLabelMapping(TENANT, FACILITY_ID,
                updateRequest.getUpdateRequestItems().get(0).getType(),
                updateRequest.getRequestedBy(),
                updateRequest.getIdempotenceKey(),
                updateRequest.getUpdateRequestItems().get(0).getLabelsToBeAdded());
        verify(imsClient).updateItem(updateRequest, Lists.newArrayList(itemToUpdate));
    }

    @Test
    public void shouldUpdateStateOfContainer() {

        container = new Item(CONTAINER_LABEL, null, null, NON_TRANSIENT_CONTAINER_TYPE, FACILITY_ID, null, null, null,
                null, null, ImmutableMap.of(UNITIZATION_CURRENT_NO_OF_ITEMS.name(),
                new ItemAttribute(UNITIZATION_CURRENT_NO_OF_ITEMS.name(), "2"), UNITIZATION_CURRENT_WEIGHT.name(),
                new ItemAttribute(UNITIZATION_CURRENT_WEIGHT.name(), "50.0"), CONTAINER_OWNER,
                new ItemAttribute(CONTAINER_OWNER, "OPEN"), UNITIZATION_STATE_MACHINE_ID.name(),
                new ItemAttribute(UNITIZATION_STATE_MACHINE_ID.name(), CONTAINER_SM)),
                ImmutableMap.of(CONTAINER_OWNER, new ItemStatus(CONTAINER_OWNER, "OPEN")),
                ImmutableMap.of(), null, 1L, 1, 1);

        specification.setAttributes(ImmutableMap.of(MAX_NO_OF_ITEMS.name(), "3"));
        specification.setAttributes(ImmutableMap.of(MAX_WEIGHT.name(), "1000.0"));

        updateRequest = createUpdateRequest(NON_TRANSIENT_CONTAINER_TYPE, CONTAINER_LABEL, FACILITY_ID, FLOW,
                LABEL_TYPE, CONTAINER_SM, "close");
        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(CONTAINER_LABEL)))
                .thenReturn(Lists.newArrayList(container));
        when(fsmClient.getNextState("OPEN", "close", CONTAINER_SM)).thenReturn("CLOSE");
        when(imsClient.getItemsByIds(FACILITY_ID, Lists.newArrayList(CONTAINER_LABEL)))
                .thenReturn(Lists.newArrayList(container));

        when(imsClient.prepareItemToUpdate(container, ImmutableMap.of(), ImmutableMap.of(
                updateRequest.getUpdateRequestItems().get(0).getLabelsToBeAdded().get(0).getType(),
                updateRequest.getUpdateRequestItems().get(0).getLabelsToBeAdded().get(0).getValue()),
                ImmutableMap.of(CONTAINER_OWNER, "CLOSE"))).thenReturn(itemToUpdate);
        unitizationService.updateItem(specificationClient, TENANT, updateRequest);

        verify(labelServiceClient).createLabelMapping(TENANT, FACILITY_ID,
                updateRequest.getUpdateRequestItems().get(0).getType(),
                updateRequest.getRequestedBy(),
                updateRequest.getIdempotenceKey(),
                updateRequest.getUpdateRequestItems().get(0).getLabelsToBeAdded());
        verify(imsClient).updateItem(updateRequest, Lists.newArrayList(itemToUpdate));
    }

    @Test
    public void shouldAddLabelsToContainer() {

        container = new Item(CONTAINER_LABEL, null, null, NON_TRANSIENT_CONTAINER_TYPE, FACILITY_ID, null, null, null,
                null, null, ImmutableMap.of(UNITIZATION_CURRENT_NO_OF_ITEMS.name(),
                new ItemAttribute(UNITIZATION_CURRENT_NO_OF_ITEMS.name(), "2"), UNITIZATION_CURRENT_WEIGHT.name(),
                new ItemAttribute(UNITIZATION_CURRENT_WEIGHT.name(), "50.0"), CONTAINER_OWNER,
                new ItemAttribute(CONTAINER_OWNER, "OPEN"), UNITIZATION_STATE_MACHINE_ID.name(),
                new ItemAttribute(UNITIZATION_STATE_MACHINE_ID.name(), CONTAINER_SM)),
                ImmutableMap.of(CONTAINER_OWNER, new ItemStatus(CONTAINER_OWNER, "OPEN")),
                ImmutableMap.of(), null, 1L, 1, 1);

        specification.setAttributes(ImmutableMap.of(MAX_NO_OF_ITEMS.name(), "3"));
        specification.setAttributes(ImmutableMap.of(MAX_WEIGHT.name(), "1000.0"));

        updateRequest = createUpdateRequest(NON_TRANSIENT_CONTAINER_TYPE, CONTAINER_LABEL, FACILITY_ID, FLOW,
                LABEL_TYPE, CONTAINER_SM, "close");
        updateRequest.getUpdateRequestItems().get(0).setLabelsToBeAdded(Lists.newArrayList(
                new com.ekart.facp.unitization.service.dtos.ItemLabel("x", "y")));
        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(CONTAINER_LABEL)))
                .thenReturn(Lists.newArrayList(container));
        when(fsmClient.getNextState("OPEN", "close", CONTAINER_SM)).thenReturn("CLOSE");
        when(imsClient.getItemsByIds(FACILITY_ID, Lists.newArrayList(CONTAINER_LABEL)))
                .thenReturn(Lists.newArrayList(container));

        when(imsClient.prepareItemToUpdate(container, ImmutableMap.of(), ImmutableMap.of("x", "y"),
                ImmutableMap.of(CONTAINER_OWNER, "CLOSE"))).thenReturn(itemToUpdate);
        unitizationService.updateItem(specificationClient, TENANT, updateRequest);

        verify(imsClient).updateItem(updateRequest, Lists.newArrayList(itemToUpdate));
    }

    @Test
    public void shouldNotInvokeLabelClientWhenUpdateLabelNotRequired() {

        updateRequest = createUpdateRequest(SHIPMENT_TYPE, SHIPMENT, FACILITY_ID, FLOW, LABEL_TYPE, SHIPMENT_SM,
                "update");
        updateRequest.getUpdateRequestItems().get(0).setAttributes(
                Lists.newArrayList(new com.ekart.facp.unitization.service.dtos.ItemAttribute(
                        WEIGHT.name(), "50.0")));
        //setting labels to null for exception use case
        updateRequest.getUpdateRequestItems().get(0).setLabelsToBeAdded(null);

        shipment = new Item(SHIPMENT, null, null, SHIPMENT_TYPE, FACILITY_ID, null, null, null, null, null,
                ImmutableMap.of(WEIGHT.name(), new ItemAttribute(WEIGHT.name(), "20.0")),
                ImmutableMap.of(SHIPMENT_OWNER, new ItemStatus(SHIPMENT_OWNER, "CLOSE")),
                ImmutableMap.of(), null, 1L, 1, 1);

        when(imsClient.getItemsByLabelTypeAndLabelValues(FACILITY_ID, LABEL_TYPE, Lists.newArrayList(SHIPMENT)))
                .thenReturn(Lists.newArrayList(shipment));
        when(fsmClient.getNextState("CLOSE", "update", SHIPMENT_SM)).thenReturn("CLOSE");
        when(imsClient.prepareItemToUpdate(shipment, ImmutableMap.of(WEIGHT.name(), "50.0"), ImmutableMap.of(),
                ImmutableMap.of(SHIPMENT_OWNER, "CLOSE"))).thenReturn(itemToUpdate);

        unitizationService.updateItem(specificationClient, TENANT, updateRequest);

        verify(labelServiceClient, never()).createLabelMapping(TENANT, FACILITY_ID,
                updateRequest.getUpdateRequestItems().get(0).getType(),
                updateRequest.getRequestedBy(),
                updateRequest.getIdempotenceKey(),
                updateRequest.getUpdateRequestItems().get(0).getLabelsToBeAdded());
        verify(imsClient).updateItem(updateRequest, Lists.newArrayList(itemToUpdate));
    }
}

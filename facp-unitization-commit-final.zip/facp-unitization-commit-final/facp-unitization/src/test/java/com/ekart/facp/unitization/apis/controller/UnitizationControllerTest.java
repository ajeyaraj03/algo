package com.ekart.facp.unitization.apis.controller;

import com.ekart.facp.unitization.apis.dtos.*;
import com.ekart.facp.unitization.apis.mapper.ApiDtoToServiceEntityMapper;
import com.ekart.facp.unitization.service.UnitizationService;
import com.ekart.facp.unitization.service.clients.SpecificationClient;
import com.ekart.facp.unitization.service.dtos.Container;
import com.ekart.facp.unitization.service.entities.Specification;
import com.ekart.facp.unitization.service.utility.ContainerFactory;
import com.ekart.facp.unitization.service.utility.TenantContext;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import static com.ekart.facp.unitization.apis.controller.BaseController.created;
import static com.ekart.facp.unitization.apis.controller.BaseController.ok;
import static com.ekart.facp.unitization.common.enums.ContainerType.DISPENSIBLE;
import static com.ekart.facp.unitization.common.enums.ContainerType.REUSABLE;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;


/**
 * Created by anurag.gupta on 06/06/16.
 */
@RunWith(MockitoJUnitRunner.class)
public class UnitizationControllerTest {

    @Mock
    private SpecificationClient specificationClient;

    @Mock
    private ContainerFactory containerFactory;

    @Mock
    private ApiDtoToServiceEntityMapper mapper;

    @Mock
    private UnitizationService unitizationService;

    @Mock
    private com.ekart.facp.unitization.service.dtos.AddRequest serviceAddRequest;

    @Mock
    private com.ekart.facp.unitization.service.dtos.UpdateRequest serviceUpdateRequest;

    @Mock
    private Container container;

    private ContainerCreateRequest containerCreateRequest;
    private Specification specification;
    private UnitizationController unitizationController;
    private static final String TENANT = "tenant";
    private static final String TYPE = "TYPE";
    private AddRequest addRequest;
    private UpdateRequest updateRequest;
    private UpdateRequestItem updateRequestItem;

    @Before
    public void setUp() throws Exception {
        unitizationController = new UnitizationController(specificationClient, containerFactory, mapper);
        specification = new Specification();
        containerCreateRequest =  new ContainerCreateRequest();
        addRequest = new AddRequest();
        updateRequestItem = new UpdateRequestItem();
        updateRequestItem.setType(TYPE);
        updateRequest = new UpdateRequest();
        updateRequest.setUpdateRequestItems(Lists.newArrayList(updateRequestItem));
    }

    @Test(expected = NullPointerException.class)
    public void shouldRaiseExceptionDuringCreationIfSpecificationValidatorIsNull() {
        new UnitizationController(null, containerFactory, mapper);
    }

    @Test(expected = NullPointerException.class)
    public void shouldRaiseExceptionDuringCreationIfContainerFactoryIsNull() {
        new UnitizationController(specificationClient, null, mapper);
    }

    @Test(expected = NullPointerException.class)
    public void shouldRaiseExceptionDuringCreationIfMapperIsNull() {
        new UnitizationController(specificationClient, containerFactory, null);
    }

    @Test
    public void shouldCreateReusableContainerService() {
        containerCreateRequest.setType(TYPE);
        specification.setReusable(true);

        when(specificationClient.getSpecification(any(TenantContext.class), eq(TYPE))).thenReturn(specification);
        when(containerFactory.getService(REUSABLE)).thenReturn(unitizationService);
        when(mapper.unitizationRequestToContainerServiceEntity(containerCreateRequest)).thenReturn(container);

        ResponseEntity<SuccessResponse> result = unitizationController.createContainer(TENANT,
                containerCreateRequest);
        verify(unitizationService).createContainer(any(TenantContext.class), eq(container));
        assertReflectionEquals(result, created(new SuccessResponse()));
    }

    @Test
    public void shouldCreateDispensibleContainerService() {
        containerCreateRequest.setType(TYPE);
        specification.setReusable(false);

        when(specificationClient.getSpecification(any(TenantContext.class), eq(TYPE))).thenReturn(specification);
        when(containerFactory.getService(DISPENSIBLE)).thenReturn(unitizationService);
        when(mapper.unitizationRequestToContainerServiceEntity(containerCreateRequest)).thenReturn(container);

        ResponseEntity<SuccessResponse> result = unitizationController.createContainer(TENANT,
                containerCreateRequest);
        verify(unitizationService).createContainer(any(TenantContext.class), eq(container));
        assertReflectionEquals(result, created(new SuccessResponse()));
    }

    @Test
    public void shouldAddItemsToReusableContainer() {
        addRequest.setContainerType(TYPE);
        specification.setReusable(true);
        specification.setAttributes(ImmutableMap.of());
        when(specificationClient.getSpecification(any(TenantContext.class), eq(TYPE))).thenReturn(specification);
        when(containerFactory.getService(REUSABLE)).thenReturn(unitizationService);
        when(mapper.apiToServiceUnitizationMoveRequest(addRequest)).thenReturn(serviceAddRequest);

        ResponseEntity<SuccessResponse> result = unitizationController.addUnitizables(TENANT,
                addRequest);
        verify(unitizationService).addUnitizablesToContainer(specification.getAttributes(), serviceAddRequest);
        assertReflectionEquals(result, ok(new SuccessResponse()));
    }

    @Test
    public void shouldAddItemsToDispensibleContainer() {
        addRequest.setContainerType(TYPE);
        specification.setReusable(false);
        specification.setAttributes(ImmutableMap.of());
        when(specificationClient.getSpecification(any(TenantContext.class), eq(TYPE))).thenReturn(specification);
        when(containerFactory.getService(DISPENSIBLE)).thenReturn(unitizationService);
        when(mapper.apiToServiceUnitizationMoveRequest(addRequest)).thenReturn(serviceAddRequest);

        ResponseEntity<SuccessResponse> result = unitizationController.addUnitizables(TENANT,
                addRequest);
        verify(unitizationService).addUnitizablesToContainer(specification.getAttributes(), serviceAddRequest);
        assertReflectionEquals(result, ok(new SuccessResponse()));
    }

    @Test
    public void shouldUpdateReusableContainer() {

        specification.setReusable(true);
        specification.setAttributes(ImmutableMap.of());
        when(specificationClient.getSpecification(any(TenantContext.class), eq(TYPE))).thenReturn(specification);
        when(containerFactory.getService(REUSABLE)).thenReturn(unitizationService);
        when(mapper.apiToServiceUnitizationUpdateRequest(updateRequest)).thenReturn(serviceUpdateRequest);

        ResponseEntity<SuccessResponse> result = unitizationController.updateItem(TENANT,
                updateRequest);
        verify(unitizationService).updateItem(specificationClient, TENANT, serviceUpdateRequest);
        assertReflectionEquals(result, ok(new SuccessResponse()));
    }

    @Test
    public void shouldUpdateDispensibleContainer() {

        specification.setReusable(false);
        specification.setAttributes(ImmutableMap.of());
        when(specificationClient.getSpecification(any(TenantContext.class), eq(TYPE))).thenReturn(specification);
        when(containerFactory.getService(DISPENSIBLE)).thenReturn(unitizationService);
        when(mapper.apiToServiceUnitizationUpdateRequest(updateRequest)).thenReturn(serviceUpdateRequest);

        ResponseEntity<SuccessResponse> result = unitizationController.updateItem(TENANT,
                updateRequest);
        verify(unitizationService).updateItem(specificationClient, TENANT, serviceUpdateRequest);
        assertReflectionEquals(result, ok(new SuccessResponse()));
    }
}

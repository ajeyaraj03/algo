package com.ekart.facp.unitization.service.impl;

import com.ekart.facp.unitization.apis.util.UUIDGenerator;
import com.ekart.facp.unitization.dal.SpecificationRepository;
import com.ekart.facp.unitization.service.entities.Specification;
import com.ekart.facp.unitization.service.entities.SpecificationCreationRequest;
import com.ekart.facp.unitization.service.entities.SpecificationUpdationRequest;
import com.ekart.facp.unitization.service.exceptions.SpecificationCreationFailedException;
import com.ekart.facp.unitization.service.exceptions.SpecificationNotFoundException;
import com.ekart.facp.unitization.service.exceptions.SpecificationFoundException;
import com.ekart.facp.unitization.service.exceptions.SpecificationUpdateFailedException;
import com.ekart.facp.unitization.service.mapper.ServiceEntityToDALModelMapper;
import com.ekart.facp.unitization.service.utility.TenantContext;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import org.joda.time.DateTime;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.dao.DataIntegrityViolationException;

import java.io.IOException;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Supplier;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.*;

/**
 * Created by anuj.chaudhary on 21/04/16.
 */

@RunWith(MockitoJUnitRunner.class)
public class SpecificationServiceImplTest {

    private static final String TENANT = "mockTenant";
    private static final TenantContext TENANT_CONTEXT = new TenantContext(TENANT);
    private static final String TYPE = "mockType";
    @Mock
    private SpecificationRepository specificationRepository;
    @Mock
    private ServiceEntityToDALModelMapper mapper;
    @Mock
    private ObjectMapper objectMapper;
    @Mock
    private ObjectReader objectReader;
    @Mock
    private UUIDGenerator uuidGenerator;
    private String sampleJson;
    private SpecificationServiceImpl specificationService;
    private Supplier<DateTime> dateTimeSupplier;

    @Before
    public void setUp() {
        dateTimeSupplier = currentTimeSupplier();
        specificationService = new SpecificationServiceImpl(specificationRepository, mapper, objectMapper,
                uuidGenerator, dateTimeSupplier);
        sampleJson = "{\"test\": true}";
    }

    @Test
    public void shouldCreateASpecification() {
        SpecificationCreationRequest specification = mock(SpecificationCreationRequest.class);
        com.ekart.facp.unitization.dal.models.Specification specificationModel =
                mock(com.ekart.facp.unitization.dal.models.Specification.class);
        UUID randomId = UUID.randomUUID();

        when(uuidGenerator.generate()).thenReturn(randomId);
        when(mapper.specificationCreateEntityToSpecificationModel(Mockito.anyString(), Mockito.anyString(),
                Mockito.<SpecificationCreationRequest>anyObject(), Mockito.anyString(), Mockito.anyLong(),
                Mockito.anyLong()))
                .thenReturn(specificationModel);

        specificationService.create(TENANT_CONTEXT, specification);
        verify(specificationRepository, times(1)).insertAndFlush(specificationModel);
    }


    @Test(expected = SpecificationFoundException.class)
    public void shouldThrowDuplicateResourceExceptionWhileCreatingExistingActiveSpecification() {
        SpecificationCreationRequest specificationCreationRequest = new SpecificationCreationRequest();
        specificationCreationRequest.setActive(true);
        com.ekart.facp.unitization.dal.models.Specification specificationModel =
                new com.ekart.facp.unitization.dal.models.Specification();
        specificationCreationRequest.setType("kk");
        specificationModel.setTenant(TENANT);
        specificationModel.setActive(true);
        UUID randomId = UUID.randomUUID();

        when(uuidGenerator.generate()).thenReturn(randomId);
        when(mapper.specificationCreateEntityToSpecificationModel(Mockito.anyString(), Mockito.anyString(),
                Mockito.<SpecificationCreationRequest>anyObject(), Mockito.anyString(), Mockito.anyLong(),
                Mockito.anyLong()))
                .thenReturn(specificationModel);
        doThrow(new DataIntegrityViolationException("text")).when(specificationRepository)
                .insertAndFlush(specificationModel);
        when(specificationRepository.findByTenantAndType(TENANT,
                specificationCreationRequest.getType())).thenReturn(specificationModel);

        specificationService.create(TENANT_CONTEXT, specificationCreationRequest);
    }

    @Test(expected = SpecificationCreationFailedException.class)
    public void shouldThrowResourceInactiveExceptionWhileCreatingExistingInactiveSpecification() {
        SpecificationCreationRequest specificationCreationRequest = new SpecificationCreationRequest();
        specificationCreationRequest.setType("kk");
        specificationCreationRequest.setActive(true);
        com.ekart.facp.unitization.dal.models.Specification specificationModel =
                new com.ekart.facp.unitization.dal.models.Specification();
        specificationModel.setTenant(TENANT);
        specificationModel.setActive(false);
        UUID randomId = UUID.randomUUID();

        when(uuidGenerator.generate()).thenReturn(randomId);
        when(mapper.specificationCreateEntityToSpecificationModel(Mockito.anyString(), Mockito.anyString(),
                Mockito.<SpecificationCreationRequest>anyObject(), Mockito.anyString(), Mockito.anyLong(),
                Mockito.anyLong()))
                .thenReturn(specificationModel);
        doThrow(new DataIntegrityViolationException("text")).when(specificationRepository)
                .insertAndFlush(specificationModel);
        when(specificationRepository.findByTenantAndType(TENANT,
                specificationCreationRequest.getType())).thenReturn(specificationModel);

        specificationService.create(TENANT_CONTEXT, specificationCreationRequest);
    }

    @Test
    public void shouldUpdateIfActiveSpecificationExistsAndRequestedSpecificationIsActive() throws IOException {
        SpecificationUpdationRequest specificationUpdationRequest = new SpecificationUpdationRequest();
        specificationUpdationRequest.setActive(true);
        com.ekart.facp.unitization.dal.models.Specification specificationModel = new
                com.ekart.facp.unitization.dal.models.Specification();
        specificationModel.setActive(true);

        when(specificationRepository.findById(specificationUpdationRequest.getId()))
                .thenReturn(Optional.of(specificationModel));
        when(objectMapper.readerForUpdating(specificationModel)).thenReturn(objectReader);
        when(objectMapper.writeValueAsString(specificationUpdationRequest)).thenReturn(sampleJson);
        when(objectReader.readValue(sampleJson)).thenReturn(specificationModel);
        specificationService.update(TENANT_CONTEXT, specificationUpdationRequest);

        verify(specificationRepository, times(1)).saveAndFlush(specificationModel);
    }

    @Test
    public void shouldUpdateIfActiveSpecificationExistsAndRequestedSpecificationIsInactive() throws IOException {
        SpecificationUpdationRequest specificationUpdationRequest = new SpecificationUpdationRequest();
        specificationUpdationRequest.setActive(false);
        com.ekart.facp.unitization.dal.models.Specification specificationModel =
                new com.ekart.facp.unitization.dal.models.Specification();
        specificationModel.setActive(true);

        when(specificationRepository.findById(specificationUpdationRequest.getId()))
                .thenReturn(Optional.of(specificationModel));
        when(objectMapper.readerForUpdating(specificationModel)).thenReturn(objectReader);
        when(objectMapper.writeValueAsString(specificationUpdationRequest)).thenReturn(sampleJson);
        when(objectReader.readValue(sampleJson)).thenReturn(specificationModel);
        specificationService.update(TENANT_CONTEXT, specificationUpdationRequest);

        verify(specificationRepository, times(1)).saveAndFlush(specificationModel);
    }

    @Test
    public void shouldUpdateIfInactiveSpecificationExistsAndRequestedSpecificationIsActive() throws IOException {
        SpecificationUpdationRequest specificationUpdationRequest = new SpecificationUpdationRequest();
        specificationUpdationRequest.setActive(true);
        com.ekart.facp.unitization.dal.models.Specification specificationModelBeforeUpdate =
                new com.ekart.facp.unitization.dal.models.Specification();
        specificationModelBeforeUpdate.setActive(false);

        com.ekart.facp.unitization.dal.models.Specification specificationModelAfterUpdate =
                new com.ekart.facp.unitization.dal.models.Specification();
        specificationModelAfterUpdate.setActive(true);

        when(specificationRepository.findById(specificationUpdationRequest.getId()))
                .thenReturn(Optional.of(specificationModelBeforeUpdate));
        when(objectMapper.readerForUpdating(specificationModelBeforeUpdate)).thenReturn(objectReader);
        when(objectMapper.writeValueAsString(specificationUpdationRequest)).thenReturn(sampleJson);
        when(objectReader.readValue(sampleJson)).thenReturn(specificationModelAfterUpdate);
        specificationService.update(TENANT_CONTEXT, specificationUpdationRequest);

        verify(specificationRepository, times(1)).saveAndFlush(specificationModelAfterUpdate);
    }

    @Test
    public void shouldUpdateIfActiveSpecificationExistsAndRequestedSpecificationDoesNotHasActiveValue()
            throws IOException {
        SpecificationUpdationRequest specificationUpdationRequest = new SpecificationUpdationRequest();
        com.ekart.facp.unitization.dal.models.Specification specificationModel =
                new com.ekart.facp.unitization.dal.models.Specification();
        specificationModel.setActive(true);

        when(specificationRepository.findById(specificationUpdationRequest.getId()))
                .thenReturn(Optional.of(specificationModel));
        when(objectMapper.readerForUpdating(specificationModel)).thenReturn(objectReader);
        when(objectMapper.writeValueAsString(specificationUpdationRequest)).thenReturn(sampleJson);
        when(objectReader.readValue(sampleJson)).thenReturn(specificationModel);
        specificationService.update(TENANT_CONTEXT, specificationUpdationRequest);

        verify(specificationRepository, times(1)).saveAndFlush(specificationModel);
    }

    @Test(expected = SpecificationUpdateFailedException.class)
    public void shouldThrowResourceUpdationExceptionWhenErrorInJsonConversion() throws IOException {
        SpecificationUpdationRequest specificationUpdationRequest = new SpecificationUpdationRequest();
        specificationUpdationRequest.setActive(true);
        com.ekart.facp.unitization.dal.models.Specification specificationModel =
                new com.ekart.facp.unitization.dal.models.Specification();
        specificationModel.setActive(true);
        when(specificationRepository.findById(specificationUpdationRequest.getId())).thenReturn(
                Optional.of(specificationModel));
        when(objectMapper.readerForUpdating(specificationModel)).thenReturn(objectReader);
        when(objectMapper.writeValueAsString(specificationUpdationRequest)).thenThrow(
                new JsonGenerationException("someException"));
        specificationService.update(TENANT_CONTEXT, specificationUpdationRequest);
    }

    @Test(expected = SpecificationNotFoundException.class)
    public void shouldThrowResourceDoesNotExistsExceptionWhileUpdateIfTheSpecificationDoesNotExists() {
        SpecificationUpdationRequest specificationUpdationRequest = new SpecificationUpdationRequest();
        when(specificationRepository.findById(specificationUpdationRequest.getId())).thenReturn(Optional.empty());

        specificationService.update(TENANT_CONTEXT, specificationUpdationRequest);
    }

    @Test
    public void shouldDeleteTheSpecificationIfExists() {
        String specificationId = "specificationId";
        com.ekart.facp.unitization.dal.models.Specification specificationModelBefore =
                new com.ekart.facp.unitization.dal.models.Specification();
        specificationModelBefore.setActive(true);
        specificationModelBefore.setArchived(false);

        when(specificationRepository.findById(specificationId)).thenReturn(Optional.of(specificationModelBefore));
        specificationModelBefore.setArchived(true);
        specificationService.remove(TENANT_CONTEXT, specificationId);

        verify(specificationRepository).saveAndFlush(specificationModelBefore);
    }

    @Test(expected = SpecificationNotFoundException.class)
    public void shouldThrowResourceDoesNotExistsExceptionWhileDeleteIfTheSpecificationDoesNotExists() {
        String specificationId = "specificationId";
        when(specificationRepository.findById(specificationId)).thenReturn(Optional.empty());

        specificationService.remove(TENANT_CONTEXT, specificationId);
    }

    @Test(expected = SpecificationNotFoundException.class)
    public void shouldReturnEmptyIfSpecificationIsNotPresent() {
        String specificationId = "id";

        when(specificationRepository.findById(specificationId)).thenReturn(Optional.empty());

        specificationService.get(TENANT_CONTEXT, specificationId);
    }

    @Test
    public void shouldReturnSpecificationIfPresent() {
        String specificationId = "id";
        com.ekart.facp.unitization.dal.models.Specification specificationModel =
                mock(com.ekart.facp.unitization.dal.models.Specification.class);
        Specification specification = mock(Specification.class);

        when(mapper.specificationModelToSpecification(specificationModel)).thenReturn(specification);
        when(specificationRepository.findById(specificationId)).thenReturn(Optional.of(specificationModel));

        assertThat(specificationService.get(TENANT_CONTEXT, specificationId), is(specification));
    }

    @Test
    public void shouldReturnSpecificationIfActiveSpecificationExistsForGivenTenantAndType() {
        com.ekart.facp.unitization.dal.models.Specification specificationModel = new
                com.ekart.facp.unitization.dal.models.Specification();
        specificationModel.setActive(true);
        Specification specification = mock(Specification.class);

        when(mapper.specificationModelToSpecification(specificationModel)).thenReturn(specification);
        when(specificationRepository.findByTenantAndType(TENANT, TYPE)).thenReturn(specificationModel);

        assertThat(specificationService.getByType(TENANT_CONTEXT, TYPE), is(specification));
    }

    @Test(expected = SpecificationNotFoundException.class)
    public void shouldThrowErrorIfSpecificationDoesNotExistsForGivenTenantAndType() {
        when(specificationRepository.findByTenantAndType(TENANT, TYPE)).thenReturn(null);

        specificationService.getByType(TENANT_CONTEXT, TYPE);
    }


    @Test
    public void shouldReturnSpecificationIfInactiveSpecificationExistsForGivenTenantAndType() {
        com.ekart.facp.unitization.dal.models.Specification specificationModel = new
                com.ekart.facp.unitization.dal.models.Specification();
        specificationModel.setActive(false);
        Specification specification = mock(Specification.class);

        when(specificationRepository.findByTenantAndType(TENANT, TYPE)).thenReturn(specificationModel);
        when(mapper.specificationModelToSpecification(specificationModel)).thenReturn(specification);

        assertThat(specificationService.getInactiveByType(TENANT_CONTEXT, TYPE), is(specification));
    }

    @Test(expected = SpecificationNotFoundException.class)
    public void shouldReturnSpecificationIfInactiveSpecificationExistsForGivenTenantAndType1() {
        com.ekart.facp.unitization.dal.models.Specification specificationModel = new
                com.ekart.facp.unitization.dal.models.Specification();
        specificationModel.setActive(true);
        Specification specification = mock(Specification.class);

        when(specificationRepository.findByTenantAndType(TENANT, TYPE)).thenReturn(specificationModel);
        assertThat(specificationService.getInactiveByType(TENANT_CONTEXT, TYPE), is(specification));
    }

    private Supplier<DateTime> currentTimeSupplier() {

        return () -> new DateTime();
    }
}

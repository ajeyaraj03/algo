package com.ekart.facp.unitization.service.validator;

import static com.ekart.facp.unitization.common.enums.Operands.*;
import com.ekart.facp.unitization.service.RuleService;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.Item;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.ItemAttribute;
import com.ekart.facp.unitization.service.exceptions.NumberOfItemsExceededException;
import com.ekart.facp.unitization.service.validators.NumberOfItemsAggregator;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import java.util.Map;
import static com.ekart.facp.unitization.common.enums.clients.ims.AttributeName.MAX_NO_OF_ITEMS;
import static com.ekart.facp.unitization.common.enums.clients.ims.AttributeName.UNITIZATION_CURRENT_NO_OF_ITEMS;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;

/**
 * Created by avinash.r on 07/08/16.
 */

@RunWith(MockitoJUnitRunner.class)
public class NumberOfItemsAggregatorTest {

    private NumberOfItemsAggregator aggregator;
    private Item shipment;
    private Item container;
    private Map<String, String> specificationAttributes;

    @Mock
    private RuleService ruleService;

    @Before
    public void setup() {

        aggregator = new NumberOfItemsAggregator(ruleService);
        shipment = new Item("shipment", null, null, "shipmentType", "facilityId", null, null, null, null, null,
                ImmutableMap.of(), ImmutableMap.of(), ImmutableMap.of(), null, 1L, 1, 1);
        container = new Item("container", null, null, "containerType", "facilityId", null, null, null, null, null,
                ImmutableMap.of(UNITIZATION_CURRENT_NO_OF_ITEMS.name(),
                        new ItemAttribute(UNITIZATION_CURRENT_NO_OF_ITEMS.name(), 5)),
                ImmutableMap.of(), ImmutableMap.of(), null, 1L, 1, 1);
    }

    @Test(expected = NumberOfItemsExceededException.class)
    public void shouldThrowErrorIfNumberOfItemsExceededWhileAddingItemToContainer() {

        specificationAttributes = ImmutableMap.of(MAX_NO_OF_ITEMS.name(), "5");
        when(ruleService.maxNoOfItemsRule(specificationAttributes, 6)).thenReturn(false);
        aggregator.aggregate(container, Lists.newArrayList(shipment), ADD, specificationAttributes);
    }

    @Test(expected = NumberOfItemsExceededException.class)
    public void shouldThrowErrorIfNumberOfItemsExceededWhileRemovingItemFromContainer() {

        specificationAttributes = ImmutableMap.of(MAX_NO_OF_ITEMS.name(), "3");
        when(ruleService.maxNoOfItemsRule(specificationAttributes, 4)).thenReturn(false);
        aggregator.aggregate(container, Lists.newArrayList(shipment), REMOVE, specificationAttributes);
    }

    @Test
    public void shouldReturnAggregatedWeightOfContainerWhileAddingItemToContainer() {

        specificationAttributes = ImmutableMap.of(MAX_NO_OF_ITEMS.name(), "6");
        when(ruleService.maxNoOfItemsRule(specificationAttributes, 6)).thenReturn(true);
        assertThat(aggregator.aggregate(container, Lists.newArrayList(shipment), ADD, specificationAttributes)
                .getNoOfItemsToUpdate(), is(6L));
    }

    @Test
     public void shouldReturnAggregatedWeightOfContainerWhileRemovingItemToContainer() {

        specificationAttributes = ImmutableMap.of(MAX_NO_OF_ITEMS.name(), "5");
        when(ruleService.maxNoOfItemsRule(specificationAttributes, 4)).thenReturn(true);
        assertThat(aggregator.aggregate(container, Lists.newArrayList(shipment), REMOVE, specificationAttributes)
                .getNoOfItemsToUpdate(), is(4L));
    }

    @Test
    public void shouldReturnTotalItemsInContainerWhileRemovingItemToContainerAndSpecificationIsNotPresent() {

        assertThat(aggregator.aggregate(container, Lists.newArrayList(shipment), REMOVE, ImmutableMap.of())
                .getNoOfItemsToUpdate(), is(4L));
    }
}

package com.ekart.facp.unitization.apis.controller;

import com.ekart.facp.unitization.apis.BaseIntegrationTest;
import com.ekart.facp.unitization.apis.dtos.ContainerCreateRequest;
import com.ekart.facp.unitization.apis.dtos.ErrorMessage;
import com.ekart.facp.unitization.apis.dtos.Label;
import com.ekart.facp.unitization.apis.dtos.SuccessResponse;
import com.ekart.facp.unitization.service.dtos.clients.label_service.request.LabelMapping;
import com.ekart.facp.unitization.service.dtos.clients.label_service.request.LabelMappingCreateRequest;
import com.ekart.facp.unitization.service.dtos.clients.label_service.response.LabelMappingCreateResponse;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.GetItemResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.ResponseEntity;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

import static com.ekart.facp.unitization.apis.UnitizationTestUtils.containerCreateRequest;
import static com.ekart.facp.unitization.apis.UnitizationTestUtils.newlabelMappingCreateRequest;
import static com.ekart.facp.unitization.common.ErrorCode.*;
import static junit.framework.TestCase.assertFalse;
import static com.ekart.facp.unitization.apis.UnitizationTestUtils.objectMapper;
import static org.apache.commons.lang.RandomStringUtils.randomAlphanumeric;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertTrue;

/**
 * Created by anurag.gupta on 08/06/16.
 */
public class UnitizationControllerIntegrationTest extends BaseIntegrationTest {

    private final String tenant = randomAlphanumeric(10);
    private final String rootContainerId = randomAlphanumeric(32);
    private final String rootContainerItemType = randomAlphanumeric(32);
    private final String itemTypeReusable = randomAlphanumeric(10);
    private final String itemTypeDispensible = randomAlphanumeric(10);
    private final List<String> rootContainerContainedTypes = Lists.newArrayList(itemTypeReusable, itemTypeDispensible);
    private final ObjectMapper objectMapper = objectMapper();

    @Before
    public void setUp() throws IOException {
        API.createItemTypes(itemTypeReusable, itemTypeDispensible, rootContainerItemType, rootContainerContainedTypes);
        API.createSpecifications(tenant, itemTypeReusable, itemTypeDispensible);
        API.createRootContainer(rootContainerId, rootContainerItemType);
        assertTrue(validateRootContainerCreation(rootContainerId, rootContainerItemType));
    }

    @Test
    public void shouldReturn400IfAppIdIsAbsentWhileCreatingContainer() {
        ContainerCreateRequest containerCreateRequest = containerCreateRequest(rootContainerId, itemTypeDispensible);
        containerCreateRequest.setAppId(null);

        assertBadRequest(API.createContainer(tenant, containerCreateRequest, ErrorMessage.class),
                VALIDATION_ERROR.name(), "[NotNull.containerCreateRequest.appId: appId cannot be null or empty.]");
    }

    @Test
    public void shouldReturn400IfContainerIdIsAbsentWhileCreatingContainer() {
        ContainerCreateRequest containerCreateRequest = containerCreateRequest(rootContainerId, itemTypeDispensible);
        containerCreateRequest.setContainerId(null);

        assertBadRequest(API.createContainer(tenant, containerCreateRequest, ErrorMessage.class),
                VALIDATION_ERROR.name(),
                "[NotNull.containerCreateRequest.containerId: containerId cannot be null or empty.]");
    }

    @Test
    public void shouldReturn400IfCreatedByDocumentIdIsAbsentWhileCreatingContainer() {
        ContainerCreateRequest containerCreateRequest = containerCreateRequest(rootContainerId, itemTypeDispensible);
        containerCreateRequest.setCreatedByDocumentId(null);

        assertBadRequest(API.createContainer(tenant, containerCreateRequest, ErrorMessage.class),
                VALIDATION_ERROR.name(), "[NotNull.containerCreateRequest.createdByDocumentId: createdByDocumentId "
                        + "cannot be null or empty.]");
    }

    @Test
    public void shouldReturn400IfCreatedByDocumentTypeIsAbsentWhileCreatingContainer() {
        ContainerCreateRequest containerCreateRequest = containerCreateRequest(rootContainerId, itemTypeDispensible);
        containerCreateRequest.setCreatedByDocumentType(null);

        assertBadRequest(API.createContainer(tenant, containerCreateRequest, ErrorMessage.class),
                VALIDATION_ERROR.name(), "[NotNull.containerCreateRequest.createdByDocumentType: createdByDocumentType "
                        + "cannot be null or empty.]");
    }

    @Test
    public void shouldReturn400IfCreatedByEntityIdIsAbsentInHeadersWhileCreatingContainer() {
        ContainerCreateRequest containerCreateRequest = containerCreateRequest(rootContainerId, itemTypeDispensible);
        containerCreateRequest.setCreatedByEntityId(null);

        assertBadRequest(API.createContainer(tenant, containerCreateRequest, ErrorMessage.class),
                VALIDATION_ERROR.name(), "[NotNull.containerCreateRequest.createdByEntityId: createdByEntityId "
                        + "cannot be null or empty.]");
    }

    @Test
    public void shouldReturn400IfCreatedByEntityTypeIsAbsentWhileCreatingContainer() {
        ContainerCreateRequest containerCreateRequest = containerCreateRequest(rootContainerId, itemTypeDispensible);
        containerCreateRequest.setCreatedByEntityType(null);

        assertBadRequest(API.createContainer(tenant, containerCreateRequest, ErrorMessage.class),
                VALIDATION_ERROR.name(), "[NotNull.containerCreateRequest.createdByEntityType: createdByEntityType "
                        + "cannot be null or empty.]");
    }

    @Test
    public void shouldReturn400IfFacilityIdIsAbsentWhileCreatingContainer() {
        ContainerCreateRequest containerCreateRequest = containerCreateRequest(rootContainerId, itemTypeDispensible);
        containerCreateRequest.setFacilityId(null);

        assertBadRequest(API.createContainer(tenant, containerCreateRequest, ErrorMessage.class),
                VALIDATION_ERROR.name(), "[NotNull.containerCreateRequest.facilityId: facilityId "
                        + "cannot be null or empty.]");
    }

    @Test
    public void shouldReturn400IfIdempotenceKeyIsAbsentWhileCreatingContainer() {
        ContainerCreateRequest containerCreateRequest = containerCreateRequest(rootContainerId, itemTypeDispensible);
        containerCreateRequest.setIdempotenceKey(null);

        assertBadRequest(API.createContainer(tenant, containerCreateRequest, ErrorMessage.class),
                VALIDATION_ERROR.name(), "[NotNull.containerCreateRequest.idempotenceKey: idempotenceKey "
                        + "cannot be null or empty.]");
    }

    @Test
    public void shouldReturn400IfStateMachineIdIsAbsentWhileCreatingContainer() {
        ContainerCreateRequest containerCreateRequest = containerCreateRequest(rootContainerId, itemTypeDispensible);
        containerCreateRequest.setStateMachineId(null);

        assertBadRequest(API.createContainer(tenant, containerCreateRequest, ErrorMessage.class),
                VALIDATION_ERROR.name(), "[NotNull.containerCreateRequest.stateMachineId: stateMachineId "
                        + "cannot be null or empty.]");
    }

    @Test
    public void shouldReturn400IfFlowContextIsAbsentWhileCreatingContainer() {
        ContainerCreateRequest containerCreateRequest = containerCreateRequest(rootContainerId, itemTypeDispensible);
        containerCreateRequest.setFlowContext(null);

        assertBadRequest(API.createContainer(tenant, containerCreateRequest, ErrorMessage.class),
                VALIDATION_ERROR.name(), "[NotNull.containerCreateRequest.flowContext: flowContext "
                        + "cannot be null or empty.]");
    }

    @Test
    public void shouldReturn400IfTypeIsAbsentWhileCreatingContainer() {
        ContainerCreateRequest containerCreateRequest = containerCreateRequest(rootContainerId, itemTypeDispensible);
        containerCreateRequest.setType(null);

        assertBadRequest(API.createContainer(tenant, containerCreateRequest, ErrorMessage.class),
                VALIDATION_ERROR.name(), "[NotNull.containerCreateRequest.type: type "
                        + "cannot be null or empty.]");
    }

    @Test
    public void shouldReturn400IfUomIsAbsentWhileCreatingContainer() {
        ContainerCreateRequest containerCreateRequest = containerCreateRequest(rootContainerId, itemTypeDispensible);
        containerCreateRequest.setUom(null);

        assertBadRequest(API.createContainer(tenant, containerCreateRequest, ErrorMessage.class),
                VALIDATION_ERROR.name(), "[NotNull.containerCreateRequest.uom: uom "
                        + "cannot be null or empty.]");
    }

    @Test
    public void shouldReturn400IfAttributesIsAbsentWhileCreatingContainer() {
        ContainerCreateRequest containerCreateRequest = containerCreateRequest(rootContainerId, itemTypeDispensible);
        containerCreateRequest.setAttributes(null);

        assertBadRequest(API.createContainer(tenant, containerCreateRequest, ErrorMessage.class),
                VALIDATION_ERROR.name(), "[NotEmpty.containerCreateRequest.attributes: attributes "
                        + "cannot be null or empty.]");
    }

    @Test
    public void shouldReturn400IfLabelIsAbsentWhileCreatingContainer() {
        ContainerCreateRequest containerCreateRequest = containerCreateRequest(rootContainerId, itemTypeDispensible);
        containerCreateRequest.setLabel(null);

        assertBadRequest(API.createContainer(tenant, containerCreateRequest, ErrorMessage.class),
                VALIDATION_ERROR.name(), "[NotNull.containerCreateRequest.label: label "
                        + "cannot be null or empty.]");
    }

    @Test
    public void shouldReturn400IfSpecificationWithTenantDoesnotExist() {
        String unknownTenant = "unknownTenant";
        ContainerCreateRequest containerCreateRequest = containerCreateRequest(rootContainerId, itemTypeDispensible);

        assertBadRequest(API.createContainer(unknownTenant, containerCreateRequest, ErrorMessage.class),
                SPECIFICATION_NOT_FOUND.name(), "The Specification identified by tenant: " +  unknownTenant
                + "  and type " + itemTypeDispensible + " was not found");
    }

    @Test
    public void shouldReturn400IfSpecificationWithTypeDoesnotExist() {
        String unknownType = "unknownType";
        ContainerCreateRequest containerCreateRequest = containerCreateRequest(rootContainerId, unknownType);

        assertBadRequest(API.createContainer(tenant, containerCreateRequest, ErrorMessage.class),
                SPECIFICATION_NOT_FOUND.name(), "The Specification identified by tenant: " +  tenant
                        + "  and type " + unknownType + " was not found");
    }

    @Test
    public void shouldReturn400IfStateMachineIdDoesnotExist() {
        String unknownStateMachineId = "unknownStateMachineId";
        ContainerCreateRequest containerCreateRequest = containerCreateRequest(rootContainerId, itemTypeDispensible);
        containerCreateRequest.setStateMachineId(unknownStateMachineId);

        assertBadRequest(API.createContainer(tenant, containerCreateRequest, ErrorMessage.class),
                INVALID_STATE_MACHINE_EXCEPTION.name(), "Invalid StateMachine: " + unknownStateMachineId);
    }

    @Test
    public void shouldCreateDispensibleContainer() throws IOException {
        String labelType = randomAlphanumeric(8);
        String labelValue = randomAlphanumeric(8);
        Label label = new Label();
        label.setType(labelType);
        label.setValue(labelValue);
        ContainerCreateRequest request = containerCreateRequest(rootContainerId, itemTypeDispensible, label);

        assertCreated(API.createContainer(tenant, request, SuccessResponse.class));
        ResponseEntity<String> response = API.getItemFromImsByLabel(rootContainerId, label);
        GetItemResponse itemResponse = objectMapper.readValue(response.getBody(), GetItemResponse.class);
        assertOk(response);
        assertTrue(API.validateCreateContainerResponse(itemResponse, request));
        assertFalse(API.getSpecificationByType(tenant, itemTypeDispensible).getBody().isReusable());
    }

    @Test
    public void shouldCreateReusableContainer() throws IOException {
        String labelType = randomAlphanumeric(8);
        String labelValue = randomAlphanumeric(8);
        Label label = new Label();
        label.setType(labelType);
        label.setValue(labelValue);
        ContainerCreateRequest request = containerCreateRequest(rootContainerId, itemTypeReusable, label);

        assertCreated(API.createContainer(tenant, request, SuccessResponse.class));
        ResponseEntity<String> response = API.getItemFromImsByLabel(rootContainerId, label);
        GetItemResponse itemResponse = objectMapper.readValue(response.getBody(), GetItemResponse.class);
        assertOk(response);
        assertTrue(API.validateCreateContainerResponse(itemResponse, request));
        assertTrue(API.getSpecificationByType(tenant, itemTypeReusable).getBody().isReusable());
    }

    @Test
    public void shouldThrowImsClientExceptionWhenContainerIsCreatedWithUnknownContainerType() {
        String unknownRootContainer = "unknowRootContainer";

        assertBadRequest(API.createContainer(tenant, containerCreateRequest(unknownRootContainer, itemTypeReusable),
                ErrorMessage.class), IMS_BAD_REQUEST_EXCEPTION.name(),
                "The items/containers: [" + unknownRootContainer + "] were not found");
    }

    @Test
    public void shouldReturnTheSameResponseForSameIdempotenceKey() {
        String idempotenceKey = randomAlphanumeric(10);
        ContainerCreateRequest request = containerCreateRequest(rootContainerId, itemTypeDispensible, idempotenceKey);

        assertCreated(API.createContainer(tenant, request, SuccessResponse.class));
        assertCreated(API.createContainer(tenant, request, SuccessResponse.class));
    }

    /*label serivce testcases */

    @Test
    public void shouldThrowErrorIfDispensibleContainerWithSameLabelAlreadyExists() {
        String labelType = randomAlphanumeric(8);
        String labelValue = randomAlphanumeric(8);
        String idempotenceKey = UUID.randomUUID().toString();
        Label label = new Label();
        label.setType(labelType);
        label.setValue(labelValue);
        LabelMapping labelMap = new LabelMapping(idempotenceKey, labelType, labelValue);

        LabelMappingCreateRequest createLabelRequest = newlabelMappingCreateRequest(labelMap);
        ResponseEntity<LabelMappingCreateResponse> response = API.createLabelInLabelService(createLabelRequest,
                rootContainerId, itemTypeDispensible, tenant);

        assertTrue(API.validateLabelCreationResponse(response, rootContainerId, labelType, labelValue,
                itemTypeDispensible));

        ContainerCreateRequest createContainerRequest = containerCreateRequest(rootContainerId,
                itemTypeDispensible, label);

        assertBadRequest(API.createContainer(tenant, createContainerRequest, ErrorMessage.class),
                LABEL_ALREADY_EXISTS.name(),
                "Cannot create a mapping as mapping for the label(s) {" + labelType + "=" + labelValue
                        + "} already exists");
    }

    @Test
    public void shouldThrowErrorIfReusableContainerWithSameLabelAlreadyExists() throws IOException {
        String labelType = randomAlphanumeric(8);
        String labelValue = randomAlphanumeric(8);
        Label label = new Label();
        label.setType(labelType);
        label.setValue(labelValue);
        ContainerCreateRequest createContainerRequest1 = containerCreateRequest(rootContainerId,
                itemTypeReusable, label);

        assertCreated(API.createContainer(tenant, createContainerRequest1, SuccessResponse.class));
        ResponseEntity<String> response = API.getItemFromImsByLabel(rootContainerId, label);
        GetItemResponse itemResponse = objectMapper.readValue(response.getBody(), GetItemResponse.class);
        assertOk(response);
        assertTrue(API.validateCreateContainerResponse(itemResponse, createContainerRequest1));
        assertTrue(API.getSpecificationByType(tenant, itemTypeReusable).getBody().isReusable());

        ContainerCreateRequest createContainerRequest2 = containerCreateRequest(rootContainerId,
                itemTypeReusable, label);
        assertBadRequest(API.createContainer(tenant, createContainerRequest2, ErrorMessage.class),
                CONTAINER_ALREADY_EXISTS.name(),
                "Container with label type: " + labelType + " and label value :" + labelValue
                        + " already exists in status: OPEN");
    }

    @Test
    public void shouldCreateContainerSuccesfullyDuringTheSecondRequestButFailsInitiallyWithTheSameIdempotenceKey()
            throws IOException {
        String labelType = randomAlphanumeric(8);
        String labelValue = randomAlphanumeric(8);
        Label label = new Label();
        label.setType(labelType);
        label.setValue(labelValue);
        String unknownRootContainerId = randomAlphanumeric(8);
        String idempotenceKey = randomAlphanumeric(10);
        ContainerCreateRequest request1 = containerCreateRequest(unknownRootContainerId, itemTypeDispensible,
                idempotenceKey, label);
        ContainerCreateRequest request2 = containerCreateRequest(rootContainerId, itemTypeDispensible,
                idempotenceKey, label);

        assertBadRequest(API.createContainer(tenant, request1, ErrorMessage.class), IMS_BAD_REQUEST_EXCEPTION.name(),
                "The items/containers: [" + unknownRootContainerId + "] were not found");
        assertCreated(API.createContainer(tenant, request2, SuccessResponse.class));

        ResponseEntity<String> response = API.getItemFromImsByLabel(rootContainerId, label);

        GetItemResponse itemResponse = objectMapper.readValue(response.getBody(), GetItemResponse.class);
        assertOk(response);
        assertTrue(API.validateCreateContainerResponse(itemResponse, request2));
    }

    private boolean validateRootContainerCreation(String rootContainerId, String rootContainertemType)
            throws IOException {
        ResponseEntity<String> response = API.getItemFromImsById(rootContainerId, rootContainerId);
        GetItemResponse itemResponse = objectMapper.readValue(response.getBody(), GetItemResponse.class);
        assertThat(itemResponse.getItems().get(0).getContainerId(), is(rootContainerId));
        assertThat(itemResponse.getItems().get(0).getType(), is(rootContainertemType));
        assertThat(itemResponse.getItems().get(0).getId(), is(rootContainerId));
        return true;
    }
}


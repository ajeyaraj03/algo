package com.ekart.facp.unitization.apis.controller;

import com.ekart.facp.unitization.apis.BaseIntegrationTest;
import com.ekart.facp.unitization.apis.dtos.*;

import static com.ekart.facp.unitization.apis.constants.ApiConstants.MAX_UNITIZABLES_TO_BE_ADDED;
import static com.ekart.facp.unitization.common.enums.clients.ims.AttributeName.*;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.GetItemResponse;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.Item;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.ItemAttribute;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import static com.ekart.facp.unitization.apis.TestUtils.newSpecificationCreateRequest;
import static com.ekart.facp.unitization.apis.UnitizationTestUtils.*;
import static com.ekart.facp.unitization.common.ErrorCode.*;
import static org.apache.commons.lang.RandomStringUtils.randomAlphabetic;
import static org.apache.commons.lang.RandomStringUtils.randomAlphanumeric;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

/**
* Created by avinash.r on 13/07/16.
*/

public class UnitizationAddItemIntegrationTest extends BaseIntegrationTest {

    private final String clientId = randomAlphanumeric(20);
    private final String rootContainerId = randomAlphanumeric(20);
    private final String rootContainerItemType = randomAlphanumeric(20);
    private final String containerType = randomAlphanumeric(20);
    private final String transientContainerType = randomAlphanumeric(20);
    private final String itemType = randomAlphanumeric(20);
    private final String randomType = randomAlphanumeric(20);
    private final String itemLabelType = randomAlphanumeric(20);
    private final String containerLabelType = randomAlphanumeric(20);
    private final String transientContainerLabelType = randomAlphanumeric(20);
    private static final String CONTAINER_LABEL = randomAlphanumeric(20);
    private static final String BULK = randomAlphanumeric(20);
    private String containerId;
    private AddRequest addRequest;
    private final ObjectMapper objectMapper = objectMapper();

    @Before
    public void setUp() throws IOException {

        // Items with labels S1,S2,S3 with same random type have weights
        createSpecifications();
        createContainersAndTypes();
        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "flow",
                "stateMachine", createUnitizableRequests(itemLabelType, "stateMachine", "unitizableLabel"));
    }

    //api validation test cases
    @Test
    public void shouldThrow400IfIdempotenceKeyIsNotPresentInRequest() {
        addRequest.setIdempotenceKey(null);
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class), VALIDATION_ERROR.name(),
                "[NotNull.addRequest.idempotenceKey: idempotenceKey cannot be null or empty.]");
    }

    @Test
    public void shouldThrow400IfContainerLabelIsNotPresentInRequest() {

        addRequest.setContainerLabel(null);
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class), VALIDATION_ERROR.name(),
                "[NotNull.addRequest.containerLabel: containerLabel can not be null.]");
    }

    @Test
    public void shouldThrow400IfContainerLabelTypeIsNotPresentInRequest() {

        addRequest.setContainerLabelType(null);
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class), VALIDATION_ERROR.name(),
                "[NotNull.addRequest.containerLabelType: containerLabelType can not be null.]");
    }

    @Test
    public void shouldThrow400IfContainerTypeIsNotPresentInRequest() {

        addRequest.setContainerType(null);
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class), VALIDATION_ERROR.name(),
                "[NotNull.addRequest.containerType: containerType can not be null.]");
    }

    @Test
    public void shouldThrow400IfRequestedByIsNotPresentInRequest() {

        addRequest.setRequestedBy(null);
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class), VALIDATION_ERROR.name(),
                "[NotNull.addRequest.requestedBy: requestedBy can not be null.]");
    }

    @Test
    public void shouldThrow400IfFacilityIdIsNotPresentInRequest() {

        addRequest.setFacilityId(null);
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class), VALIDATION_ERROR.name(),
                "[NotNull.addRequest.facilityId: facilityId cannot be null or empty.]");
    }

    @Test
    public void shouldThrow400IfAppIdIsNotPresentInRequest() {

        addRequest.setAppId(null);
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class), VALIDATION_ERROR.name(),
                "[NotNull.addRequest.appId: appId cannot be null or empty.]");
    }

    @Test
    public void shouldThrow400IfUnitizableLabelIsNotPresentInRequest() {

        addRequest.getUnitizables().get(0).setLabel(null);
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class), VALIDATION_ERROR.name(),
                "[NotNull.addRequest.unitizables[0].label: label can not be null.]");
    }

    @Test
    public void shouldThrow400IfUnitizableLabelTypeIsNotPresentInRequest() {

        addRequest.getUnitizables().get(0).setLabelType(null);
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class), VALIDATION_ERROR.name(),
                "[NotNull.addRequest.unitizables[0].labelType: labelType cannot be null or empty.]");
    }

    @Test
    public void shouldThrow400IfUnitizableStateMachineIdIsNotPresentInRequest() {

        addRequest.getUnitizables().get(0).setStateMachineId(null);
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class), VALIDATION_ERROR.name(),
                "[NotNull.addRequest.unitizables[0].stateMachineId: stateMachineId cannot be null or empty.]");
    }

    @Test
    public void shouldThrow400IfFlowContextIsNotPresentInRequest() {

        addRequest.setFlowContext(null);
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class), VALIDATION_ERROR.name(),
                "[NotNull.addRequest.flowContext: flowContext cannot be null or empty.]");
    }

    @Test
    public void shouldThrow400IfContainerStateMachineIdIsNotPresentInRequest() {

        addRequest.setStateMachineId(null);
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class), VALIDATION_ERROR.name(),
                "[NotNull.addRequest.stateMachineId: stateMachineId cannot be null or empty.]");
    }

    @Test
    public void shouldThrow400IfCreatedByEntityIdIsNotPresentInRequest() {

        addRequest.setCreatedByEntityId(null);
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class), VALIDATION_ERROR.name(),
                "[NotNull.addRequest.createdByEntityId: createdByEntityId cannot be null or empty.]");
    }

    @Test
    public void shouldThrow400IfCreatedByEntityTypeIsNotPresentInRequest() {

        addRequest.setCreatedByEntityType(null);
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class), VALIDATION_ERROR.name(),
                "[NotNull.addRequest.createdByEntityType: createdByEntityType cannot be null or empty.]");
    }

    @Test
    public void shouldThrow400IfUnitzablesToBeAddedAreMoreThanConfigured() {

        for (int i = 0; i < MAX_UNITIZABLES_TO_BE_ADDED; ++i) {
            addRequest.getUnitizables()
                    .addAll(createUnitizableRequests(randomAlphabetic(10), randomAlphabetic(10), randomAlphabetic(10)));
        }
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class), VALIDATION_ERROR.name(),
                "[Size.addRequest.unitizables: maximum allowed unitizables are 20]");
    }

    //service validation test cases
    //not supporting because ims doesn't have bulk api
    @Test
    public void shouldThrow400IfUnitizablesHaveDifferentLabelTypes() {

        addRequest.getUnitizables().addAll(createUnitizableRequests("unkonown_type", "stateMachine", "unknown_label"));
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class), ADD_EXCEPTION.name(),
                "Unitizables are not of same label type");
    }

    //not supporting because fsm doesn't have bulk api
    @Test
    public void shouldThrow400IfUnitizablesAreOfDifferentTypes() {

        createUnitizableInIms(randomType, "S4", 5.0);
        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "flow",
                "stateMachine", createUnitizableRequests(itemLabelType, "stateMachine", "S1", "S4"));
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class), ADD_EXCEPTION.name(),
                "Unitizables are not of same type");
    }

    @Test
    public void shouldThrow400IfUnitizablesHaveDuplicateLabels() {

        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "flow",
                "stateMachine", createUnitizableRequests(itemLabelType, "stateMachine", "S1", "S1"));
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class), ADD_EXCEPTION.name(),
                "Duplicate labels found");
    }

    //1.IMS Validations
    @Test
    public void shouldThrow400IfNoUnitizablesArePresentInIMS() {

        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class), LABEL_NOT_FOUND_EXCEPTION.name(),
                "Item with label unitizableLabel and type " + itemLabelType + " not found");
    }

    @Test
    public void shouldThrow400IfSomeUnitizableAreMissingInIMS() {
        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "3PL",
                "stateMachine", createUnitizableRequests(itemLabelType, "stateMachine", "S1", "unknown"));
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class), LABEL_NOT_FOUND_EXCEPTION.name(),
                "Item with label unknown and type " + itemLabelType + " not found");
    }

    @Test
    public void shouldThrow400IfContainerIsNotPresentInIMS() {

        addRequest = createAddRequest("containerLabel", containerType, containerLabelType, rootContainerId, "3PL",
                "stateMachine", createUnitizableRequests(itemLabelType, "stateMachine", "S1", "S2"));
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class),
                CONTAINER_NOT_FOUND_EXCEPTION.name(),
                "Container with label containerLabel and type " + containerLabelType + " not found");
    }

    @Test
    public void shouldRaiseErrorIfContainerIsNotCompatibleWithUnitizables() {

        assertOk(API.updateItem(clientId, createUpdateRequest(transientContainerType, BULK, rootContainerId, "3PL",
                transientContainerLabelType, STATE_MACHINE, "close"), SuccessResponse.class));
        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(transientContainerLabelType, STATE_MACHINE, BULK));
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class));
    }

    //2. Fsm Validations
    @Test
    public void shouldThrow400IfUnitizablesAreNotInSameStates() {

        createUnitizableInIms(itemType, "S4", 5.0);
        assertOk(API.updateItem(clientId, createUpdateRequest(itemType, "S4", rootContainerId, "3PL",
                itemLabelType, STATE_MACHINE, "dispatch"), SuccessResponse.class));
        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, "stateMachine", "S1", "S4"));
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class),
                ADD_EXCEPTION.name(), "Items are not in same state.");
    }

    @Test
    public void shouldThrow400IfContainerStateMachineNotFound() {

        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, "stateMachine", "S1"));
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class),
                INVALID_STATE_MACHINE_EXCEPTION.name(), "Invalid StateMachine: stateMachine");
    }

    @Test
    public void shouldThrow400IfAddTransitionIsNotAllowedForContainer() {

        assertOk(API.updateItem(clientId, createUpdateRequest(containerType, CONTAINER_LABEL, rootContainerId,
                "3PL", containerLabelType, STATE_MACHINE, "close"), SuccessResponse.class));

        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S1"));
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class),
                INVALID_TRANSITION_EXCEPTION.name(), "add_unitizables is not a valid transition.");
    }

    @Test
    public void shouldThrow400IfUnitizablesStateMachineNotFound() {

        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "3PL",
                "stateMachine", createUnitizableRequests(itemLabelType, STATE_MACHINE, "S1"));
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class),
                INVALID_STATE_MACHINE_EXCEPTION.name(), "Invalid StateMachine: stateMachine");
    }

    //case is here because we don't have bulk API in FSM
    @Test
    public void shouldThrow400IfUnitizablesAreFromMultipleSourceContainer() {

        //one item is in non_transient container and another in facility trying to move both to bulk
        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S1"));
        assertOk(API.addToContainer(clientId, addRequest, SuccessResponse.class));

        addRequest = createAddRequest(BULK, transientContainerType, transientContainerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S1", "S2"));
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class),
                ADD_EXCEPTION.name(), "Can not remove items from multiple containers");

    }

    //3.weight validation when weight attribute is present and max weight attribute is present in specification.
    @Test
    public void shouldThrow400IfContainerCanNotHoldMoreWeightWhileContainerIsEmpty() {
        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "3PL",
                "stateMachine", createUnitizableRequests(itemLabelType, "stateMachine", "S1", "S2", "S3"));
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class),
                WEIGHT_EXCEEDED_EXCEPTION.name(),
                "Maximum allowed weight for item " + containerId + " is 50.0 but total provided weight is 60.0");
    }

    @Test
    public void shouldThrow400IfContainerCanNotHoldMoreWeightWhileContainerIsNotEmpty() {

        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S1", "S2"));
        assertOk(API.addToContainer(clientId, addRequest, SuccessResponse.class));

        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S3"));
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class),
                WEIGHT_EXCEEDED_EXCEPTION.name(),
                "Maximum allowed weight for item " + containerId + " is 50.0 but total provided weight is 60.0");
    }

    @Test
    public void shouldThrow400IfSomeUnitizablesHaveWeightAttributeAndSomeDontWhileAddingToNonTransientContainer() {

        createUnitizableInImsWithoutWeight(itemType, "S4");
        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S1", "S4"));
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class), ADD_EXCEPTION.name(),
                "Some items have weight and some don't");
    }

    @Test
    public void shouldThrow400IfUnitizablesDoNotHaveWeightAttributeAndSpecificationHasMaxWt() {

        createUnitizableInImsWithoutWeight(itemType, "S4");
        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S1"));
        assertOk(API.addToContainer(clientId, addRequest, ErrorMessage.class));

        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S4"));
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class), ADD_EXCEPTION.name(),
                "Can not add items without having weight attribute");
    }

    @Test
    public void shouldThrow400IfSomeUnitizablesHaveWeightAndContainerDontHaveCurrWtWhileAddingToNonTransientCon() {

        createUnitizableInImsWithoutWeight(itemType, "S4");
        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S4"));
        assertOk(API.addToContainer(clientId, addRequest, ErrorMessage.class));
        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S1"));
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class), ADD_EXCEPTION.name(),
                "Adding items with weight not allowed");
    }

    //4.number of items validation when specification has max_no_of_items attribute
    @Test
    public void shouldThrow400IfContainerCanNotHoldMoreItemsWhileContainerIsEmpty() {

        createUnitizableInIms(itemType, "S4", 5.0);
        createUnitizableInIms(itemType, "S5", 5.0);
        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "3PL",
                "stateMachine", createUnitizableRequests(itemLabelType, "stateMachine", "S1", "S2", "S4", "S5"));
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class),
                NUMBER_OF_ITEMS_EXCEEDED_EXCEPTION.name(),
                "Maximum number of items allowed for item " + containerId + "are 3 but total provided are 4");
    }

    @Test
    public void shouldThrow400IfContainerCanNotHoldMoreItemsWhileContainerIsNotEmpty() {

        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S1", "S2"));
        assertOk(API.addToContainer(clientId, addRequest, SuccessResponse.class));

        createUnitizableInIms(randomType, "S4", 5.0);
        createUnitizableInIms(randomType, "S5", 5.0);

        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "3PL",
                "stateMachine", createUnitizableRequests(itemLabelType, "stateMachine", "S4", "S5"));

        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class),
                NUMBER_OF_ITEMS_EXCEEDED_EXCEPTION.name(),
                "Maximum number of items allowed for item " + containerId + "are 3 but total provided are 4");
    }

    //5. Add unitizables with weight
    @Test
    public void shouldMoveUnitizablesFromRootContainerToNonTransientContainer() throws IOException {

        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S1", "S2"));
        assertOk(API.addToContainer(clientId, addRequest, SuccessResponse.class));

        Item container = getItemsFromResponse(API.getItemFromImsByLabel(rootContainerId,
                new Label(containerLabelType, CONTAINER_LABEL)).getBody()).get(0);

        //root container is transient so there won't be any current weight attribute
        assertThat(getItemsFromResponse(API.getItemFromImsById(rootContainerId, rootContainerId)
                .getBody()).get(0).getAttributes().containsKey(UNITIZATION_CURRENT_WEIGHT.name()), is(false));

        //current weight of container will be increased to weight of S1+S2 = 30.0
        assertThat(new BigDecimal(container.getAttributes().get(UNITIZATION_CURRENT_WEIGHT.name())
                        .getValue().toString()), is(BigDecimal.valueOf(30.0)));

        //container will now have two items S1 and S2
        assertThat(Long.parseLong(container.getAttributes().get(UNITIZATION_CURRENT_NO_OF_ITEMS.name()).getValue()
                .toString()), is(2L));
    }

    @Test
    public void shouldMoveUnitizablesFromRootContainerToTransientContainer() throws IOException {

        addRequest = createAddRequest(BULK, transientContainerType, transientContainerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S1", "S2"));
        assertOk(API.addToContainer(clientId, addRequest, SuccessResponse.class));

        Item container = getItemsFromResponse(API.getItemFromImsByLabel(rootContainerId,
                new Label(transientContainerLabelType, BULK)).getBody()).get(0);

        //root container is transient so there won't be any current weight attribute
        assertThat(getItemsFromResponse(API.getItemFromImsById(rootContainerId, rootContainerId).getBody())
                .get(0).getAttributes().containsKey(UNITIZATION_CURRENT_WEIGHT.name()), is(false));

        //container is also transient so there won't be any current weight attribute
        assertThat(container.getAttributes().containsKey(UNITIZATION_CURRENT_WEIGHT.name()), is(false));

        //container will now have two items S1 and S2
        assertThat(Long.parseLong(container.getAttributes().get(UNITIZATION_CURRENT_NO_OF_ITEMS.name()).getValue()
                .toString()), is(2L));
    }

    @Test
    public void shouldMoveUnitizablesFromTransientContainerToNonTransientContainer() throws IOException {

        //move to transient
        addRequest = createAddRequest(BULK, transientContainerType, transientContainerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S1", "S2"));
        assertOk(API.addToContainer(clientId, addRequest, SuccessResponse.class));
        //get item and match container id

        //move to non transient
        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S1", "S2"));
        assertOk(API.addToContainer(clientId, addRequest, SuccessResponse.class));

        Map<String, ItemAttribute> containerAttributes = getItemsFromResponse(API.getItemFromImsByLabel(rootContainerId,
                new Label(containerLabelType, CONTAINER_LABEL)).getBody()).get(0).getAttributes();

        Map<String, ItemAttribute> transientContainerAttributes = getItemsFromResponse(API.getItemFromImsByLabel(
                rootContainerId, new Label(transientContainerLabelType, BULK)).getBody()).get(0).getAttributes();

        //bulk is transient so there won't be any current weight attribute
        assertThat(transientContainerAttributes.containsKey(UNITIZATION_CURRENT_WEIGHT.name()), is(false));

        //we added only 2 item in bulk now we removed all 2 so current no of items in bulk will be 0
        assertThat(Long.parseLong(transientContainerAttributes.get(UNITIZATION_CURRENT_NO_OF_ITEMS.name())
                        .getValue().toString()), is(0L));

        // container is non-transient, so it should have all these attributes
        assertThat(new BigDecimal(containerAttributes.get(UNITIZATION_CURRENT_WEIGHT.name()).getValue().toString()),
                is(BigDecimal.valueOf(30.0)));

        assertThat(Long.parseLong(containerAttributes.get(UNITIZATION_CURRENT_NO_OF_ITEMS.name())
                .getValue().toString()), is(2L));

    }

    @Test
    public void shouldMoveUnitizablesFromNonTransientToTransientContainerAndRemoveAllItems() throws IOException {

        //move to non transient from facility
        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S1", "S2"));
        assertOk(API.addToContainer(clientId, addRequest, SuccessResponse.class));

        //moving same item again it should not be moved
        addRequest.setIdempotenceKey(randomAlphabetic(20));
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class));

        //move to transient
        addRequest = createAddRequest(BULK, transientContainerType, transientContainerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S1", "S2"));
        assertOk(API.addToContainer(clientId, addRequest, SuccessResponse.class));

        Map<String, ItemAttribute> containerAttributes = getItemsFromResponse(API.getItemFromImsByLabel(rootContainerId,
                new Label(containerLabelType, CONTAINER_LABEL)).getBody()).get(0).getAttributes();

        Map<String, ItemAttribute> transientContainerAttributes = getItemsFromResponse(API.getItemFromImsByLabel(
                rootContainerId, new Label(transientContainerLabelType, BULK)).getBody()).get(0).getAttributes();

        //we are removing all items from non-transient container that means current_weight attribute should get deleted
        assertThat(containerAttributes.containsKey(UNITIZATION_CURRENT_WEIGHT.name()), is(false));

        //removing all items from non-transient so current no of items also should be 0
        assertThat(Long.parseLong(containerAttributes.get(UNITIZATION_CURRENT_NO_OF_ITEMS.name())
                .getValue().toString()), is(0L));

        //adding to transient so there won't be any current weight attribute
        assertThat(transientContainerAttributes.containsKey(UNITIZATION_CURRENT_WEIGHT.name()), is(false));

        //total items in transient container will be 2
        assertThat(Long.parseLong(transientContainerAttributes.get(UNITIZATION_CURRENT_NO_OF_ITEMS.name()).getValue()
                .toString()), is(2L));
    }

    @Test
    public void shouldMoveUnitizablesFromNonTransientToTransientContainerAndRemoveSomeItems() throws IOException {

        //move to non transient from facility
        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S1", "S2"));
        assertOk(API.addToContainer(clientId, addRequest, SuccessResponse.class));

        //moving same item again it should not be moved
        addRequest.setIdempotenceKey(randomAlphabetic(20));
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class));

        //move to transient
        addRequest = createAddRequest(BULK, transientContainerType, transientContainerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S1"));
        assertOk(API.addToContainer(clientId, addRequest, SuccessResponse.class));

        Map<String, ItemAttribute> containerAttributes = getItemsFromResponse(API.getItemFromImsByLabel(rootContainerId,
                new Label(containerLabelType, CONTAINER_LABEL)).getBody()).get(0).getAttributes();

        Map<String, ItemAttribute> transientContainerAttributes = getItemsFromResponse(API.getItemFromImsByLabel(
                rootContainerId, new Label(transientContainerLabelType, BULK)).getBody()).get(0).getAttributes();

        //we are removing only S1 from non-transient container that means current_weight should get reduced to 20
        assertThat(new BigDecimal(containerAttributes.get(UNITIZATION_CURRENT_WEIGHT.name()).getValue().toString()),
                is(BigDecimal.valueOf(20.0)));

        //removing only S1 from non-transient so current no of items also should be 1
        assertThat(Long.parseLong(containerAttributes.get(UNITIZATION_CURRENT_NO_OF_ITEMS.name())
                .getValue().toString()), is(1L));

        //adding to transient so there won't be any current weight attribute
        assertThat(transientContainerAttributes.containsKey(UNITIZATION_CURRENT_WEIGHT.name()), is(false));

        //total items in transient container will be 1
        assertThat(Long.parseLong(transientContainerAttributes.get(UNITIZATION_CURRENT_NO_OF_ITEMS.name()).getValue()
                .toString()), is(1L));
    }

    @Test
    public void shouldMoveUnitizablesWithWeightFromNonTransientToNonTransientContainer() throws IOException {

        String newNonTransientContainerLabel = "newContainer";
        assertCreated(API.createContainer(clientId, createContainer(containerType, newNonTransientContainerLabel,
                containerLabelType, rootContainerId), SuccessResponse.class));

        //move to non transient from facility
        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S1", "S2"));
        assertOk(API.addToContainer(clientId, addRequest, SuccessResponse.class));

        //moving same item again it should not be moved
        addRequest.setIdempotenceKey(randomAlphabetic(20));
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class));

        //move to non-transient
        addRequest = createAddRequest(newNonTransientContainerLabel, containerType, containerLabelType,
                rootContainerId, "3PL", STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S1"));
        assertOk(API.addToContainer(clientId, addRequest, SuccessResponse.class));

        Map<String, ItemAttribute> containerAttributes = getItemsFromResponse(API.getItemFromImsByLabel(rootContainerId,
                new Label(containerLabelType, CONTAINER_LABEL)).getBody()).get(0).getAttributes();

        Map<String, ItemAttribute> newContainerAttributes = getItemsFromResponse(API.getItemFromImsByLabel(
                rootContainerId, new Label(containerLabelType, newNonTransientContainerLabel)).getBody()).
                get(0).getAttributes();

        assertThat(new BigDecimal(containerAttributes.get(UNITIZATION_CURRENT_WEIGHT.name()).getValue().toString()),
                is(BigDecimal.valueOf(20.0)));

        //removing only S1 from non-transient so current no of items also should be 1
        assertThat(Long.parseLong(containerAttributes.get(UNITIZATION_CURRENT_NO_OF_ITEMS.name())
                .getValue().toString()), is(1L));

        assertThat(new BigDecimal(newContainerAttributes.get(UNITIZATION_CURRENT_WEIGHT.name()).getValue().toString()),
                is(BigDecimal.valueOf(10.0)));

        //total items in new non-transient container will be 1
        assertThat(Long.parseLong(newContainerAttributes.get(UNITIZATION_CURRENT_NO_OF_ITEMS.name()).getValue()
                .toString()), is(1L));
    }

    @Test
    public void shouldMoveUnitizablesWithWeightFromTransientToTransientContainer() throws IOException {

        String newTransientContainerLabel = "newContainer";
        assertCreated(API.createContainer(clientId, createContainer(transientContainerType,
                newTransientContainerLabel,
                transientContainerLabelType, rootContainerId), SuccessResponse.class));

        //move to transient from facility
        addRequest = createAddRequest(BULK, transientContainerType, transientContainerLabelType,
                rootContainerId, "3PL", STATE_MACHINE,
                createUnitizableRequests(itemLabelType, STATE_MACHINE, "S1", "S2"));
        assertOk(API.addToContainer(clientId, addRequest, SuccessResponse.class));

        //moving same item again it should not be moved
        addRequest.setIdempotenceKey(randomAlphabetic(20));
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class));

        //move to transient
        addRequest = createAddRequest(newTransientContainerLabel, transientContainerType,
                transientContainerLabelType,
                rootContainerId, "3PL", STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S1"));
        assertOk(API.addToContainer(clientId, addRequest, SuccessResponse.class));

        Map<String, ItemAttribute> containerAttributes = getItemsFromResponse(API.getItemFromImsByLabel(rootContainerId,
                new Label(transientContainerLabelType, BULK)).getBody()).get(0).getAttributes();

        Map<String, ItemAttribute> newContainerAttributes = getItemsFromResponse(API.getItemFromImsByLabel(
                rootContainerId, new Label(transientContainerLabelType, newTransientContainerLabel)).getBody()).
                get(0).getAttributes();

        //unitizables don't have weight attributes so there won't be any current weight attribute
        assertThat(containerAttributes.containsKey(UNITIZATION_CURRENT_WEIGHT.name()), is(false));

        //removing only S1 from transient so current no of items also should be 1
        assertThat(Long.parseLong(containerAttributes.get(UNITIZATION_CURRENT_NO_OF_ITEMS.name())
                .getValue().toString()), is(1L));

        //adding to transient so there won't be any current weight attribute
        assertThat(newContainerAttributes.containsKey(UNITIZATION_CURRENT_WEIGHT.name()), is(false));

        //total items in new transient container will be 1
        assertThat(Long.parseLong(newContainerAttributes.get(UNITIZATION_CURRENT_NO_OF_ITEMS.name()).getValue()
                .toString()), is(1L));
    }

    //6. Add unitizables without weight
    @Test
    public void shouldMoveUnitizablesWithoutWeightFromRootContainerToNonTransientContainer() throws IOException {

        createUnitizableInImsWithoutWeight(itemType, "S4");
        createUnitizableInImsWithoutWeight(itemType, "S5");

        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S4", "S5"));
        assertOk(API.addToContainer(clientId, addRequest, SuccessResponse.class));

        Item container = getItemsFromResponse(API.getItemFromImsByLabel(rootContainerId,
                new Label(containerLabelType, CONTAINER_LABEL)).getBody()).get(0);

        //root container is transient so there won't be any current weight attribute
        assertThat(getItemsFromResponse(API.getItemFromImsById(rootContainerId, rootContainerId).getBody())
                .get(0).getAttributes().containsKey(UNITIZATION_CURRENT_WEIGHT.name()), is(false));

        //items to be moved inside container don't have weight so there won't be any current weight attribute
        assertThat(container.getAttributes().containsKey(UNITIZATION_CURRENT_WEIGHT.name()), is(false));

        //container will now have two items S1 and S2
        assertThat(Long.parseLong(container.getAttributes().get(UNITIZATION_CURRENT_NO_OF_ITEMS.name()).getValue()
                .toString()), is(2L));
    }

    @Test
    public void shouldMoveUnitizablesWithoutWeightFromRootContainerToTransientContainer() throws IOException {

        createUnitizableInImsWithoutWeight(itemType, "S4");
        createUnitizableInImsWithoutWeight(itemType, "S5");

        addRequest = createAddRequest(BULK, transientContainerType, transientContainerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S4", "S5"));
        assertOk(API.addToContainer(clientId, addRequest, SuccessResponse.class));

        Item container = getItemsFromResponse(API.getItemFromImsByLabel(rootContainerId,
                new Label(transientContainerLabelType, BULK)).getBody()).get(0);

        //root container is transient so there won't be any current weight attribute
        assertThat(getItemsFromResponse(API.getItemFromImsById(rootContainerId, rootContainerId).getBody())
                .get(0).getAttributes().containsKey(UNITIZATION_CURRENT_WEIGHT.name()), is(false));

        //container is also transient so there won't be any current weight attribute
        assertThat(container.getAttributes().containsKey(UNITIZATION_CURRENT_WEIGHT.name()), is(false));

        //container will now have two items S1 and S2
        assertThat(Long.parseLong(container.getAttributes().get(UNITIZATION_CURRENT_NO_OF_ITEMS.name()).getValue()
                .toString()), is(2L));
    }

    @Test
    public void shouldMoveUnitizablesWithoutWeightFromTransientContainerToNonTransientContainer() throws IOException {

        createUnitizableInImsWithoutWeight(itemType, "S4");
        createUnitizableInImsWithoutWeight(itemType, "S5");
        //move to transient
        addRequest = createAddRequest(BULK, transientContainerType, transientContainerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S4", "S5"));
        assertOk(API.addToContainer(clientId, addRequest, SuccessResponse.class));
        //get item and match container id

        //move to non transient
        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S4", "S5"));
        assertOk(API.addToContainer(clientId, addRequest, SuccessResponse.class));

        Map<String, ItemAttribute> containerAttributes = getItemsFromResponse(API.getItemFromImsByLabel(rootContainerId,
                new Label(containerLabelType, CONTAINER_LABEL)).getBody()).get(0).getAttributes();

        Map<String, ItemAttribute> transientContainerAttributes = getItemsFromResponse(API.getItemFromImsByLabel(
                rootContainerId, new Label(transientContainerLabelType, BULK)).getBody()).get(0).getAttributes();

        //bulk is transient so there won't be any current weight attribute
        assertThat(transientContainerAttributes.containsKey(UNITIZATION_CURRENT_WEIGHT.name()), is(false));

        //we added only 2 item in bulk now we removed all 2 so current no of items in bulk will be 0
        assertThat(Long.parseLong(transientContainerAttributes.get(UNITIZATION_CURRENT_NO_OF_ITEMS.name())
                .getValue().toString()), is(0L));

        //unitizables don't have weight attributes so there won't be any current weight attribute
        assertThat(containerAttributes.containsKey(UNITIZATION_CURRENT_WEIGHT.name()), is(false));

        assertThat(Long.parseLong(containerAttributes.get(UNITIZATION_CURRENT_NO_OF_ITEMS.name())
                .getValue().toString()), is(2L));
    }

    @Test
    public void shouldMoveUnitizablesWithoutWeightFromNonTransientToTransientContainerAndRemoveAllItems()
            throws IOException {

        createUnitizableInImsWithoutWeight(itemType, "S4");
        createUnitizableInImsWithoutWeight(itemType, "S5");
        //move to non transient from facility
        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S4", "S5"));
        assertOk(API.addToContainer(clientId, addRequest, SuccessResponse.class));

        //moving same item again it should not be moved
        addRequest.setIdempotenceKey(randomAlphabetic(20));
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class));

        //move to transient
        addRequest = createAddRequest(BULK, transientContainerType, transientContainerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S4", "S5"));
        assertOk(API.addToContainer(clientId, addRequest, SuccessResponse.class));

        Map<String, ItemAttribute> containerAttributes = getItemsFromResponse(API.getItemFromImsByLabel(rootContainerId,
                new Label(containerLabelType, CONTAINER_LABEL)).getBody()).get(0).getAttributes();

        Map<String, ItemAttribute> transientContainerAttributes = getItemsFromResponse(API.getItemFromImsByLabel(
                rootContainerId, new Label(transientContainerLabelType, BULK)).getBody()).get(0).getAttributes();

        //unitizables don't have weight attributes so there won't be any current weight attribute
        assertThat(containerAttributes.containsKey(UNITIZATION_CURRENT_WEIGHT.name()), is(false));

        //removing all items from non-transient so current no of items also should be 0
        assertThat(Long.parseLong(containerAttributes.get(UNITIZATION_CURRENT_NO_OF_ITEMS.name())
                .getValue().toString()), is(0L));

        //adding to transient so there won't be any current weight attribute
        assertThat(transientContainerAttributes.containsKey(UNITIZATION_CURRENT_WEIGHT.name()), is(false));

        //total items in transient container will be 2
        assertThat(Long.parseLong(transientContainerAttributes.get(UNITIZATION_CURRENT_NO_OF_ITEMS.name()).getValue()
                .toString()), is(2L));
    }

    @Test
    public void shouldMoveUnitizablesWithoutWeightFromNonTransientToTransientContainerAndRemoveSomeItems()
            throws IOException {

        createUnitizableInImsWithoutWeight(itemType, "S4");
        createUnitizableInImsWithoutWeight(itemType, "S5");
        //move to non transient from facility
        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S4", "S5"));
        assertOk(API.addToContainer(clientId, addRequest, SuccessResponse.class));

        //moving same item again it should not be moved
        addRequest.setIdempotenceKey(randomAlphabetic(20));
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class));

        //move to transient
        addRequest = createAddRequest(BULK, transientContainerType, transientContainerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S4"));
        assertOk(API.addToContainer(clientId, addRequest, SuccessResponse.class));

        Map<String, ItemAttribute> containerAttributes = getItemsFromResponse(API.getItemFromImsByLabel(rootContainerId,
                new Label(containerLabelType, CONTAINER_LABEL)).getBody()).get(0).getAttributes();

        Map<String, ItemAttribute> transientContainerAttributes = getItemsFromResponse(API.getItemFromImsByLabel(
                rootContainerId, new Label(transientContainerLabelType, BULK)).getBody()).get(0).getAttributes();

        //unitizables don't have weight attributes so there won't be any current weight attribute
        assertThat(containerAttributes.containsKey(UNITIZATION_CURRENT_WEIGHT.name()), is(false));

        //removing only S1 from non-transient so current no of items also should be 1
        assertThat(Long.parseLong(containerAttributes.get(UNITIZATION_CURRENT_NO_OF_ITEMS.name())
                .getValue().toString()), is(1L));

        //adding to transient so there won't be any current weight attribute
        assertThat(transientContainerAttributes.containsKey(UNITIZATION_CURRENT_WEIGHT.name()), is(false));

        //total items in transient container will be 1
        assertThat(Long.parseLong(transientContainerAttributes.get(UNITIZATION_CURRENT_NO_OF_ITEMS.name()).getValue()
                .toString()), is(1L));
    }

    @Test
    public void shouldMoveUnitizablesWithoutWeightFromNonTransientToNonTransientContainer() throws IOException {

        createUnitizableInImsWithoutWeight(itemType, "S4");
        createUnitizableInImsWithoutWeight(itemType, "S5");
        String newNonTransientContainerLabel = "newContainer";
        assertCreated(API.createContainer(clientId, createContainer(containerType, newNonTransientContainerLabel,
                containerLabelType, rootContainerId), SuccessResponse.class));

        //move to non transient from facility
        addRequest = createAddRequest(CONTAINER_LABEL, containerType, containerLabelType, rootContainerId, "3PL",
                STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S4", "S5"));
        assertOk(API.addToContainer(clientId, addRequest, SuccessResponse.class));

        //moving same item again it should not be moved
        addRequest.setIdempotenceKey(randomAlphabetic(20));
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class));

        //move to non-transient
        addRequest = createAddRequest(newNonTransientContainerLabel, containerType, containerLabelType,
                rootContainerId, "3PL", STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S4"));
        assertOk(API.addToContainer(clientId, addRequest, SuccessResponse.class));

        Map<String, ItemAttribute> containerAttributes = getItemsFromResponse(API.getItemFromImsByLabel(rootContainerId,
                new Label(containerLabelType, CONTAINER_LABEL)).getBody()).get(0).getAttributes();

        Map<String, ItemAttribute> newContainerAttributes = getItemsFromResponse(API.getItemFromImsByLabel(
                rootContainerId, new Label(containerLabelType, newNonTransientContainerLabel)).getBody()).
                get(0).getAttributes();

        //unitizables don't have weight attributes so there won't be any current weight attribute
        assertThat(containerAttributes.containsKey(UNITIZATION_CURRENT_WEIGHT.name()), is(false));

        //removing only S1 from non-transient so current no of items also should be 1
        assertThat(Long.parseLong(containerAttributes.get(UNITIZATION_CURRENT_NO_OF_ITEMS.name())
                .getValue().toString()), is(1L));

        //adding to transient so there won't be any current weight attribute
        assertThat(newContainerAttributes.containsKey(UNITIZATION_CURRENT_WEIGHT.name()), is(false));

        //total items in new non-transient container will be 1
        assertThat(Long.parseLong(newContainerAttributes.get(UNITIZATION_CURRENT_NO_OF_ITEMS.name()).getValue()
                .toString()), is(1L));
    }

    @Test
    public void shouldMoveUnitizablesWithoutWeightFromTransientToTransientContainer() throws IOException {

        createUnitizableInImsWithoutWeight(itemType, "S4");
        createUnitizableInImsWithoutWeight(itemType, "S5");
        String newTransientContainerLabel = "newContainer";
        assertCreated(API.createContainer(clientId, createContainer(transientContainerType,
                newTransientContainerLabel,
                transientContainerLabelType, rootContainerId), SuccessResponse.class));

        //move to transient from facility
        addRequest = createAddRequest(BULK, transientContainerType, transientContainerLabelType,
                rootContainerId, "3PL", STATE_MACHINE,
                createUnitizableRequests(itemLabelType, STATE_MACHINE, "S4", "S5"));
        assertOk(API.addToContainer(clientId, addRequest, SuccessResponse.class));

        //moving same item again it should not be moved
        addRequest.setIdempotenceKey(randomAlphabetic(20));
        assertBadRequest(API.addToContainer(clientId, addRequest, ErrorMessage.class));

        //move to transient
        addRequest = createAddRequest(newTransientContainerLabel, transientContainerType,
                transientContainerLabelType,
                rootContainerId, "3PL", STATE_MACHINE, createUnitizableRequests(itemLabelType, STATE_MACHINE, "S4"));
        assertOk(API.addToContainer(clientId, addRequest, SuccessResponse.class));

        Map<String, ItemAttribute> containerAttributes = getItemsFromResponse(API.getItemFromImsByLabel(rootContainerId,
                new Label(transientContainerLabelType, BULK)).getBody()).get(0).getAttributes();

        Map<String, ItemAttribute> newContainerAttributes = getItemsFromResponse(API.getItemFromImsByLabel(
                rootContainerId, new Label(transientContainerLabelType, newTransientContainerLabel)).getBody()).
                get(0).getAttributes();

        //unitizables don't have weight attributes so there won't be any current weight attribute
        assertThat(containerAttributes.containsKey(UNITIZATION_CURRENT_WEIGHT.name()), is(false));

        //removing only S1 from transient so current no of items also should be 1
        assertThat(Long.parseLong(containerAttributes.get(UNITIZATION_CURRENT_NO_OF_ITEMS.name())
                .getValue().toString()), is(1L));

        //adding to transient so there won't be any current weight attribute
        assertThat(newContainerAttributes.containsKey(UNITIZATION_CURRENT_WEIGHT.name()), is(false));

        //total items in new transient container will be 1
        assertThat(Long.parseLong(newContainerAttributes.get(UNITIZATION_CURRENT_NO_OF_ITEMS.name()).getValue()
                .toString()), is(1L));
    }

    private void createSpecifications() {
        SpecificationCreationRequest request = newSpecificationCreateRequest(containerType);
        request.setAttributes(ImmutableMap.of(MAX_WEIGHT.name(), "50.0",
                MAX_NO_OF_ITEMS.name(), "3"));
        API.createSpecification(clientId, request).getBody().getSpecificationId();
        request = newSpecificationCreateRequest(transientContainerType);
        API.createSpecification(clientId, request);
        request = newSpecificationCreateRequest(itemType);
        API.createSpecification(clientId, request);
        request = newSpecificationCreateRequest(randomType);
        API.createSpecification(clientId, request);
    }

    private void createContainersAndTypes() throws IOException {

        API.createItemType(itemType);
        API.createItemType(randomType);
        API.createRootContainerItemType(containerType, Lists.newArrayList(itemType));
        API.createRootContainerItemType(transientContainerType, Lists.newArrayList(itemType));
        API.createRootContainerItemType(rootContainerItemType,
                Lists.newArrayList(itemType, containerType, transientContainerType, randomType));
        API.createRootContainer(rootContainerId, rootContainerItemType);

        assertCreated(API.createContainer(clientId, createContainer(containerType, CONTAINER_LABEL,
                containerLabelType, rootContainerId), SuccessResponse.class));
        containerId = getItemsFromResponse(API.getItemFromImsByLabel(rootContainerId,
                new Label(containerLabelType, CONTAINER_LABEL)).getBody()).get(0).getId();

        assertCreated(API.createContainer(clientId, createTransientContainer(transientContainerType, BULK,
                transientContainerLabelType, rootContainerId), SuccessResponse.class));

        //create unitiables with dispatch status so that they can be moved to container
        for (int i = 0; i < 3; ++i) {
            createUnitizableInIms(itemType, "S" + (i + 1), 10.0 * (i + 1));
        }
    }

    private void createUnitizableInIms(String type, String label, double weight) {

        assertCreated(API.createContainer(clientId, createContainerWithWeight(type, label,
                itemLabelType, rootContainerId, weight), SuccessResponse.class));
        assertOk(API.updateItem(clientId, createUpdateRequest(type, label, rootContainerId, "3PL",
                itemLabelType, STATE_MACHINE, "close"), SuccessResponse.class));
    }

    private void createUnitizableInImsWithoutWeight(String itemType, String label) {

        assertCreated(API.createContainer(clientId, createContainer(itemType, label,
                itemLabelType, rootContainerId), SuccessResponse.class));
        assertOk(API.updateItem(clientId, createUpdateRequest(itemType, label, rootContainerId, "3PL",
                itemLabelType, STATE_MACHINE, "close"), SuccessResponse.class));
    }

    private List<Item> getItemsFromResponse(String response) throws IOException {
        return objectMapper.readValue(response, GetItemResponse.class).getItems();
    }
}


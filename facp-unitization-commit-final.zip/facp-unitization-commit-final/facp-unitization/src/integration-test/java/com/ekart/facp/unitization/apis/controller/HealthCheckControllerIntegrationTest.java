package com.ekart.facp.unitization.apis.controller;

import com.ekart.facp.unitization.apis.BaseIntegrationTest;
import com.ekart.facp.unitization.apis.dtos.health.ElbHealthCheckResponse;
import com.ekart.facp.unitization.apis.dtos.health.HealthCheckResponse;
import com.ekart.facp.unitization.apis.dtos.health.HealthStatus;
import com.ekart.facp.unitization.apis.dtos.health.VipConfiguration;
import com.google.common.collect.ImmutableMap;
import org.junit.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

public class HealthCheckControllerIntegrationTest extends BaseIntegrationTest {

    private static void assertHealthCheckResponse(ResponseEntity<HealthCheckResponse> actualResponse,
                                                  List<String> nonPoolComponents) {

        assertThat(actualResponse.getStatusCode(), is(HttpStatus.OK));
        HealthCheckResponse actual = actualResponse.getBody();
        assertThat(actual.getServiceStatus(), is(HealthStatus.HEALTHY));
        assertThat(actual.getComponentStatuses().size(), is(nonPoolComponents.size() + 1));

        nonPoolComponents.forEach(c -> assertThat(actual.getComponentStatuses().get(c), is(HealthStatus.HEALTHY)));

        Optional<Entry<String, HealthStatus>> poolStatus = actual.getComponentStatuses().entrySet().stream()
                .filter(e -> e.getKey().startsWith("HikariPool")).findFirst();
        assertThat(poolStatus.isPresent(), is(true));
        assertThat(poolStatus.get().getValue(), is(HealthStatus.HEALTHY));
    }

    @Test
    public void shouldReturn400IfVipStatusIsNull() {

        HttpEntity<VipConfiguration> request = new HttpEntity<>(new VipConfiguration(), newHeader());
        ResponseEntity<String> response =
                CLIENT.exchange(url("/elb-healthcheck"), HttpMethod.PUT, request, String.class);
        assertThat(response.getStatusCode(), is(HttpStatus.BAD_REQUEST));
    }

    // NOTE: We won't be running tests for changing the VIP status as we don't
    // want to take any Alpha stage hosts OOR from behind their VIPs :)

    @Test
    public void shouldReturn400IfVipStatusIsNotRecognized() {

        HttpEntity<Map<String, String>> request = new HttpEntity<>(ImmutableMap.of("vip_status", "someStatus"),
                newHeader());
        ResponseEntity<String> response =
                CLIENT.exchange(url("/elb-healthcheck"), HttpMethod.PUT, request, String.class);
        assertThat(response.getStatusCode(), is(HttpStatus.BAD_REQUEST));
    }

    @Test
    public void shouldReturnSufficientDataForElbHealthCheckWhenShallowHealthCheckSucceeds() {

        ResponseEntity<ElbHealthCheckResponse> response = CLIENT.getForEntity(url("/elb-healthcheck"),
                ElbHealthCheckResponse.class);

        // Of course, we can't validate the exact values! :)
        assertThat(response.getBody().getCapacity(), notNullValue());
        assertThat(response.getBody().getRequests(), notNullValue());
        assertThat(response.getBody().getUptime(), notNullValue());

        assertThat(response.getStatusCode(), is(HttpStatus.OK));
    }

    @Test
    public void shouldReturnSuccessIfShallowHealthCheckSucceeds() {

        ResponseEntity<HealthCheckResponse> response = CLIENT.getForEntity(url("/elb-healthcheck/shallow"),
                HealthCheckResponse.class);
        assertHealthCheckResponse(response, Arrays.asList("threadDeadlockDetector", "vip_status"));
    }

    @Test
    public void shouldReturnSuccessIfDeepHealthCheckSucceeds() {

        ResponseEntity<HealthCheckResponse> response = CLIENT.getForEntity(url("/elb-healthcheck/deep"),
                HealthCheckResponse.class);
        assertHealthCheckResponse(response, Arrays.asList("threadDeadlockDetector"));
    }
}

package com.ekart.facp.unitization.apis;

import com.ekart.facp.unitization.apis.dtos.*;
import com.ekart.facp.unitization.service.dtos.clients.label_service.request.LabelMappingCreateRequest;
import com.ekart.facp.unitization.service.dtos.clients.label_service.response.LabelMappingCreateResponse;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.GetItemResponse;
import com.google.common.collect.ImmutableMap;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import javax.ws.rs.core.MediaType;
import java.util.List;
import java.util.Map;

import static com.ekart.facp.unitization.apis.BaseIntegrationTest.assertCreated;
import static com.ekart.facp.unitization.apis.BaseIntegrationTest.assertNoContent;
import static com.ekart.facp.unitization.apis.TestUtils.newSpecificationCreateRequest;
import static com.ekart.facp.unitization.apis.UnitizationTestUtils.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

/**
 * Created by anuj.chaudhary on 22/04/16.
 */

public class ApiInterface {

    private static final String TENANT_KEY = "X-Tenant-Context";
    private static final String EKART_CLIENT_KEY = "X-Ekart-Client";
    private RestTemplate client;
    private String host;
    private String imsHost;
    private String labelServiceHost;

    public ApiInterface() {
    }

    public RestTemplate getClient() {
        return client;
    }

    public void setClient(RestTemplate client) {
        this.client = client;
    }

    public String getHost() {

        return host;
    }

    public void setHost(String host) {

        this.host = host;
    }

    public void setImsHost(String imsHost) {

        this.imsHost = imsHost;
    }

    public void setLabelServiceHost(String labelServiceHost) {

        this.labelServiceHost = labelServiceHost;
    }

    public ResponseEntity<SpecificationCreationResponse> createSpecification(String tenantId,
                                                                             SpecificationCreationRequest
                                                                                    creationRequest) {

        return createSpecification(tenantId, creationRequest, SpecificationCreationResponse.class);
    }

    public <T> ResponseEntity<T> createSpecification(String tenantId, SpecificationCreationRequest creationRequest,
                                                     Class<T> responseClass) {

        HttpEntity<?> httpRequest = new HttpEntity<>(creationRequest, apiHeaders(tenantId));
        return client.exchange(url("/api/v1/specifications"), HttpMethod.POST, httpRequest, responseClass);

    }

    public ResponseEntity<Specification> getSpecificationById(String tenantId, String specificationId) {
        return getSpecificationById(tenantId, specificationId, Specification.class);
    }

    public <T> ResponseEntity<T> getSpecificationById(String tenantId, String specificationId, Class<T> responseClass) {
        HttpEntity<?> httpRequest = new HttpEntity<>(apiHeaders(tenantId));
        return client.exchange(url("/api/v1/specifications/{specificationId}"), HttpMethod.GET, httpRequest,
                responseClass, specificationId);
    }

    public ResponseEntity<Specification> getSpecificationByType(String tenantId, String type) {
        return getSpecificationByType(tenantId, type, Specification.class);
    }

    public <T> ResponseEntity<T> getSpecificationByType(String tenantId,
                                                        String type, Class<T> responseClass) {
        HttpEntity<?> httpRequest = new HttpEntity<>(apiHeaders(tenantId));
        return client.exchange(url("/api/v1/search/specifications/{type}"), HttpMethod.GET, httpRequest,
                responseClass, type);
    }

    public ResponseEntity<Specification> getInactiveSpecificationByType(String tenantId,
                                                                        String type) {
        return getInactiveSpecificationByType(tenantId, type, Specification.class);
    }

    public <T> ResponseEntity<T> getInactiveSpecificationByType(String tenantId, String type,
                                                                Class<T> responseClass) {
        HttpEntity<?> httpRequest = new HttpEntity<>(apiHeaders(tenantId));
        return client.exchange(url("/api/v1/search/inactive/specifications/{type}"),
                HttpMethod.GET, httpRequest, responseClass, type);
    }

    public ResponseEntity<Void> updateSpecification(String tenantId, String specificationId,
                                                    SpecificationUpdateRequest request) {
        return updateSpecification(tenantId, specificationId, request, Void.class);
    }

    public <T> ResponseEntity<T> updateSpecification(String tenantId, String specificationId,
                                                     SpecificationUpdateRequest request,
                                                     Class<T> responseClass) {
        HttpEntity<?> httpRequest = new HttpEntity<>(request, apiHeaders(tenantId));
        return client.exchange(url("/api/v1/specifications/{specificationId}"), HttpMethod.PATCH,
                httpRequest, responseClass, specificationId);
    }

    public ResponseEntity<Void> deleteSpecification(String tenantId, String specificationId) {
        return deleteSpecification(tenantId, specificationId, Void.class);
    }

    public <T> ResponseEntity<T> deleteSpecification(String tenantId, String specificationId, Class<T> responseClass) {
        HttpEntity<?> httpRequest = new HttpEntity<>(apiHeaders(tenantId));
        return client.exchange(url("/api/v1/specifications/{specificationId}"), HttpMethod.DELETE, httpRequest,
                responseClass, specificationId);
    }

    public ResponseEntity<SpecificationCreationResponse> createReusableContainerSpecification(String tenant,
                                                                                              String type) {
        SpecificationCreationRequest specificationCreateRequest = newSpecificationCreateRequest(type);
        return createSpecification(tenant, specificationCreateRequest);
    }

    public ResponseEntity<SpecificationCreationResponse> createDispensibleContainerSpecification(String tenant,
                                                                                                 String type) {
        SpecificationCreationRequest specificationCreateRequest = newSpecificationCreateRequest(type);
        specificationCreateRequest.setReusable(false);
        return createSpecification(tenant, specificationCreateRequest);
    }

    public void createSpecifications(String tenant, String itemTypeReusable, String itemTypeDispensible) {
        assertCreated(createReusableContainerSpecification(tenant, itemTypeReusable));
        assertCreated(createDispensibleContainerSpecification(tenant, itemTypeDispensible));
    }

    public <T> ResponseEntity<T> createContainer(String tenantId, ContainerCreateRequest request,
                                                 Class<T> responseClass) {
        HttpHeaders header = newHeader();
        header.add(TENANT_KEY, tenantId);
        HttpEntity<?> httpRequest = new HttpEntity<>(request, header);
        return client.exchange(url("/api/v1/unitization"), HttpMethod.POST,
                httpRequest, responseClass);
    }

    public <T> ResponseEntity<T> addToContainer(String tenantId, AddRequest request,
                                                Class<T> responseClass) {
        HttpHeaders header = newHeader();
        header.add(TENANT_KEY, tenantId);
        HttpEntity<?> httpRequest = new HttpEntity<>(request, header);
        return client.exchange(url("/api/v1/unitization/add"), HttpMethod.PUT,
                httpRequest, responseClass);
    }

    public <T> ResponseEntity<T> updateItem(String tenantId, UpdateRequest request, Class<T> responseClass) {

        HttpHeaders header = newHeader();
        header.add(TENANT_KEY, tenantId);
        HttpEntity<?> httpRequest = new HttpEntity<>(request, header);
        return client.exchange(url("/api/v1/unitization"), HttpMethod.PATCH,
                httpRequest, responseClass);
    }

    public boolean validateCreateContainerResponse(GetItemResponse response,
                                                   ContainerCreateRequest request) {
        assertThat(request.getLabel().getType(),
                is(response.getItems().get(0).getLabels().values().iterator().next().getType()));
        assertThat(request.getLabel().getValue(),
                is(response.getItems().get(0).getLabels().values().iterator().next().getValue()));
        assertThat(request.getCreatedByDocumentId(), is(response.getItems().get(0).getCreatedByDocumentId()));
        assertThat(request.getCreatedByDocumentType(),
                is(response.getItems().get(0).getCreatedByDocumentType()));
        assertThat(request.getFacilityId(), is(response.getItems().get(0).getRootContainerId()));
        assertThat(request.getContainerId(), is(response.getItems().get(0).getContainerId()));
        assertThat(request.getType(), is(response.getItems().get(0).getType()));
        assertThat(request.getUom(), is(response.getItems().get(0).getUom()));
        return true;
    }

    public ResponseEntity<Void> createRootContainerItemType(String rootContainerItemType,
                                                            List<String> rootContainerContainedTypes) {
        ItemTypeCreationRequest request = newRootContainerItemTypeCreationRequest(rootContainerItemType,
                rootContainerContainedTypes);
        HttpEntity<?> httpRequest = new HttpEntity<>(request, newHeader());
        return client.exchange(
                url("/api/v1/type", imsHost), HttpMethod.POST,
                httpRequest, Void.class);
    }

    public ResponseEntity<Void> createRootContainer(String rootContainerId,
                                                                     String rootContainerItemType) {
        RootContainerCreationRequest request = newRootContainerCreationRequest(rootContainerId,
                rootContainerItemType);
        HttpEntity<?> httpRequest = new HttpEntity<>(request, newHeader());
        return client.exchange(
                url("/api/v1/{rootContainerId}", imsHost),
                HttpMethod.POST, httpRequest, Void.class, rootContainerId);
    }

    public ResponseEntity<Void> createItemType(String itemType) {
        ItemTypeCreationRequest request = newItemTypeCreationRequest(itemType);
        HttpEntity<?> httpRequest = new HttpEntity<>(request, newHeader());
        return client.exchange(
                url("/api/v1/type", imsHost), HttpMethod.POST,
                httpRequest, Void.class);
    }

    public void createItemTypes(String itemTypeReusable, String itemTypeDispensible,
                                String rootContainerItemType, List<String> rootContainerContainedTypes) {
        assertNoContent(createItemType(itemTypeReusable));
        assertNoContent(createItemType(itemTypeDispensible));
        assertNoContent(createRootContainerItemType(rootContainerItemType, rootContainerContainedTypes));
    }

    public ResponseEntity<String> getItemFromImsByLabel(String rootContainerId, Label label) {
        HttpEntity<?> httpRequest = new HttpEntity<>(newHeader());
        return client.exchange(
                url("api/v1/{rootContainerId}/item/labels/{labelValue}?labelType={labelType}",
                        imsHost), HttpMethod.GET,
                httpRequest, String.class, rootContainerId, label.getValue(), label.getType());
    }

    public ResponseEntity<String> getItemFromImsById(String rootContainerId, String itemId) {
        HttpEntity<?> httpRequest = new HttpEntity<>(newHeader());
        return client.exchange(
                url("api/v1/{rootContainerId}/item/{itemId}",
                        imsHost), HttpMethod.GET,
                httpRequest, String.class, rootContainerId, itemId);
    }

    public ResponseEntity<LabelMappingCreateResponse> createLabelInLabelService(LabelMappingCreateRequest request,
                                                                                String rootContainerId, String type,
                                                                                String tenant) {
        HttpEntity<?> httpRequest = new HttpEntity<>(request, labelApiHeaders(tenant));
        return client.exchange(
                url("api/v1/{facility_id}/mapping/{entity_type}", labelServiceHost),
                HttpMethod.POST, httpRequest, LabelMappingCreateResponse.class, rootContainerId, type);
    }

    public boolean validateLabelCreationResponse(ResponseEntity<LabelMappingCreateResponse> response, String facilityId,
                                                 String labelType, String labelValue, String type) {
        assertCreated(response);
        assertThat(response.getBody().getFacilityId(), is(facilityId));
        assertThat(response.getBody().getLabels().get(labelType), is(labelValue));
        assertThat(response.getBody().getEntityType(), is(type));
        return true;
    }

    private String url(String urlPath, String baseUrl) {
        return url(urlPath, baseUrl, ImmutableMap.of());
    }

    private String url(String urlPath, String baseUrl, Map<String, Object> requestParams) {
        MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        requestParams.forEach((k, v) -> params.add(k, v.toString()));
        return UriComponentsBuilder.newInstance().scheme("http").host(baseUrl).path(urlPath).queryParams(params).build()
                .toUriString();
    }

    private static HttpHeaders newHeader() {

        HttpHeaders header = new HttpHeaders();
        header.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON);
        return header;
    }

    private HttpHeaders apiHeaders(String tenantId) {

        HttpHeaders header = newHeader();
        header.add(TENANT_KEY, tenantId);
        return header;
    }

    private HttpHeaders labelApiHeaders(String tenantId) {

        HttpHeaders header = newHeader();
        header.add(EKART_CLIENT_KEY, tenantId);
        return header;
    }

    private String url(String urlPath) {

        return url(urlPath, ImmutableMap.of());
    }

    private String url(String urlPath, Map<String, Object> requestParams) {

        MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        requestParams.forEach((k, v) -> params.add(k, v.toString()));

        UriComponents uriComp = UriComponentsBuilder.newInstance().host(host).path(urlPath).queryParams(params).build();
        return "http:" + uriComp.toUriString();
    }
}

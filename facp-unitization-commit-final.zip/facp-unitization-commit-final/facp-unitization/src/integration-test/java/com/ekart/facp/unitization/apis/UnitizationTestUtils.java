package com.ekart.facp.unitization.apis;

import com.ekart.facp.unitization.apis.dtos.*;
import static com.ekart.facp.unitization.common.enums.clients.ims.AttributeName.*;
import com.ekart.facp.unitization.apis.dtos.Attribute;
import com.ekart.facp.unitization.apis.dtos.ContainerCreateRequest;
import com.ekart.facp.unitization.apis.dtos.Label;
import com.ekart.facp.unitization.service.dtos.clients.label_service.request.LabelMapping;
import com.ekart.facp.unitization.service.dtos.clients.label_service.request.LabelMappingCreateRequest;
import com.ekart.facp.unitization.service.dtos.clients.ims.request.ItemCreationRequest;
import com.ekart.facp.unitization.service.dtos.clients.ims.request.ItemCreationRequestAttributes;
import com.ekart.facp.unitization.service.dtos.ItemLabel;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.guava.GuavaModule;
import com.google.common.collect.Lists;
import java.util.List;
import java.util.UUID;
import static org.apache.commons.lang.RandomStringUtils.randomAlphabetic;
import static org.apache.commons.lang.RandomStringUtils.randomAlphanumeric;
/**
 * Created by anurag.gupta on 29/06/16.
 */
public final class UnitizationTestUtils {

    private static final String APP_ID = randomAlphanumeric(8);
    private static final String CREATED_BY_ENTITY_ID = randomAlphanumeric(8);
    private static final String CREATED_BY_ENTITY_TYPE = randomAlphanumeric(8);
    private static final boolean IS_TRANSIENT = true;
    private static final String ATTRIBUTE_TYPE = randomAlphanumeric(8);
    private static final String ATTRIBUTE_VALUE = randomAlphanumeric(8);
    private static final List<Attribute> ATTRIBUTES = Lists.newArrayList(new Attribute(ATTRIBUTE_TYPE,
            ATTRIBUTE_VALUE));
    private static final String UOM = "none";
    private static final String CREATED_BY = randomAlphanumeric(8);
    private static final List<String> ITEM_CONTAINED_TYPES = Lists.newArrayList("bag");
    private static final boolean CONTAINER = true;
    private static final int LAST_READ_CONTAINER_VERSION = 0;
    private static final int QUANTITY = 1;
    private static final String CREATED_BY_DOCUMENT_ID = randomAlphanumeric(8);
    private static final String CREATED_BY_DOCUMENT_TYPE = randomAlphanumeric(8);
    private static final Label LABEL = new Label();
    private static final String FLOW_CONTEXT = randomAlphanumeric(8);
    public static final String STATE_MACHINE = "3PL_MH_UNIT";

    private UnitizationTestUtils() {
        //no need to instantiate it
    }

    public static ItemTypeCreationRequest newRootContainerItemTypeCreationRequest(String itemType,
                                                                                  List<String> containedTypes) {
        ItemTypeCreationRequest request = new ItemTypeCreationRequest();
        request.setContainer(CONTAINER);
        request.setType(itemType);
        request.setContainedTypes(containedTypes);
        return request;
    }

    public static ItemTypeCreationRequest newItemTypeCreationRequest(String itemType) {
        ItemTypeCreationRequest request = new ItemTypeCreationRequest();
        request.setContainer(CONTAINER);
        request.setType(itemType);
        request.setContainedTypes(ITEM_CONTAINED_TYPES);
        return request;
    }

    public static RootContainerCreationRequest newRootContainerCreationRequest(String containerId ,
                                                                               String rootContainerItemType) {
        String idempotenceKey = UUID.randomUUID().toString();
        RootContainerCreationRequest request = new RootContainerCreationRequest();
        RootContainerCreationRequestAttributes requestAttributes = new RootContainerCreationRequestAttributes();
        request.setCreatedByDocumentId(CREATED_BY_DOCUMENT_ID);
        request.setCreatedByDocumentType(CREATED_BY_DOCUMENT_TYPE);
        request.setIdempotenceKey(idempotenceKey);
        request.setRequestedBy(CREATED_BY);
        requestAttributes.setContainerId(containerId);
        requestAttributes.setId(containerId);
        requestAttributes.setLastReadContainerVersion(LAST_READ_CONTAINER_VERSION);
        requestAttributes.setUom(UOM);
        requestAttributes.setQuantity(QUANTITY);
        requestAttributes.setType(rootContainerItemType);
        request.setItemRequests(Lists.newArrayList(requestAttributes));
        return request;
    }

    public static ItemCreationRequest newItemCreationRequest(String containerId, ItemLabel label, String type) {

        String idempotenceKey = UUID.randomUUID().toString();
        ItemCreationRequest request = new ItemCreationRequest();
        ItemCreationRequestAttributes requestAttributes = new ItemCreationRequestAttributes();
        request.setCreatedByDocumentId(CREATED_BY_DOCUMENT_ID);
        request.setCreatedByDocumentType(CREATED_BY_DOCUMENT_TYPE);
        request.setIdempotenceKey(idempotenceKey);
        request.setRequestedBy(CREATED_BY);
        requestAttributes.setContainerId(containerId);
        requestAttributes.setLabels(Lists.newArrayList(label));
        requestAttributes.setUom(UOM);
        requestAttributes.setQuantity(QUANTITY);
        requestAttributes.setType(type);
        request.setItemRequests(Lists.newArrayList(requestAttributes));
        return request;
    }

    public static ContainerCreateRequest containerCreateRequest(String rootContainerId, String type) {
        LABEL.setType(randomAlphanumeric(8));
        LABEL.setValue(randomAlphanumeric(8));
        String idempotenceKey = UUID.randomUUID().toString();
        return containerCreateRequest(rootContainerId, type, idempotenceKey, LABEL);
    }

    public static ContainerCreateRequest containerCreateRequest(String rootContainerId, String type,
                                                                String idempotenceKey) {
        LABEL.setType(randomAlphanumeric(8));
        LABEL.setValue(randomAlphanumeric(8));
        return containerCreateRequest(rootContainerId, type, idempotenceKey, LABEL);
    }

    public static ContainerCreateRequest containerCreateRequest(String rootContainerId, String type,
                                                                Label label) {
        String idempotenceKey = UUID.randomUUID().toString();
        return containerCreateRequest(rootContainerId, type, idempotenceKey, label);
    }

    public static ContainerCreateRequest containerCreateRequest(String rootContainerId, String type,
                                                                String idempotenceKey, Label label) {
        ContainerCreateRequest creationRequest = new ContainerCreateRequest();
        creationRequest.setAppId(APP_ID);
        creationRequest.setContainerId(rootContainerId);
        creationRequest.setCreatedBy(CREATED_BY);
        creationRequest.setCreatedByDocumentId(CREATED_BY_DOCUMENT_ID);
        creationRequest.setCreatedByDocumentType(CREATED_BY_DOCUMENT_TYPE);
        creationRequest.setCreatedByEntityId(CREATED_BY_ENTITY_ID);
        creationRequest.setCreatedByEntityType(CREATED_BY_ENTITY_TYPE);
        creationRequest.setFacilityId(rootContainerId);
        creationRequest.setIdempotenceKey(idempotenceKey);
        creationRequest.setIsTransient(IS_TRANSIENT);
        creationRequest.setStateMachineId(STATE_MACHINE);
        creationRequest.setFlowContext(FLOW_CONTEXT);
        creationRequest.setType(type);
        creationRequest.setUom(UOM);
        creationRequest.setAttributes(ATTRIBUTES);
        creationRequest.setLabel(label);
        return creationRequest;
    }

    public static LabelMappingCreateRequest newlabelMappingCreateRequest(LabelMapping label) {
        return new LabelMappingCreateRequest(CREATED_BY, Lists.newArrayList(label));
    }

    public static AddRequest createAddRequest(String containerLabel, String containerType, String containerLabelType,
                                              String facilityId, String flowContext, String stateMachineId,
                                              List<Unitizable> unitizables) {
        AddRequest addRequest = new AddRequest();
        addRequest.setIdempotenceKey(randomAlphanumeric(20));
        addRequest.setAppId("MH");
        addRequest.setCreatedByEntityType(randomAlphanumeric(20));
        addRequest.setCreatedByEntityId(randomAlphanumeric(20));
        addRequest.setContainerLabel(containerLabel);
        addRequest.setContainerLabelType(containerLabelType);
        addRequest.setContainerType(containerType);
        addRequest.setFacilityId(facilityId);
        addRequest.setFlowContext(flowContext);
        addRequest.setStateMachineId(stateMachineId);
        addRequest.setUnitizables(unitizables);
        addRequest.setRequestedBy("some_random_guy_moving");
        return addRequest;
    }

    public static List<Unitizable> createUnitizableRequests(String labelType, String stateMachineId, String... labels) {

        List<Unitizable> unitizables = Lists.newArrayListWithExpectedSize(labels.length);
        for (String label : labels) {
            Unitizable unitizable = new Unitizable();
            unitizable.setLabelType(labelType);
            unitizable.setLabel(label);
            unitizable.setStateMachineId(stateMachineId);
            unitizables.add(unitizable);
        }
        return unitizables;
    }

    public static UpdateRequest createUpdateRequest(String containerType, String label, String facilityId,
                                                    String flowContext, String labelType, String stateMachineId,
                                                    String transitionName) {

        UpdateRequest updateRequest = new UpdateRequest();
        UpdateRequestItem updateRequestItem = new UpdateRequestItem();
        updateRequest.setIdempotenceKey(randomAlphabetic(20));
        updateRequest.setAppId("MH");
        updateRequest.setCreatedByEntityType(randomAlphabetic(20));
        updateRequest.setCreatedByEntityId(randomAlphabetic(20));
        updateRequest.setFacilityId(facilityId);
        updateRequest.setRequestedBy(randomAlphabetic(20));

        updateRequestItem.setType(containerType);
        updateRequestItem.setLabel(label);
        updateRequest.setFlowContext(flowContext);
        updateRequestItem.setLabelType(labelType);
        updateRequestItem.setStateMachineId(stateMachineId);
        updateRequestItem.setTransitionName(transitionName);

        updateRequest.setUpdateRequestItems(Lists.newArrayList(updateRequestItem));
        return updateRequest;
    }

    public static ContainerCreateRequest createTransientContainer(String containerType, String label,
                                                                  String labelType, String rootContainerId) {

        ContainerCreateRequest request = createContainer(containerType, label, labelType, rootContainerId);
        request.setIsTransient(true);
        return request;
    }

    public static ContainerCreateRequest createContainer(String containerType, String label, String labelType,
                                                         String rootContainerId) {

        ContainerCreateRequest request = containerCreateRequest(rootContainerId, containerType, randomAlphabetic(20),
                new Label(labelType, label));
        request.setFlowContext("3PL");
        request.setAppId("MH");
        request.setIsTransient(false);
        return request;
    }

    public static ContainerCreateRequest createContainerWithWeight(String containerType, String label,
                                                                   String labelType,
                                                                   String rootContainerId, double weight) {

        ContainerCreateRequest request = createContainer(containerType, label, labelType, rootContainerId);
        request.setAttributes(Lists.newArrayList(new Attribute(WEIGHT.name(), String.valueOf(weight))));
        return request;
    }

    public static ObjectMapper objectMapper() {
        ObjectMapper objectMapper = new ObjectMapper()
                .configure(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS, true)
                .configure(JsonGenerator.Feature.WRITE_BIGDECIMAL_AS_PLAIN, true);
        objectMapper.registerModule(new GuavaModule());
        return objectMapper;
    }
}

package com.ekart.facp.unitization.apis.controller;

import com.ekart.facp.unitization.apis.BaseIntegrationTest;
import com.ekart.facp.unitization.apis.dtos.ErrorMessage;
import com.ekart.facp.unitization.apis.dtos.Specification;
import com.ekart.facp.unitization.apis.dtos.SpecificationCreationRequest;

import static org.apache.commons.lang.RandomStringUtils.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.http.ResponseEntity;

import static com.ekart.facp.unitization.apis.TestUtils.getSpecificationResponse;
import static com.ekart.facp.unitization.apis.TestUtils.newSpecificationCreateRequest;
import static org.unitils.reflectionassert.ReflectionAssert.assertLenientEquals;
import static com.ekart.facp.unitization.common.ErrorCode.*;

/**
 * Created by anuj.chaudhary on 26/04/16.
 */
public class SpecificationSearchControllerIntegrationTest extends BaseIntegrationTest {

    private String tenant;
    private String type;

    @Before
    public void setUp() {
        tenant = randomAlphabetic(10);
        type = randomAlphabetic(10);
    }

    @Test
    public void shouldReturnActiveSpecificationDetailsByTenantIdAndType() {
        API.createSpecification(tenant, newSpecificationCreateRequest(type));
        Specification expectedSpecification = getSpecificationResponse(
                API.getSpecificationByType(tenant, type).getBody().getId(), tenant, type);
        ResponseEntity<Specification> actualSpecification =
                API.getSpecificationByType(tenant, type);

        assertOk(actualSpecification);
        assertLenientEquals(expectedSpecification, actualSpecification.getBody());
    }

    @Test
    public void shouldReturn400WhenSpecificationDoesNotExist() {
        ResponseEntity<ErrorMessage> response =
                API.getSpecificationByType(tenant, type, ErrorMessage.class);
        assertBadRequest(response, SPECIFICATION_NOT_FOUND.name(), "The Specification identified by tenant: " + tenant
                + "  and type " + type + " was not found");
    }


    @Test
    public void shouldReturnInactiveSpecificationDetailsByTenantIdAndType() {
        SpecificationCreationRequest specificationRequest = newSpecificationCreateRequest(type);
        specificationRequest.setActive(false);

        API.createSpecification(tenant, specificationRequest);
        Specification expectedSpecification = getSpecificationResponse(
                API.getInactiveSpecificationByType(tenant, type).getBody().getId(), tenant, type);
        expectedSpecification.setActive(false);
        ResponseEntity<Specification> actualSpecification =
                API.getInactiveSpecificationByType(tenant, type);

        assertOk(actualSpecification);
        assertLenientEquals(expectedSpecification, actualSpecification.getBody());
    }

    @Test
    public void shouldReturn400WhenSpecificationIsNotThere() {
        ResponseEntity<ErrorMessage> response =
                API.getInactiveSpecificationByType(tenant, type, ErrorMessage.class);
        assertBadRequest(response, SPECIFICATION_NOT_FOUND.name(), "The Specification identified by tenant: " + tenant
                + "  and type " + type + " was not found");
    }

}

package com.ekart.facp.unitization.apis;

/**
 * Created by anurag.gupta on 01/07/16.
 */
public class RootContainerCreationRequestAttributes {

    private String id;
    private String containerId;
    private String type;
    private String uom;
    private int quantity;
    private int lastReadContainerVersion;

    public String getContainerId() {
        return containerId;
    }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUom() {
        return uom;
    }

    public void setUom(String uom) {
        this.uom = uom;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getLastReadContainerVersion() {
        return lastReadContainerVersion;
    }

    public void setLastReadContainerVersion(int lastReadContainerVersion) {
        this.lastReadContainerVersion = lastReadContainerVersion;
    }

    @Override
    public String toString() {
        return "RootContainerCreationRequestAttributes{"
                + "id='" + id + '\''
                + ", containerId='" + containerId + '\''
                + ", type='" + type + '\''
                + ", uom='" + uom + '\''
                + ", quantity=" + quantity
                + ", LAST_READ_CONTAINER_VERSION=" + lastReadContainerVersion
                + '}';
    }
}

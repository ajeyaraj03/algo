package com.ekart.facp.unitization.apis.controller;

import com.ekart.facp.unitization.apis.BaseIntegrationTest;
import com.ekart.facp.unitization.apis.dtos.*;
import com.google.common.collect.ImmutableMap;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.ResponseEntity;
import org.unitils.reflectionassert.ReflectionComparatorMode;

import java.util.Map;

import static com.ekart.facp.unitization.apis.TestUtils.*;
import static org.apache.commons.lang.RandomStringUtils.randomAlphabetic;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;
import static com.ekart.facp.unitization.common.ErrorCode.*;


/**
 * Created by anuj.chaudhary on 22/04/16.
 */
public class SpecificationControllerIntegrationTest extends BaseIntegrationTest {

    private String tenant;
    private String type;

    @Before
    public void setUp() {
        tenant = randomAlphabetic(10);
        type = randomAlphabetic(10);
    }

    @Test
    public void shouldCreateSpecification() {

        ResponseEntity<SpecificationCreationResponse> specificationCreateResponse = API.createSpecification(tenant,
                newSpecificationCreateRequest(type));
        String specificationId = API.getSpecificationByType(tenant, type).getBody().getId();

        Specification expectedSpecification = getSpecificationResponse(specificationId, tenant, type);
        ResponseEntity<Specification> actualSpecification = API.getSpecificationById(tenant, specificationId);

        assertCreated(specificationCreateResponse);
        compareSpecificationResponse(expectedSpecification, actualSpecification.getBody());
    }


    @Test
    public void shouldReturnSameIdForIdempotentActiveRequest() {
        ResponseEntity<SpecificationCreationResponse> specificationCreateResponse = API.createSpecification(tenant,
                newSpecificationCreateRequest(type));
        assertCreated(specificationCreateResponse);

        ResponseEntity<SpecificationCreationResponse> specificationCreateSecondResponse = API
                .createSpecification(tenant,
                        newSpecificationCreateRequest(type));
        assertCreated(specificationCreateSecondResponse);

        assertThat(specificationCreateResponse.getBody().getSpecificationId(),
                is(specificationCreateSecondResponse.getBody().getSpecificationId()));
    }

    @Test
    public void shouldReturnSameIdForIdempotentInActiveRequest() {
        SpecificationCreationRequest specificationCreationRequest = newSpecificationCreateRequest(type);
        specificationCreationRequest.setActive(false);

        ResponseEntity<SpecificationCreationResponse> specificationCreateResponse = API.createSpecification(tenant,
                specificationCreationRequest);
        assertCreated(specificationCreateResponse);

        ResponseEntity<SpecificationCreationResponse> specificationCreateSecondResponse = API
                .createSpecification(tenant,
                        specificationCreationRequest);
        assertCreated(specificationCreateSecondResponse);
        assertThat(specificationCreateResponse.getBody().getSpecificationId(),
                is(specificationCreateSecondResponse.getBody().getSpecificationId()));
    }


    @Test
    public void shouldReturn400WhenCreatedByIsNotPresent() {
        SpecificationCreationRequest request = newSpecificationCreateRequest(type);
        request.setCreatedBy(null);
        assertBadRequest(API.createSpecification(randomAlphabetic(10), request, ErrorMessage.class),
                VALIDATION_ERROR.name(),
                "[NotNull.specificationCreationRequest.createdBy: createdBy field cannot be null or empty.]");
    }

    @Test
    public void shouldReturnSpecificationDetailsById() {
        API.createSpecification(tenant, newSpecificationCreateRequest(type));
        String specificationId = API.getSpecificationByType(tenant, type).getBody().getId();
        Specification expectedSpecification = getSpecificationResponse(specificationId, tenant, type);

        ResponseEntity<Specification> actualSpecification =
                API.getSpecificationById(tenant, specificationId);
        assertOk(actualSpecification);
        assertReflectionEquals(expectedSpecification, actualSpecification.getBody(),
                ReflectionComparatorMode.IGNORE_DEFAULTS);
    }

    @Test
    public void shouldReturn400WhenSpecificationByIdDoesNotExist() {
        String specId = randomAlphabetic(10);
        ResponseEntity<ErrorMessage> response = API.getSpecificationById(tenant, specId, ErrorMessage.class);
        assertBadRequest(response, SPECIFICATION_NOT_FOUND.name(), "Specification with id : " + specId + " not found");
    }


    @Test
    public void shouldUpdateActiveSpecification() {
        API.createSpecification(tenant, newSpecificationCreateRequest(type));
        String specificationId = API.getSpecificationByType(tenant, type).getBody().getId();

        Map<String, String> attribute = ImmutableMap.of(randomAlphabetic(10), randomAlphabetic(10));
        String updatedBy = randomAlphabetic(10);

        SpecificationUpdateRequest request = specificationUpdateRequest();
        request.setUpdatedBy(updatedBy);
        request.setActive(false);
        request.setReusable(false);
        request.setAttributes(attribute);

        Specification expectedResponse = getSpecificationResponse(specificationId, tenant, type);
        expectedResponse.setUpdatedBy(updatedBy);
        expectedResponse.setActive(false);
        expectedResponse.setReusable(false);
        expectedResponse.setAttributes(attribute);

        ResponseEntity<Void> updateResponse = API.updateSpecification(tenant, specificationId, request);
        assertOk(updateResponse);
        ResponseEntity<Specification> specification = API.getSpecificationById(tenant, specificationId);
        compareSpecificationResponse(expectedResponse, specification.getBody());
    }

    @Test
    public void shouldUpdateInActiveSpecificationIfAlsoUpdatingFlag() {
        SpecificationCreationRequest specificationRequest = newSpecificationCreateRequest(type);
        specificationRequest.setActive(false);
        API.createSpecification(tenant, specificationRequest);
        String specificationId = API.getInactiveSpecificationByType(tenant, type).getBody().getId();

        Map<String, String> attribute = ImmutableMap.of(randomAlphabetic(10), randomAlphabetic(10));
        String updatedBy = randomAlphabetic(10);

        SpecificationUpdateRequest request = specificationUpdateRequest();
        request.setUpdatedBy(updatedBy);
        request.setActive(true);
        request.setReusable(false);
        request.setAttributes(attribute);

        Specification expectedResponse = getSpecificationResponse(specificationId, tenant, type);
        expectedResponse.setUpdatedBy(updatedBy);
        expectedResponse.setActive(true);
        expectedResponse.setReusable(false);
        expectedResponse.setAttributes(attribute);

        ResponseEntity<Void> updateResponse = API.updateSpecification(tenant, specificationId, request);
        assertOk(updateResponse);
        ResponseEntity<Specification> specification = API.getSpecificationById(tenant, specificationId);
        compareSpecificationResponse(expectedResponse, specification.getBody());
    }


    @Test
    public void shouldReturn400WhenSpecificationDoesNotExistsForUpdate() {
        String specId = randomAlphabetic(10);

        ResponseEntity<ErrorMessage> response = API.updateSpecification(tenant, specId,
                specificationUpdateRequest(), ErrorMessage.class);

        assertBadRequest(response, SPECIFICATION_NOT_FOUND.name(), "Specification with id : " + specId + " not found");
    }

    @Test
    public void shouldThrowErrorWhileDeleteSpecification() {
        API.createSpecification(tenant, newSpecificationCreateRequest(type));
        String specificationId = API.getSpecificationByType(tenant, type).getBody().getId();
        Specification expectedResponse = getSpecificationResponse(specificationId, tenant, type);
        expectedResponse.setActive(false);

        ResponseEntity<Void> updateResponse = API.deleteSpecification(tenant, specificationId);
        assertOk(updateResponse);
        ResponseEntity<ErrorMessage> response = API.getSpecificationById(tenant, specificationId, ErrorMessage.class);
        assertBadRequest(response, SPECIFICATION_NOT_FOUND.name(),
                "Specification with id : " + specificationId + " not found");
    }

    @Test
    public void shouldDeleteSpecification() {
        API.createSpecification(tenant, newSpecificationCreateRequest(type));
        String specificationId = API.getSpecificationByType(tenant, type).getBody().getId();
        ResponseEntity<SuccessResponse> response = API.deleteSpecification(tenant, specificationId,
                SuccessResponse.class);

        assertOk(response);
    }


}

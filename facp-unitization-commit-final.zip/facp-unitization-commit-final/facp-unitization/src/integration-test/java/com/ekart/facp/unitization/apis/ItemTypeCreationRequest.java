package com.ekart.facp.unitization.apis;

import java.util.List;

/**
 * Created by anurag.gupta on 01/07/16.
 */
public class ItemTypeCreationRequest {

    private List<String> containedTypes;
    private boolean container;
    private String type;

    public List<String> getContainedTypes() {
        return containedTypes;
    }

    public void setContainedTypes(List<String> containedTypes) {
        this.containedTypes = containedTypes;
    }

    public boolean getContainer() {
        return container;
    }

    public void setContainer(boolean container) {
        this.container = container;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "ItemTypeCreationRequest{"
                + "containedTypes=" + containedTypes
                + ", container=" + container
                + ", type='" + type + '\''
                + '}';
    }
}

package com.ekart.facp.unitization.service.dtos;

import java.util.List;

/**
 * Created by avinash.r on 13/07/16.
 */
public class AddRequest {

    private String idempotenceKey;
    private String createdByEntityType;
    private String createdByEntityId;
    private String facilityId;
    private String appId;
    private String flowContext;
    private String containerLabelType;
    private String containerLabel;
    private String containerType;
    private String stateMachineId;
    private List<Unitizable> unitizables;
    private String requestedBy;

    public String getIdempotenceKey() {
        return idempotenceKey;
    }

    public void setIdempotenceKey(String idempotenceKey) {
        this.idempotenceKey = idempotenceKey;
    }

    public String getCreatedByEntityType() {
        return createdByEntityType;
    }

    public void setCreatedByEntityType(String createdByEntityType) {
        this.createdByEntityType = createdByEntityType;
    }

    public String getCreatedByEntityId() {
        return createdByEntityId;
    }

    public void setCreatedByEntityId(String createdByEntityId) {
        this.createdByEntityId = createdByEntityId;
    }

    public String getFacilityId() {
        return facilityId;
    }

    public void setFacilityId(String facilityId) {
        this.facilityId = facilityId;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getFlowContext() {
        return flowContext;
    }

    public void setFlowContext(String flowContext) {
        this.flowContext = flowContext;
    }

    public String getContainerLabelType() {
        return containerLabelType;
    }

    public void setContainerLabelType(String containerLabelType) {
        this.containerLabelType = containerLabelType;
    }

    public String getContainerLabel() {
        return containerLabel;
    }

    public void setContainerLabel(String containerLabel) {
        this.containerLabel = containerLabel;
    }

    public String getContainerType() {
        return containerType;
    }

    public void setContainerType(String containerType) {
        this.containerType = containerType;
    }

    public String getStateMachineId() {
        return stateMachineId;
    }

    public void setStateMachineId(String stateMachineId) {
        this.stateMachineId = stateMachineId;
    }

    public List<Unitizable> getUnitizables() {
        return unitizables;
    }

    public void setUnitizables(List<Unitizable> unitizables) {
        this.unitizables = unitizables;
    }

    public String getRequestedBy() {
        return requestedBy;
    }

    public void setRequestedBy(String requestedBy) {
        this.requestedBy = requestedBy;
    }

    @Override
    public String toString() {
        return "AddRequest{" + "idempotenceKey='" + idempotenceKey + '\'' + ", createdByEntityType='"
                + createdByEntityType + '\''
                + ", createdByEntityId='" + createdByEntityId + '\'' + ", facilityId='" + facilityId + '\''
                + ", appId='" + appId + '\'' + ", flowContext='" + flowContext + '\''
                + ", containerLabelType='" + containerLabelType + '\'' + ", containerLabel='" + containerLabel + '\''
                + ", containerType='" + containerType + '\'' + ", stateMachineId='" + stateMachineId + '\''
                + ", unitizables=" + unitizables + ", requestedBy='" + requestedBy + '\'' + '}';
    }
}

package com.ekart.facp.unitization.apis.dtos;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;

/**
 * Created by anurag.gupta on 06/07/16.
 */
@ApiModel
public class Label {

    @ApiModelProperty(name = "type", value = "Label type of the container")
    @JsonProperty(value = "type")
    @NotNull(message = "{container.labelType.notnull}")
    private String type;

    @ApiModelProperty(name = "value", value = "Label value of the container")
    @JsonProperty(value = "value")
    @NotNull(message = "{container.labelValue.notnull}")
    private String value;

    public Label() {
    }

    public Label(String type, String value) {
        this.type = type;
        this.value = value;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "Label{"
                + "type='" + type + '\''
                + ", value=" + value
                + '}';
    }
}

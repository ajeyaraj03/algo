package com.ekart.facp.unitization.service.exceptions;

import static com.ekart.facp.unitization.common.ErrorCode.CONTAINER_ALREADY_EXISTS;


/**
 * Created by anurag.gupta on 13/06/16.
 */
public class ContainerAlreadyExistsException extends BaseException {

    private static final long serialVersionUID = -8719315920559315309L;

    public ContainerAlreadyExistsException(String message) {
        super(message, CONTAINER_ALREADY_EXISTS.name());
    }
}

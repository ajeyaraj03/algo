package com.ekart.facp.unitization.dal.models.common;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.Version;

/**
 * Created by ajeya.hb on 24/03/16.
 */
@MappedSuperclass
public abstract class BaseEntity {
    @Column(name = "created_at_epoch", updatable = false, nullable = false)
    private long createdAtEpoch;

    @Column(name = "updated_at_epoch", nullable = false)
    private long updatedAtEpoch;

    @Version
    @Column(name = "version")
    private int version;

    @Column(name = "archived", nullable = false)
    private boolean archived = false;

    public long getCreatedAtEpoch() {
        return createdAtEpoch;
    }

    public void setCreatedAtEpoch(long createdAtEpoch) {
        this.createdAtEpoch = createdAtEpoch;
    }

    public long getUpdatedAtEpoch() {
        return updatedAtEpoch;
    }

    public void setUpdatedAtEpoch(long updatedAtEpoch) {
        this.updatedAtEpoch = updatedAtEpoch;
    }

    public boolean isArchived() {
        return archived;
    }

    public void setArchived(boolean archived) {
        this.archived = archived;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

}

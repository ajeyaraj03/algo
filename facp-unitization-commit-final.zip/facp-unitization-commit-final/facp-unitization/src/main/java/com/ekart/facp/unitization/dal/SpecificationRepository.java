package com.ekart.facp.unitization.dal;


import com.ekart.facp.unitization.dal.models.Specification;
import com.ekart.facp.unitization.service.constants.CacheNames;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

/**
 * Created by ajeya.hb on 08/03/16.
 */
public interface SpecificationRepository {

    @Query("select spec from Specification spec where spec.id = :#{#id} and spec.archived=0")
    Optional<Specification> findById(@Param("id") String id);

    @Cacheable(cacheNames = CacheNames.SPECIFICATION, key = "#root.args[0] + #root.args[1]",
            unless = CacheNames.OPTIONAL_ABSENT)
    @Query("select spec from Specification spec where spec.tenant = :#{#tenant} "
            + "and spec.type=:#{#type} and spec.archived=0")
    Specification findByTenantAndType(@Param("tenant") String tenant, @Param("type") String type);

    //TODO making it return Optional overriding saveAndFlush and later modify findByTenantAndType to return Optional
    @CachePut(cacheNames = CacheNames.SPECIFICATION, key = "#root.args[0].tenant + #root.args[0].type",
            condition = "!#root.args[0].archived", unless = CacheNames.OPTIONAL_ABSENT)
    @CacheEvict(cacheNames = CacheNames.SPECIFICATION, key = "#root.args[0].tenant + #root.args[0].type",
            condition = "#root.args[0].archived")
    Specification saveAndFlush(Specification specification);

    void insertAndFlush(Specification specification);
}

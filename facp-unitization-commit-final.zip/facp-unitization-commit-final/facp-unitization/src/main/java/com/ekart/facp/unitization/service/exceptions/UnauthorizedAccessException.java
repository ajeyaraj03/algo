package com.ekart.facp.unitization.service.exceptions;
import static com.ekart.facp.unitization.common.ErrorCode.UNAUTHORIZED_ACCESS;
/**
 * @author vijay.daniel
 */
public class UnauthorizedAccessException extends BaseException {

    public UnauthorizedAccessException(String message, Throwable cause) {

        super(message, UNAUTHORIZED_ACCESS.name(), cause);
    }
}

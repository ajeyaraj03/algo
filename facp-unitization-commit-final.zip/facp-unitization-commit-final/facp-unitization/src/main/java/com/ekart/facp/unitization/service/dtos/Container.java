package com.ekart.facp.unitization.service.dtos;

import javax.annotation.ParametersAreNonnullByDefault;
import java.util.List;

/**
 * Created by anurag.gupta on 27/06/16.
 */
@ParametersAreNonnullByDefault
public class Container {

    private String idempotenceKey;
    private String containerId;
    private String createdBy;
    private String type;
    private String createdByDocumentId;
    private String createdByDocumentType;
    private String createdByEntityId;
    private String createdByEntityType;
    private String stateMachineId;
    private String flowContext;
    private String uom;
    private String appId;
    private String facilityId;
    private List<ItemAttribute> attributes;
    private ItemLabel label;
    private boolean isTransient;

    public String getIdempotenceKey() {
        return idempotenceKey;
    }

    public void setIdempotenceKey(String idempotenceKey) {
        this.idempotenceKey = idempotenceKey;
    }

    public String getContainerId() {
        return containerId;
    }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCreatedByDocumentId() {
        return createdByDocumentId;
    }

    public void setCreatedByDocumentId(String createdByDocumentId) {
        this.createdByDocumentId = createdByDocumentId;
    }

    public String getCreatedByDocumentType() {
        return createdByDocumentType;
    }

    public void setCreatedByDocumentType(String createdByDocumentType) {
        this.createdByDocumentType = createdByDocumentType;
    }

    public String getCreatedByEntityId() {
        return createdByEntityId;
    }

    public void setCreatedByEntityId(String createdByEntityId) {
        this.createdByEntityId = createdByEntityId;
    }

    public String getCreatedByEntityType() {
        return createdByEntityType;
    }

    public void setCreatedByEntityType(String createdByEntityType) {
        this.createdByEntityType = createdByEntityType;
    }

    public String getStateMachineId() {
        return stateMachineId;
    }

    public void setStateMachineId(String stateMachineId) {
        this.stateMachineId = stateMachineId;
    }

    public String getUom() {
        return uom;
    }

    public void setUom(String uom) {
        this.uom = uom;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getFacilityId() {
        return facilityId;
    }

    public void setFacilityId(String facilityId) {
        this.facilityId = facilityId;
    }

    public List<ItemAttribute> getAttributes() {
        return attributes;
    }

    public void setAttributes(List<ItemAttribute> attributes) {
        this.attributes = attributes;
    }

    public ItemLabel getLabel() {
        return label;
    }

    public void setLabel(ItemLabel label) {
        this.label = label;
    }

    public boolean isTransient() {
        return isTransient;
    }

    public void setTransient(boolean aTransient) {
        isTransient = aTransient;
    }

    public String getFlowContext() {
        return flowContext;
    }

    public void setFlowContext(String flowContext) {
        this.flowContext = flowContext;
    }

    @Override
    public String toString() {
        return "Container{"
                + "idempotenceKey='" + idempotenceKey + '\''
                + ", containerId='" + containerId + '\''
                + ", createdBy='" + createdBy + '\''
                + ", type='" + type + '\''
                + ", createdByDocumentId='" + createdByDocumentId + '\''
                + ", createdByDocumentType='" + createdByDocumentType + '\''
                + ", createdByEntityId='" + createdByEntityId + '\''
                + ", createdByEntityType='" + createdByEntityType + '\''
                + ", stateMachineId='" + stateMachineId + '\''
                + ", uom='" + uom + '\''
                + ", UNITIZATION_APP_ID='" + appId + '\''
                + ", facilityId='" + facilityId + '\''
                + ", attributes=" + attributes
                + ", label=" + label
                + ", isTransient=" + isTransient
                + ", flowContext=" + flowContext
                + '}';
    }
}

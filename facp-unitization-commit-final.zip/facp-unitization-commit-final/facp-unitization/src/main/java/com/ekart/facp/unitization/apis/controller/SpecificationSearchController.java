package com.ekart.facp.unitization.apis.controller;

import com.codahale.metrics.annotation.ExceptionMetered;
import com.codahale.metrics.annotation.Timed;
import com.ekart.facp.unitization.apis.dtos.ErrorMessage;
import com.ekart.facp.unitization.apis.dtos.Specification;
import com.ekart.facp.unitization.apis.mapper.ApiDtoToServiceEntityMapper;
import com.ekart.facp.unitization.service.SpecificationService;
import com.ekart.facp.unitization.service.utility.TenantContext;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.eclipse.jetty.http.HttpStatus;
import org.hibernate.validator.constraints.NotEmpty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.ThreadSafe;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.ws.rs.core.MediaType;

import static com.ekart.facp.unitization.apis.constants.ApiConstants.TENANT_KEY;
import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Created by anuj.chaudhary on 26/04/16.
 */

@ThreadSafe
@RequestMapping("/api/v1/search")
@ParametersAreNonnullByDefault
@Api(protocols = "http", tags = "Unit Load Definition Search Management")
public class SpecificationSearchController extends BaseController {

    private static final Logger LOGGER = LoggerFactory.getLogger(SpecificationSearchController.class);
    private final SpecificationService specificationService;
    private final ApiDtoToServiceEntityMapper mapper;

    public SpecificationSearchController(SpecificationService specificationService,
                                         ApiDtoToServiceEntityMapper mapper) {
        this.specificationService = checkNotNull(specificationService);
        this.mapper = checkNotNull(mapper);
    }

    @ApiOperation(nickname = "get_active_specification_by_type", value = "Search active Specification")
    @ApiResponses({
            @ApiResponse(code = HttpStatus.OK_200, message = "The Specification retrieved successfully",
                    response = Specification.class),
            @ApiResponse(code = HttpStatus.BAD_REQUEST_400,
                    message = "Unable retrieve specification, "
                            + "Error due to business validations. ",
                    response = ErrorMessage.class),
            @ApiResponse(code = HttpStatus.INTERNAL_SERVER_ERROR_500,
                    message = "Internal server error. An unexpected error occurred",
                    response = ErrorMessage.class)})
    @Timed
    @ExceptionMetered
    @RequestMapping(method = RequestMethod.GET, path = "/specifications/{type}",
            produces = MediaType.APPLICATION_JSON)

    public ResponseEntity<?> getActiveSpecificationByType(
            @RequestHeader(value = TENANT_KEY,
                    required = true) @Valid @NotEmpty String tenant,
            @PathVariable("type") @Valid @NotNull String type) {
        return ok(mapper.specificationEntityToSpecificationResponse(specificationService.getByType(
                new TenantContext(tenant), type)));
    }

    @ApiOperation(nickname = "get_inactive_specification_by_type", value = "Search inactive Specification")
    @ApiResponses({
            @ApiResponse(code = HttpStatus.OK_200, message = "The Specification retrieved successfully",
                    response = Specification.class),
            @ApiResponse(code = HttpStatus.BAD_REQUEST_400,
                    message = "Unable retrieve specification, "
                            + "Error due to business validations. ",
                    response = ErrorMessage.class),
            @ApiResponse(code = HttpStatus.INTERNAL_SERVER_ERROR_500,
                    message = "Internal server error. An unexpected error occurred",
                    response = ErrorMessage.class)})
    @Timed
    @ExceptionMetered
    @RequestMapping(method = RequestMethod.GET, path = "/inactive/specifications/{type}",
            produces = MediaType.APPLICATION_JSON)

    public ResponseEntity<?> getInactiveSpecificationByType(
            @RequestHeader(value = TENANT_KEY,
                    required = true) @Valid @NotEmpty String tenant,
            @PathVariable("type") @Valid @NotNull String type) {

        return ok(mapper.specificationEntityToSpecificationResponse(specificationService
                .getInactiveByType(new TenantContext(tenant), type)));
    }

}

package com.ekart.facp.unitization.apis.constants;

/**
 * Created by ajeya.hb on 08/07/16.
 */
public final class ApiConstants {
    private ApiConstants() {
        //restrict constructor instantiation
    }

    public static final String TENANT_KEY = "X-Tenant-Context";
    public static final String ADD_TO_CONTAINER = "add_to_container";
    public static final String ADD_UNITIZABLES = "add_unitizables";
    public static final String DELETED_VALUE = "deletedValues";
    public static final String MODIFIED_VALUE = "modifiedValues";
    public static final int UPDATE_REQUEST_BULK_SIZE = 1;
    public static final int MAX_LABELS_TO_BE_ADDED = 5;
    public static final int MAX_UNITIZABLES_TO_BE_ADDED = 20;
}

package com.ekart.facp.unitization.service.validators;

import com.ekart.facp.unitization.service.dtos.Unitizable;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.Item;
import com.ekart.facp.unitization.service.exceptions.AddException;
import com.ekart.facp.unitization.service.exceptions.LabelNotFoundException;
import static com.ekart.facp.unitization.service.utility.UnitizationUtility.*;
import com.google.common.collect.Maps;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static com.ekart.facp.unitization.common.enums.clients.ims.AttributeName.*;
import static com.ekart.facp.unitization.service.utility.UnitizationUtility.getIsTransientFlag;
import static com.ekart.facp.unitization.service.utility.UnitizationUtility.getOwner;

/**
 * Created by avinash.r on 19/07/16.
 */
public class UnitizationValidator {

    public void validateContainerAttributes(Map<String, String> specificationAttributes,
                                            List<Item> unitizables, Item container) {

        if (!specificationAttributes.isEmpty() && specificationAttributes.containsKey(MAX_WEIGHT.name())) {
            List<String> itemsWithWeight = getUnitizablesWithWeight(unitizables);
            List<String> itemsWithoutWeight = getUnitizablesWithoutWeight(unitizables);

            if (!itemsWithWeight.isEmpty() && !itemsWithoutWeight.isEmpty() && !getIsTransientFlag(container)) {
                throw new AddException("Some items have weight and some don't");
            }

            if (container.getAttributes().containsKey(UNITIZATION_CURRENT_WEIGHT.name())
                    && !itemsWithoutWeight.isEmpty()) {
                throw new AddException("Can not add items without having weight attribute", itemsWithoutWeight);
            }

            long currentNoOfItemsInContainer = Long.parseLong(container.getAttributes()
                    .get(UNITIZATION_CURRENT_NO_OF_ITEMS.name()).getValue().toString());

            if (currentNoOfItemsInContainer > 0
                    && !container.getAttributes().containsKey(UNITIZATION_CURRENT_WEIGHT.name())
                    && !itemsWithWeight.isEmpty()) {

                throw new AddException("Adding items with weight not allowed", itemsWithWeight);
            }
        }
    }

    public void validateUnitizables(List<Unitizable> unitizables) {

        Set<String> labelTypes = unitizables.stream().map(elt -> elt.getLabelType())
                .collect(Collectors.toSet());

        if (labelTypes.size() > 1) {
            throw new AddException("Unitizables are not of same label type", labelTypes);
        }

        List<String> labelValues = unitizables.stream().map(elt -> elt.getLabel())
                .distinct().collect(Collectors.toList());

        if (labelValues.stream().distinct().count() < unitizables.size()) {
            throw new AddException("Duplicate labels found", labelValues);
        }
    }

    public void validateUnitizableLabelsAndState(List<Item> items, String labelType, List<String> labelValues,
                                         String flowContext, String appId) {
        /**
         * Fetch items for all labels from IMS and validate if
         * any label is not present in IMS
         */

        //throw error if unitizables are not of same type
        List<String> uniqueTypes = items.stream().map(elt -> elt.getType()).distinct().collect(Collectors.toList());
        if (uniqueTypes.size() > 1) {
            throw new AddException("Unitizables are not of same type", uniqueTypes);
        }

        //check if all labels are present
        String unitizableProcessOwner = getOwner(flowContext, appId, items.get(0).getType());

        Map<String, String> labelAndStatusMap = Maps.newHashMap();
        items.stream().forEach(elt -> {
            if (elt.getLabels().containsKey(labelType)) {
                labelAndStatusMap.put(elt.getLabels().get(labelType).getValue(),
                        elt.getStatuses().get(unitizableProcessOwner).getValue());
            }
        });

        labelValues.stream().forEach(elt -> {
            if (!labelAndStatusMap.containsKey(elt)) {
                throw new LabelNotFoundException(elt, labelType);
            }
        });

        /**
         * Assuming all the items are in same state
         * If they are not in same state currently throwing error
         * will change when FSM will provide bulk API for states and transitions
         */
        List<String> states = labelAndStatusMap.entrySet().stream().map(elt -> elt.getValue().toString())
                .distinct().collect(Collectors.toList());
        if (states.size() > 1) {
            throw new AddException("Items are not in same state.", labelAndStatusMap);
        }
    }
}

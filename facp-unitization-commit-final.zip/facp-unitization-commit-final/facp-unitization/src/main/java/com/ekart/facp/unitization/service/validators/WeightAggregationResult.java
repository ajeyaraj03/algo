package com.ekart.facp.unitization.service.validators;

import java.math.BigDecimal;

/**
 * Created by avinash.r on 04/08/16.
 */
public class WeightAggregationResult extends AggregationResult {

    private BigDecimal aggregatedWeight;

    public WeightAggregationResult(BigDecimal aggregatedWeight) {
        this.aggregatedWeight = aggregatedWeight;
    }

    public BigDecimal getAggregatedWeight() {
        return aggregatedWeight;
    }

    public void setAggregatedWeight(BigDecimal aggregatedWeight) {
        this.aggregatedWeight = aggregatedWeight;
    }

    @Override
    public String toString() {
        return "WeightAggregationResult{" + "aggregatedWeight=" + aggregatedWeight + '}';
    }
}

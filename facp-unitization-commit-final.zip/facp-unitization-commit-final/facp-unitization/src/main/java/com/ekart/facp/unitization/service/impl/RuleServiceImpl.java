package com.ekart.facp.unitization.service.impl;

import static com.ekart.facp.unitization.common.enums.clients.ims.AttributeName.*;
import com.ekart.facp.unitization.service.RuleService;

import java.math.BigDecimal;
import java.util.Map;

/**
 * Created by avinash.r on 13/07/16.
 */
public class RuleServiceImpl implements RuleService {

    @Override
    public boolean maxWeightRule(Map<String, String> attributes, BigDecimal totalWeight) {

        BigDecimal maxWeight = new BigDecimal(attributes.get(MAX_WEIGHT.name()));
        return (maxWeight.compareTo(totalWeight) >= 0);
    }

    @Override
    public boolean maxNoOfItemsRule(Map<String, String> attributes, long noOfItems) {

        long maxNoOfItems = Long.parseLong(attributes.get(MAX_NO_OF_ITEMS.name()));
        return maxNoOfItems >= noOfItems;
    }
}

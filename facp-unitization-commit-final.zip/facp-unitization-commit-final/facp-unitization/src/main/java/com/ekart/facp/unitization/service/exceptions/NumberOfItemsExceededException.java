package com.ekart.facp.unitization.service.exceptions;

import static com.ekart.facp.unitization.common.ErrorCode.NUMBER_OF_ITEMS_EXCEEDED_EXCEPTION;

/**
 * Created by avinash.r on 13/07/16.
 */
public class NumberOfItemsExceededException extends BaseException {

    private static final long serialVersionUID = 5627202640294818304L;

    public NumberOfItemsExceededException(String id, long maxNoOfItems, long totalItems) {
        super("Maximum number of items allowed for item " + id + "are " + maxNoOfItems + " but total provided are "
                + totalItems, NUMBER_OF_ITEMS_EXCEEDED_EXCEPTION.name());
    }
}

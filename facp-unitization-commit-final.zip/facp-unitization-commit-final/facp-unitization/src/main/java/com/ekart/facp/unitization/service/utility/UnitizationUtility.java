package com.ekart.facp.unitization.service.utility;

import com.ekart.facp.unitization.service.dtos.SpecificationAttributesToUpdate;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.Item;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.util.List;
import java.util.Map;

import static com.ekart.facp.unitization.common.enums.clients.ims.AttributeName.*;

/**
 * Created by avinash.r on 19/07/16.
 */
public final class UnitizationUtility {

    private UnitizationUtility() {

    }

    public static String getOwner(String flowContext, String appId, String type) {
        return String.join("_", flowContext, appId, type);
    }

    public static boolean getIsTransientFlag(Item container) {

        /**
         * as bulk is also a container so having this isTransient flag
         * if container is type of isTransient then we don't have to validate
         */

        String isTransient = "false";
        if (container.getAttributes().containsKey(UNITIZATION_IS_TRANSIENT.name())) {
            isTransient = container.getAttributes().get(UNITIZATION_IS_TRANSIENT.name())
                    .getValue().toString();
        }
        return isTransient.equals("true");
    }

    public static Map<String, Object> getContainerAttributesToBeModified(SpecificationAttributesToUpdate attributes) {

        Map<String, Object> modifiedAttributes = Maps.newHashMap();
        modifiedAttributes.put(UNITIZATION_CURRENT_NO_OF_ITEMS.name(), attributes.getNoOfItems());
        if (attributes.getWeightAttributeToUpdate() != null) {
            modifiedAttributes.put(UNITIZATION_CURRENT_WEIGHT.name(), attributes.getWeightAttributeToUpdate());
        }
        return modifiedAttributes;
    }

    public static Map<String, Object> getContainerAttributesToBeDeleted(SpecificationAttributesToUpdate attributes) {

        Map<String, Object> deletedAttributes = Maps.newHashMap();
        if (attributes.getWeightAttributeToDelete() != null) {
            deletedAttributes.put(UNITIZATION_CURRENT_WEIGHT.name(), attributes.getWeightAttributeToDelete());
        }
        return deletedAttributes;
    }

    public static boolean isWeightPresentInAllUnitizables(List<Item> unitizables) {

        return getUnitizablesWithoutWeight(unitizables).isEmpty() && !getUnitizablesWithWeight(unitizables).isEmpty();
    }

    public static List<String> getUnitizablesWithWeight(List<Item> unitizables) {

        List<String> unitizablesWithWeight = Lists.newArrayList();
        unitizables.stream().forEach(elt -> {
            if (elt.getAttributes().containsKey(WEIGHT.name())) {
                unitizablesWithWeight.add(elt.getId());
            }
        });
        return unitizablesWithWeight;
    }

    public static List<String> getUnitizablesWithoutWeight(List<Item> unitizables) {

        List<String> unitizablesWithoutWeight = Lists.newArrayList();
        unitizables.stream().forEach(elt -> {
            if (!elt.getAttributes().containsKey(WEIGHT.name())) {
                unitizablesWithoutWeight.add(elt.getId());
            }
        });
        return unitizablesWithoutWeight;
    }
}

package com.ekart.facp.unitization.service.validators;

/**
 * Created by avinash.r on 04/08/16.
 */
public class NumberOfItemsAggregationResult extends AggregationResult {

    private Long noOfItemsToUpdate;

    public NumberOfItemsAggregationResult(Long noOfItemsToUpdate) {
        this.noOfItemsToUpdate = noOfItemsToUpdate;
    }

    public Long getNoOfItemsToUpdate() {
        return noOfItemsToUpdate;
    }

    @Override
    public String toString() {
        return "NumberOfItemsAggregationResult{" + "noOfItemsToUpdate=" + noOfItemsToUpdate + '}';
    }
}

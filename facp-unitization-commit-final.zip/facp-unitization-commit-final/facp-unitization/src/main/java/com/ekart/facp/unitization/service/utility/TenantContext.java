package com.ekart.facp.unitization.service.utility;

/**
 * Created by ajeya.hb on 20/06/16.
 */
public class TenantContext {

    private String tenantName;

    public TenantContext(String tenantName) {
        this.tenantName = tenantName;
    }

    public String getTenantName() {
        return tenantName;
    }

    @Override
    public String toString() {
        return "TenantContext{"
                + "tenantName='" + tenantName + '\''
                + '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof TenantContext)) {
            return false;
        }

        TenantContext that = (TenantContext)o;

        return getTenantName() != null ? getTenantName().equals(that.getTenantName()) : that.getTenantName() == null;

    }

    @Override
    public int hashCode() {
        return getTenantName() != null ? getTenantName().hashCode() : 0;
    }
}

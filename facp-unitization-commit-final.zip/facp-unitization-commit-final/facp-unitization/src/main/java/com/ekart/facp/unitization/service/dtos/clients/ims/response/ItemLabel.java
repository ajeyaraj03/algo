package com.ekart.facp.unitization.service.dtos.clients.ims.response;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.concurrent.Immutable;

/**
 * Created by anurag.gupta on 19/07/16.
 */
@Immutable
public final class ItemLabel {

    private final String type;
    private final String value;

    @JsonCreator
    public ItemLabel(@JsonProperty(value = "type") String type, @JsonProperty(value = "value") String value) {
        this.value = value;
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return "ItemLabel{"
                + "type='" + type + '\''
                + ", value=" + value
                + '}';
    }
}


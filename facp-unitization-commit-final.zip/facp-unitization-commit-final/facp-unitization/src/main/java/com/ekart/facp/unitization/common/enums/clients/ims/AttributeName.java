package com.ekart.facp.unitization.common.enums.clients.ims;

import javax.annotation.concurrent.Immutable;

/**
 * Created by anurag.gupta on 27/06/16.
 */

@Immutable
public enum AttributeName {
    UNITIZATION_APP_ID,
    UNITIZATION_IS_TRANSIENT,
    UNITIZATION_CURRENT_WEIGHT,
    UNITIZATION_CURRENT_NO_OF_ITEMS,
    WEIGHT,
    MAX_WEIGHT,
    MAX_NO_OF_ITEMS,
    UNITIZATION_STATE_MACHINE_ID,
    UNITIZATION_IN_CONTAINER
}

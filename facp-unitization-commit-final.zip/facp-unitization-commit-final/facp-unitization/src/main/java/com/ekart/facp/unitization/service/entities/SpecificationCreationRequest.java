package com.ekart.facp.unitization.service.entities;

import java.util.Map;

/**
 * Created by ajeya.hb on 27/06/16.
 */
public class SpecificationCreationRequest {

    private String type;
    private String createdBy;
    private boolean reusable;
    private boolean active;
    private Map<String, String> attributes;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public boolean isReusable() {
        return reusable;
    }

    public void setReusable(boolean reusable) {
        this.reusable = reusable;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public Map<String, String> getAttributes() {
        return attributes;
    }

    public void setAttributes(Map<String, String> attributes) {
        this.attributes = attributes;
    }

    @Override
    public String toString() {
        return "SpecificationCreationRequest{" + "type='" + type + '\'' + ", createdBy='" + createdBy
                + '\'' + ", reusable=" + reusable
                + ", active=" + active + ", attributes=" + attributes + '}';
    }
}

package com.ekart.facp.unitization.apis.dtos;

import static com.ekart.facp.unitization.apis.constants.ApiConstants.*;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

/**
 * Created by avinash.r on 13/07/16.
 */
@ApiModel
public class UpdateRequestItem {

    @ApiModelProperty(name = "label_type", value = "The label_type of the unitizable.")
    @JsonProperty(value = "label_type")
    @NotNull(message = "{container.labelType.notnull}")
    private String labelType;

    @ApiModelProperty(name = "label", value = "The label of the unitizable.")
    @JsonProperty(value = "label")
    @NotNull(message = "{unitizable.label.notnull}")
    private String label;

    @ApiModelProperty(name = "container_type", value = "The container_type is type of container.")
    @JsonProperty(value = "container_type")
    @NotNull(message = "{container.containerType.notnull}")
    private String type;

    @ApiModelProperty(name = "state_machine_id", value = "The identifier of the flow for which "
            + "the container is created")
    @JsonProperty(value = "state_machine_id")
    @NotNull(message = "{container.stateMachineId.notnull}")
    private String stateMachineId;

    @ApiModelProperty(name = "transition_name", value = "change status of item using transition")
    @JsonProperty(value = "transition_name")
    @NotNull(message = "{container.transitionName.notnull}")
    private String transitionName;

    @ApiModelProperty(name = "attributes", value = "The attributes to be updated")
    @JsonProperty(value = "attributes")
    private List<Attribute> attributes;

    //for now having 5 will change according to use case
    @ApiModelProperty(name = "labelsToBeAdded", value = "The labelsToBeAdded to be created")
    @JsonProperty(value = "labelsToBeAdded")
    @Size(max = MAX_LABELS_TO_BE_ADDED, message = "{container.labels.size}")
    private List<Label> labelsToBeAdded;

    public String getLabelType() {
        return labelType;
    }

    public void setLabelType(String labelType) {
        this.labelType = labelType;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getStateMachineId() {
        return stateMachineId;
    }

    public void setStateMachineId(String stateMachineId) {
        this.stateMachineId = stateMachineId;
    }

    public String getTransitionName() {
        return transitionName;
    }

    public void setTransitionName(String transitionName) {
        this.transitionName = transitionName;
    }

    public List<Attribute> getAttributes() {
        return attributes;
    }

    public void setAttributes(List<Attribute> attributes) {
        this.attributes = attributes;
    }

    public List<Label> getLabelsToBeAdded() {
        return labelsToBeAdded;
    }

    public void setLabelsToBeAdded(List<Label> labelsToBeAdded) {
        this.labelsToBeAdded = labelsToBeAdded;
    }

    @Override
    public String toString() {
        return "UpdateRequestItem{" + ", labelType='" + labelType + '\''
                + ", label='" + label + '\'' + ", type='" + type + '\'' + ", stateMachineId='" + stateMachineId + '\''
                + ", transitionName='" + transitionName + '\'' + ", attributes=" + attributes
                + ", labelsToBeAdded=" + labelsToBeAdded + '}';
    }
}

package com.ekart.facp.unitization.service.exceptions.clients;

import com.ekart.facp.unitization.service.exceptions.BaseException;

/**
 * Created by anurag.gupta on 11/07/16.
 */
public abstract class ClientException extends BaseException {

    protected ClientException(String message, String errorCode) {
        super(message, errorCode);
    }

    protected ClientException(String message, String name, Throwable cause) {
        super(message, name, cause);
    }
}


package com.ekart.facp.unitization.service.clients;


import com.ekart.facp.unitization.apis.dtos.ErrorMessage;
import com.ekart.facp.unitization.apis.mapper.ServiceEntityToClientRequestMapper;
import com.ekart.facp.unitization.common.ErrorCode;
import com.ekart.facp.unitization.service.dtos.clients.fsm.FsmInitialStateResponse;
import com.ekart.facp.unitization.service.dtos.clients.fsm.FsmNextStateResponse;
import com.ekart.facp.unitization.service.exceptions.clients.fsm.FsmBadRequestException;
import com.ekart.facp.unitization.service.exceptions.clients.fsm.FsmClientException;
import com.ekart.facp.unitization.service.exceptions.clients.fsm.InvalidStateMachineException;
import com.ekart.facp.unitization.service.exceptions.clients.fsm.InvalidTransitionException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

import static com.ekart.facp.unitization.apis.util.ClientUtil.url;
import static jersey.repackaged.com.google.common.base.Preconditions.checkNotNull;

/**
 * Created by anurag.gupta on 17/06/16.
 */
public class FsmClient {

    private final String baseUrl;
    private final RestTemplate restTemplate;
    private final ServiceEntityToClientRequestMapper mapper;
    private final ObjectMapper objectMapper;
    private static final Logger LOGGER = LoggerFactory.getLogger(FsmClient.class);

    public FsmClient(RestTemplate restTemplate, String baseUrl, ServiceEntityToClientRequestMapper mapper,
                     ObjectMapper objectMapper) {
        this.restTemplate = checkNotNull(restTemplate);
        this.baseUrl = checkNotNull(baseUrl);
        this.mapper = checkNotNull(mapper);
        this.objectMapper = checkNotNull(objectMapper);
    }

    public String getInitialState(String stateMachineId) {
        HttpEntity<?> httpRequest = new HttpEntity<>(newHeader());
        ResponseEntity<String> response = restTemplate.exchange(
                url("/api/v1/statemachines/{stateMachineId}/states/initial", baseUrl),
                HttpMethod.GET, httpRequest, String.class, stateMachineId);
        return getFsmResponse(response, stateMachineId).getInitialState();
    }

    private HttpHeaders newHeader() {
        HttpHeaders header = new HttpHeaders();
        header.add(HttpHeaders.CONTENT_TYPE, javax.ws.rs.core.MediaType.APPLICATION_JSON);
        return header;
    }

    //TODO: swagger client jar integration
    private FsmInitialStateResponse getFsmResponse(ResponseEntity<String> response, String stateMachineId) {
        FsmInitialStateResponse initialStateResponse = null;
        try {
            switch (response.getStatusCode()) {
                case OK:
                    initialStateResponse = objectMapper.readValue(response.getBody(), FsmInitialStateResponse.class);
                    break;
                case BAD_REQUEST:
                    ErrorMessage errorMessage = objectMapper.readValue(response.getBody(), ErrorMessage.class);
                    switch (ErrorCode.valueOf(errorMessage.getErrorCode())) {
                        case SM_NOT_FOUND:
                            throw new InvalidStateMachineException("Invalid StateMachine: " + stateMachineId);
                        default:
                            throw new FsmBadRequestException(errorMessage.getMessage(), errorMessage.getErrorCode());
                    }
                default:
                    ErrorMessage defaultErrorMessage = objectMapper.readValue(response.getBody(), ErrorMessage.class);
                    throw new FsmClientException(defaultErrorMessage.getMessage(), defaultErrorMessage.getErrorCode());
            }
        } catch (IOException e) {
            LOGGER.error("Response error: {} ", e.getMessage());
            throw new FsmClientException(response.getBody() + e.getMessage(), e);
        }
        return initialStateResponse;
    }

    //TODO: swagger client jar integration
    public String getNextState(String state, String transition, String stateMachineId) {

        HttpEntity<?> httpRequest = new HttpEntity<>(newHeader());
        String nextState = null;
        ResponseEntity<String> response = restTemplate.exchange(
                url("/api/v1/statemachines/{identifier}/states/{state}/transitions/{transition}", baseUrl),
                HttpMethod.GET, httpRequest, String.class, stateMachineId, state, transition);
        try {
            switch (response.getStatusCode()) {
                case OK:
                    nextState = objectMapper.readValue(response.getBody(), FsmNextStateResponse.class).getNextState();
                    break;
                case BAD_REQUEST:
                    ErrorMessage errorMessage = objectMapper.readValue(response.getBody(), ErrorMessage.class);
                    switch (ErrorCode.valueOf(errorMessage.getErrorCode())) {
                        case SM_NOT_FOUND:
                            throw new InvalidStateMachineException("Invalid StateMachine: " + stateMachineId);
                        case INVALID_STATE_TRANSITION:
                            throw new InvalidTransitionException(transition);
                        default:
                            throw new FsmBadRequestException(errorMessage.getMessage(), errorMessage.getErrorCode());
                    }
                default:
                    ErrorMessage defaultErrorMessage = objectMapper.readValue(response.getBody(), ErrorMessage.class);
                    throw new FsmClientException(defaultErrorMessage.getMessage(), defaultErrorMessage.getErrorCode());
            }
        } catch (IOException e) {
            LOGGER.error("Response error: {} ", e.getMessage());
            throw new FsmClientException(response.getBody() + e.getMessage(), e);
        }
        return nextState;
    }
}

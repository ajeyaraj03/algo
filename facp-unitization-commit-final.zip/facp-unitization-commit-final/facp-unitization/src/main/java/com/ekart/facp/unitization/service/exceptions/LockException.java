package com.ekart.facp.unitization.service.exceptions;

/**
 * @author vijay.daniel
 */
public class LockException extends RuntimeException {

    private static final long serialVersionUID = -2674379306253009840L;

    public LockException() {

    }

    public LockException(String message) {

        super(message);
    }

    public LockException(Throwable cause) {

        super(cause);
    }

    public LockException(String message, Throwable cause) {

        super(message, cause);
    }

    public LockException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {

        super(message, cause, enableSuppression, writableStackTrace);
    }
}

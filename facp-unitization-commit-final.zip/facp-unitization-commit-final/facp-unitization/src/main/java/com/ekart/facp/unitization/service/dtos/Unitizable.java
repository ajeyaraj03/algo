package com.ekart.facp.unitization.service.dtos;

/**
 * Created by avinash.r on 13/07/16.
 */
public class Unitizable {

    private String label;
    private String labelType;
    private String stateMachineId;

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getLabelType() {
        return labelType;
    }

    public void setLabelType(String labelType) {
        this.labelType = labelType;
    }

    public String getStateMachineId() {
        return stateMachineId;
    }

    public void setStateMachineId(String stateMachineId) {
        this.stateMachineId = stateMachineId;
    }

    @Override
    public String toString() {
        return "Unitizable{" + "label='" + label + '\'' + ", labelType='" + labelType + '\''
                + ", stateMachineId='" + stateMachineId + '\'' + '}';
    }
}

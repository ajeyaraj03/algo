package com.ekart.facp.unitization.apis.config.spring;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.inject.Inject;
import java.beans.PropertyVetoException;
import java.util.Properties;

@Configuration
@Import({EnvironmentConfig.class, HealthCheckConfig.class, HibernateConfig.class})
@EnableTransactionManagement
@EnableRetry
public class DatabaseConfig {

    @Inject
    private EnvironmentConfig environmentConfig;

    @Inject
    private HealthCheckConfig healthCheckConfig;

    @Inject
    private HibernateConfig hibernateConfig;

    @Value("${database.packagesToScan}")
    private String packagesToScan;

    @Bean
    public HikariDataSource dataSource() {

        HikariDataSource dataSource = new HikariDataSource(hikariConfig());

        // https://github.com/brettwooldridge/HikariCP/wiki/Dropwizard-Metrics
        dataSource.setMetricRegistry(environmentConfig.metricRegistry());

        dataSource.setHealthCheckRegistry(healthCheckConfig.healthCheckRegistry());
        return dataSource;
    }

    @Bean
    @ConfigurationProperties(prefix = "database.hikari")
    public HikariConfig hikariConfig() {

        return new HikariConfig();
    }

    @Bean
    public LocalContainerEntityManagerFactoryBean entityManagerFactory() {

        LocalContainerEntityManagerFactoryBean entityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();
        entityManagerFactoryBean.setDataSource(dataSource());
        entityManagerFactoryBean.setPackagesToScan(new String[]{packagesToScan});
        entityManagerFactoryBean.setJpaVendorAdapter(new HibernateJpaVendorAdapter());

        Properties hibernateProperties = new Properties();
        hibernateProperties.putAll(hibernateConfig.getHibernateProperties());
        entityManagerFactoryBean.setJpaProperties(hibernateProperties);

        return entityManagerFactoryBean;
    }

    @Bean
    public JpaTransactionManager transactionManager() throws PropertyVetoException {

        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(entityManagerFactory().getObject());
        return transactionManager;
    }

    @Bean
    public PersistenceExceptionTranslationPostProcessor exceptionTranslation() {

        return new PersistenceExceptionTranslationPostProcessor();
    }
}

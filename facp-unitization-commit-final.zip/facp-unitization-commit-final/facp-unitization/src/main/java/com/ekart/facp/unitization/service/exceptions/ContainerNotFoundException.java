package com.ekart.facp.unitization.service.exceptions;

import static com.ekart.facp.unitization.common.ErrorCode.CONTAINER_NOT_FOUND_EXCEPTION;

/**
 * Created by avinash.r on 13/07/16.
 */
public class ContainerNotFoundException extends BaseException {

    private static final long serialVersionUID = -5661086993984811287L;

    public ContainerNotFoundException(String label, String type) {
        super("Container with label " + label + " and type " + type + " not found",
                CONTAINER_NOT_FOUND_EXCEPTION.name());
    }

    public ContainerNotFoundException(String id) {
        super("Container with id: " + id + " not found", CONTAINER_NOT_FOUND_EXCEPTION.name());
    }
}

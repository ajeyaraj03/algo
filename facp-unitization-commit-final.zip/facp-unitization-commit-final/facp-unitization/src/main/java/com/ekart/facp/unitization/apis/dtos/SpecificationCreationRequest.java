package com.ekart.facp.unitization.apis.dtos;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;
import java.util.Map;

/**
 * Created by ajeya.hb on 26/03/16.
 */

@ApiModel
public class SpecificationCreationRequest {

    @ApiModelProperty(name = "reusable", value = "Indicates whether the entity type is reusable")
    @JsonProperty(value = "reusable")
    private boolean reusable;

    @ApiModelProperty(name = "active", value = "Indicates whether the entity type is active or inactive")
    @JsonProperty(value = "active")
    private boolean active = true;

    @ApiModelProperty(name = "created_by", value = "User who is creating the Specification")
    @JsonProperty(value = "created_by")
    @NotNull(message = "{spec.createdby.notnull}")
    private String createdBy;

    @ApiModelProperty(name = "attributes", value = "Attributes which are getting added")
    @JsonProperty(value = "attributes")
    private Map<String, String> attributes;

    @ApiModelProperty(name = "type", value = "Entity type for which Specification is being added")
    @JsonProperty(value = "type", required = true)
    @NotEmpty(message = "{spec.type.notnull}")
    private String type;


    public boolean isReusable() {
        return reusable;
    }

    public void setReusable(boolean reusable) {
        this.reusable = reusable;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Map<String, String> getAttributes() {
        return attributes;
    }

    public void setAttributes(Map<String, String> attributes) {
        this.attributes = attributes;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "SpecificationCreationRequest{"
                + "reusable=" + reusable
                + ", active=" + active
                + ", createdBy='" + createdBy
                + '\''
                + ", attributes=" + attributes
                + ", type='" + type + '\''
                + '}';
    }
}

package com.ekart.facp.unitization.service.dtos;


import java.util.List;

/**
 * Created by avinash.r on 13/07/16.
 */
public class UpdateRequestItem {

    private String labelType;
    private String label;
    private String type;
    private String stateMachineId;
    private String transitionName;
    private List<ItemAttribute> attributes;
    private List<ItemLabel> labelsToBeAdded;

    public List<ItemLabel> getLabelsToBeAdded() {
        return labelsToBeAdded;
    }

    public void setLabelsToBeAdded(List<ItemLabel> labelsToBeAdded) {
        this.labelsToBeAdded = labelsToBeAdded;
    }

    public List<ItemAttribute> getAttributes() {
        return attributes;
    }

    public void setAttributes(List<ItemAttribute> attributes) {
        this.attributes = attributes;
    }

    public String getTransitionName() {
        return transitionName;
    }

    public void setTransitionName(String transitionName) {
        this.transitionName = transitionName;
    }

    public String getStateMachineId() {
        return stateMachineId;
    }

    public void setStateMachineId(String stateMachineId) {
        this.stateMachineId = stateMachineId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getLabelType() {
        return labelType;
    }

    public void setLabelType(String labelType) {
        this.labelType = labelType;
    }

    @Override
    public String toString() {
        return "UpdateRequestItem{" + "labelType='" + labelType + '\'' + ", label='" + label + '\''
                + ", type='" + type + '\'' + ", stateMachineId='" + stateMachineId + '\''
                + ", transitionName='" + transitionName + '\'' + ", attributes=" + attributes
                + ", labelsToBeAdded=" + labelsToBeAdded + '}';
    }
}

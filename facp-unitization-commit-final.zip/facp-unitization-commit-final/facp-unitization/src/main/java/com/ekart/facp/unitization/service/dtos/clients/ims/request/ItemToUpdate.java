package com.ekart.facp.unitization.service.dtos.clients.ims.request;

import com.ekart.facp.unitization.service.dtos.ItemAttribute;
import com.ekart.facp.unitization.service.dtos.ItemLabel;
import com.ekart.facp.unitization.service.dtos.ItemStatus;

import java.util.List;
import java.util.Map;

/**
 * Created by avinash.r on 13/07/16.
 */
public class ItemToUpdate {

    private String id;
    private long lastReadVersion;
    private Map<String, List<ItemAttribute>> attributes;
    private Map<String, List<ItemLabel>> labels;
    private Map<String, List<ItemStatus>> statuses;

    public ItemToUpdate() {
    }

    public ItemToUpdate(String id, long lastReadVersion, Map<String, List<ItemAttribute>> attributes,
                        Map<String, List<ItemLabel>> labels, Map<String, List<ItemStatus>> statuses) {
        this.id = id;
        this.lastReadVersion = lastReadVersion;
        this.attributes = attributes;
        this.labels = labels;
        this.statuses = statuses;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public long getLastReadVersion() {
        return lastReadVersion;
    }

    public void setLastReadVersion(long lastReadVersion) {
        this.lastReadVersion = lastReadVersion;
    }

    public Map<String, List<ItemAttribute>> getAttributes() {
        return attributes;
    }

    public void setAttributes(Map<String, List<ItemAttribute>> attributes) {
        this.attributes = attributes;
    }

    public Map<String, List<ItemLabel>> getLabels() {
        return labels;
    }

    public void setLabels(Map<String, List<ItemLabel>> labels) {
        this.labels = labels;
    }

    public Map<String, List<ItemStatus>> getStatuses() {
        return statuses;
    }

    public void setStatuses(Map<String, List<ItemStatus>> statuses) {
        this.statuses = statuses;
    }
}

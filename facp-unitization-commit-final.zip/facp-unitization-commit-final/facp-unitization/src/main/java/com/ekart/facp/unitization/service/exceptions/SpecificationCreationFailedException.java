package com.ekart.facp.unitization.service.exceptions;
import static com.ekart.facp.unitization.common.ErrorCode.SPECIFICATION_CREATION_FAILED;
/**
 * Created by ajeya.hb on 28/06/16.
 */
public class SpecificationCreationFailedException extends BaseException {

    public SpecificationCreationFailedException(String resource, String tenant, String type, boolean active,
                                                Throwable cause) {
        super(resource + " with tenant: " + tenant + " and type: "
                + type + " already exists with " + (active ? "Active" : "Inactive") + " State",
                SPECIFICATION_CREATION_FAILED.name(), cause);
    }
}

package com.ekart.facp.unitization.apis.config.spring;

import com.ekart.facp.unitization.apis.mapper.ServiceEntityToClientRequestMapper;
import com.ekart.facp.unitization.service.clients.FsmClient;
import com.ekart.facp.unitization.service.clients.ImsClient;
import com.ekart.facp.unitization.service.clients.LabelServiceClient;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.guava.GuavaModule;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import javax.inject.Inject;

/**
 * Created by anurag.gupta on 02/06/16.
 */
@Configuration
@Import({HttpClientConfig.class})

public class ClientServiceConfig {

    @Inject
    private ServiceEntityToClientRequestMapper mapper;

    @Inject
    private HttpClientConfig httpClientConfig;

    @Value("${imsService.baseUrl}")
    private String imsBaseUrl;

    @Value("${fsmService.baseUrl}")
    private String fsmBaseUrl;

    @Value("${labelService.baseUrl}")
    private String labelServiceBaseUrl;

    @Bean
    public ObjectMapper objectMapper() {
        ObjectMapper objectMapper = new ObjectMapper()
                .configure(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS, true)
                .configure(JsonGenerator.Feature.WRITE_BIGDECIMAL_AS_PLAIN, true);
        objectMapper.registerModule(new GuavaModule());
        return objectMapper;
    }


    @Bean
    public ImsClient imsClient() {
        return new ImsClient(httpClientConfig.restTemplate(), imsBaseUrl, mapper, objectMapper());
    }

    @Bean
    public FsmClient fsmClient() {
        return new FsmClient(httpClientConfig.restTemplate(), fsmBaseUrl, mapper, objectMapper());
    }

    @Bean
    public LabelServiceClient labelServiceClient() {
        return new LabelServiceClient(httpClientConfig.restTemplate(), labelServiceBaseUrl, mapper, objectMapper());
    }


}


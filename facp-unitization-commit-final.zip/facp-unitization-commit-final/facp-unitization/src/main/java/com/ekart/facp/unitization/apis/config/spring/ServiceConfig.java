package com.ekart.facp.unitization.apis.config.spring;

import com.ekart.facp.unitization.apis.util.UUIDGenerator;
import com.ekart.facp.unitization.service.RuleService;
import com.ekart.facp.unitization.service.SpecificationService;
import com.ekart.facp.unitization.service.impl.RuleServiceImpl;
import com.ekart.facp.unitization.service.impl.SpecificationServiceImpl;
import com.ekart.facp.unitization.service.mapper.ServiceEntityToDALModelMapper;
import com.ekart.facp.unitization.service.DispensibleContainerService;
import com.ekart.facp.unitization.service.ReusableContainerService;
import com.ekart.facp.unitization.service.utility.ContainerFactory;
import com.ekart.facp.unitization.service.clients.SpecificationClient;
import com.ekart.facp.unitization.service.validators.SpecificationAttributesValidator;
import com.ekart.facp.unitization.service.validators.UnitizationValidator;
import com.ekart.facp.unitization.service.validators.NumberOfItemsAggregator;
import com.ekart.facp.unitization.service.validators.WeightAggregator;
import org.springframework.context.annotation.Import;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.joda.time.DateTime;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.inject.Inject;
import java.util.function.Supplier;

/**
 * Created by ajeya.hb on 07/06/16.
 */
@Configuration
@Import({ClientServiceConfig.class})
public class ServiceConfig {

    @Inject
    private RepositoryConfig repositoryConfig;

    @Inject
    private ServiceEntityToDALModelMapper serviceAndDAOMapper;

    @Inject
    private ObjectMapper objectMapper;

    @Inject
    private ClientServiceConfig clientServiceConfig;

    @Inject
    private RuleService ruleService;

    @Inject
    private UnitizationValidator unitizationValidator;

    @Inject
    private SpecificationAttributesValidator specificationAttributesValidator;

    @Bean
    public ReusableContainerService reusableContainerService() {
        return new ReusableContainerService(clientServiceConfig.imsClient(), clientServiceConfig.fsmClient(),
                specificationAttributesValidator, unitizationValidator, clientServiceConfig.labelServiceClient());
    }

    @Bean
    public DispensibleContainerService dispensibleContainerService() {
        return new DispensibleContainerService(clientServiceConfig.imsClient(), clientServiceConfig.fsmClient(),
                specificationAttributesValidator, unitizationValidator, clientServiceConfig.labelServiceClient());
    }

    @Bean
    public ContainerFactory containerFactory() {
        return new ContainerFactory(reusableContainerService(), dispensibleContainerService());
    }

    @Bean
    public SpecificationClient specificationClient() {
        return new SpecificationClient(specificationService());
    }

    @Bean
    public SpecificationService specificationService() {
        return new SpecificationServiceImpl(repositoryConfig.specificationRepository(), serviceAndDAOMapper,
                objectMapper, uuidGenerator(), currentTimeSupplier());
    }

    @Bean
    public UUIDGenerator uuidGenerator() {
        return new UUIDGenerator();
    }

    @Bean
    public Supplier<DateTime> currentTimeSupplier() {

        return () -> new DateTime();
    }

    @Bean
    public RuleServiceImpl ruleServiceImpl() {
        return new RuleServiceImpl();
    }

    @Bean
    public UnitizationValidator unitizationValidator() {
        return new UnitizationValidator();
    }

    @Bean
    public SpecificationAttributesValidator specificationAttributesValidator() {
        return new SpecificationAttributesValidator(weightAggregator(), numberOfItemsAggregator());
    }

    @Bean
    public WeightAggregator weightAggregator() {
        return new WeightAggregator(ruleService);
    }

    @Bean
    NumberOfItemsAggregator numberOfItemsAggregator() {
        return new NumberOfItemsAggregator(ruleService);
    }
}

package com.ekart.facp.unitization.service.validators;

/**
 * Created by avinash.r on 04/08/16.
 */
public abstract class AggregationResult {
}

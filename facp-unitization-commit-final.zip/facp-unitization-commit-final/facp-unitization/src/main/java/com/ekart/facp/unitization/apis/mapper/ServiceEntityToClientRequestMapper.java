package com.ekart.facp.unitization.apis.mapper;

import com.ekart.facp.unitization.apis.dtos.Attribute;
import com.ekart.facp.unitization.apis.dtos.Label;
import com.ekart.facp.unitization.service.dtos.AddRequest;
import com.ekart.facp.unitization.service.dtos.Container;
import com.ekart.facp.unitization.service.dtos.UpdateRequest;
import com.ekart.facp.unitization.service.dtos.ItemAttribute;
import com.ekart.facp.unitization.service.dtos.clients.ims.request.*;
import com.ekart.facp.unitization.service.dtos.ItemLabel;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by anurag.gupta on 07/06/16.
 */
@Component
@Mapper(componentModel = "spring")
public interface ServiceEntityToClientRequestMapper {

    @Mapping(source = "createdBy", target = "requestedBy")
    @Mapping(target = "itemRequests", ignore = true)
    ItemCreationRequest unitizationToItemCreationRequest(Container container);

    @Mapping(target = "statuses", ignore = true)
    @Mapping(target = "labels", ignore = true)
    ItemCreationRequestAttributes unitizationToItemCreationRequestAttributes(Container container);

    ItemAttribute containerAttributeToItemAttribute(Attribute attribute);

    ItemLabel containerLabelToItemLabel(Label label);

    ItemMoveRequest unitizationMoveRequestToItemMoveRequest(AddRequest moveRequest,
                                                            List<ItemAddRequest> itemRequests);

    ItemUpdateRequest unitizationUpdateRequestToItemUpdateRequest(UpdateRequest updateRequest,
                                                                  List<ItemToUpdate> itemRequests);
}

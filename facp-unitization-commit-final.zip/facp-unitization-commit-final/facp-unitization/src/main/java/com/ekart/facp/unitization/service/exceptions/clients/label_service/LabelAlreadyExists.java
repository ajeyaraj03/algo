package com.ekart.facp.unitization.service.exceptions.clients.label_service;

import com.ekart.facp.unitization.service.exceptions.clients.ClientException;

import static com.ekart.facp.unitization.common.ErrorCode.LABEL_ALREADY_EXISTS;

/**
 * Created by anurag.gupta on 17/06/16.
 */
public class LabelAlreadyExists extends ClientException {

    private static final long serialVersionUID = -8719315920559315309L;

    public LabelAlreadyExists(String message) {
        super(message, LABEL_ALREADY_EXISTS.name());
    }
}

package com.ekart.facp.unitization.apis.util;

import java.util.UUID;

/**
 * Created by ajeya.hb on 10/03/16.
 */
public class UUIDGenerator {

    public UUID generate() {

        return UUID.randomUUID();
    }
}

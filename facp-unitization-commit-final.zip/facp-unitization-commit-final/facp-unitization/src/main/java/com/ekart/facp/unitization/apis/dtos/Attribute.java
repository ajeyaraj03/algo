package com.ekart.facp.unitization.apis.dtos;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;

/**
 * Created by anurag.gupta on 06/07/16.
 */
@ApiModel
public class Attribute {

    @ApiModelProperty(name = "name", value = "Attribute name of the container")
    @JsonProperty(value = "name")
    @NotNull(message = "{container.attributeName.notnull}")
    private String name;

    @ApiModelProperty(name = "value", value = "Attribute value of the container")
    @JsonProperty(value = "value")
    @NotNull(message = "{container.attributeValue.notnull}")
    private Object value;

    public Attribute(String name, Object value) {
        this.name = name;
        this.value = value;
    }

    //Required for mapstruct
    public Attribute() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Object getValue() {
        return value;
    }

    public void setValue(Object value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "Attribute{"
                + "name='" + name + '\''
                + ", value=" + value
                + '}';
    }
}

package com.ekart.facp.unitization.service.dtos.clients.ims.request;

import java.util.List;

/**
 * Created by avinash.r on 13/07/16.
 */
public class ItemUpdateRequest {

    private String idempotenceKey;
    private List<ItemToUpdate> itemRequests;
    private String requestedBy;

    public String getIdempotenceKey() {
        return idempotenceKey;
    }

    public void setIdempotenceKey(String idempotenceKey) {
        this.idempotenceKey = idempotenceKey;
    }

    public List<ItemToUpdate> getItemRequests() {
        return itemRequests;
    }

    public void setItemRequests(List<ItemToUpdate> itemRequests) {
        this.itemRequests = itemRequests;
    }

    public String getRequestedBy() {
        return requestedBy;
    }

    public void setRequestedBy(String requestedBy) {
        this.requestedBy = requestedBy;
    }

    @Override
    public String toString() {
        return "ItemUpdateRequest{" + "idempotenceKey='" + idempotenceKey + '\'' + ", itemRequests=" + itemRequests
                + ", requestedBy='" + requestedBy + '\'' + '}';
    }
}

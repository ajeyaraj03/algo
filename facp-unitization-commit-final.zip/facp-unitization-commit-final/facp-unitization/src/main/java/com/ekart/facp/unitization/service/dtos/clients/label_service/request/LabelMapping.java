package com.ekart.facp.unitization.service.dtos.clients.label_service.request;

/**
 * Created by anurag.gupta on 14/07/16.
 */
public class LabelMapping {

    private String idempotenceKey;
    private String type;
    private String value;

    public LabelMapping(String idempotenceKey, String type, String value) {
        this.idempotenceKey = idempotenceKey;
        this.type = type;
        this.value = value;
    }

    public String getIdempotenceKey() {
        return idempotenceKey;
    }

    public void setIdempotenceKey(String idempotenceKey) {
        this.idempotenceKey = idempotenceKey;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "LabelMapping{"
                + "idempotenceKey='" + idempotenceKey + '\''
                + ", type='" + type + '\''
                + ", value='" + value + '\'' + '}';
    }
}

package com.ekart.facp.unitization.service.dtos.clients.ims.request;

import com.ekart.facp.unitization.service.dtos.ItemAttribute;
import com.ekart.facp.unitization.service.dtos.ItemLabel;
import com.ekart.facp.unitization.service.dtos.ItemStatus;

import java.util.List;

/**
 * Created by anurag.gupta on 02/06/16.
 */
public class ItemCreationRequestAttributes {

    private String containerId;
    private String type;
    private String uom;
    private int quantity;
    private List<ItemAttribute> attributes;
    private List<ItemStatus> statuses;
    private List<ItemLabel> labels;

    public String getContainerId() {
        return containerId;
    }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUom() {
        return uom;
    }

    public void setUom(String uom) {
        this.uom = uom;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public List<ItemAttribute> getAttributes() {
        return attributes;
    }

    public void setAttributes(List<ItemAttribute> attributes) {
        this.attributes = attributes;
    }

    public List<ItemStatus> getStatuses() {
        return statuses;
    }

    public void setStatuses(List<ItemStatus> statuses) {
        this.statuses = statuses;
    }

    public List<ItemLabel> getLabels() {
        return labels;
    }

    public void setLabels(List<ItemLabel> labels) {
        this.labels = labels;
    }

    @Override
    public String toString() {
        return "ItemCreationRequestAttributes{"
                + "containerId='" + containerId + '\''
                + ", type='" + type + '\''
                + ", uom='" + uom + '\''
                + ", quantity=" + quantity
                + ", attributes=" + attributes
                + ", statuses=" + statuses
                + ", labels=" + labels
                + '}';
    }
}

package com.ekart.facp.unitization.service.dtos.clients.ims.response;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.concurrent.Immutable;

/**
 * Created by anurag.gupta on 19/07/16.
 */
@Immutable
public final class ItemStatus {

    private final String owner;
    private final String value;

    @JsonCreator
    public ItemStatus(@JsonProperty(value = "owner") String owner, @JsonProperty(value = "value") String value) {
        this.owner = owner;
        this.value = value;
    }

    public String getOwner() {
        return owner;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return "ItemStatus{"
                + "owner='" + owner + '\''
                + ", value='" + value + '\''
                + '}';
    }
}


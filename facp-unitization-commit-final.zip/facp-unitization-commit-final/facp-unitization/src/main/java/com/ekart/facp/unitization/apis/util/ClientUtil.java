package com.ekart.facp.unitization.apis.util;

import com.google.common.collect.ImmutableMap;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Map;

/**
 * Created by anurag.gupta on 12/07/16.
 */
public final class ClientUtil {

    private ClientUtil() {
    }

    public static String url(String urlPath, String baseUrl) {
        return url(urlPath, baseUrl, ImmutableMap.of());
    }

    public static String url(String urlPath, String baseUrl, Map<String, Object> requestParams) {
        MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        requestParams.forEach((k, v) -> params.add(k, v.toString()));
        return UriComponentsBuilder.newInstance().scheme("http").host(baseUrl).path(urlPath).queryParams(params).build()
                .toUriString();
    }
}

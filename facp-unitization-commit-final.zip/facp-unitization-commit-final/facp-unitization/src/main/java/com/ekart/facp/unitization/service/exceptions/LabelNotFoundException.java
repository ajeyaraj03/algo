package com.ekart.facp.unitization.service.exceptions;

import static com.ekart.facp.unitization.common.ErrorCode.LABEL_NOT_FOUND_EXCEPTION;

/**
 * Created by avinash.r on 13/07/16.
 */
public class LabelNotFoundException extends BaseException {

    private static final long serialVersionUID = 2605377261162445168L;

    public LabelNotFoundException(String message) {
        super(message, LABEL_NOT_FOUND_EXCEPTION.name());
    }

    public LabelNotFoundException(String label, String type) {
        super("Item with label " + label + " and type " + type + " not found", LABEL_NOT_FOUND_EXCEPTION.name());
    }
}

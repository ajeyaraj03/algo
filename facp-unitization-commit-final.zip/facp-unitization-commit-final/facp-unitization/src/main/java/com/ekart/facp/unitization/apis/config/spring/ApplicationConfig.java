package com.ekart.facp.unitization.apis.config.spring;

import com.ekart.facp.unitization.apis.controller.HealthCheckController;
import com.ekart.facp.unitization.apis.controller.SpecificationController;
import com.ekart.facp.unitization.apis.controller.SpecificationSearchController;
import com.ekart.facp.unitization.apis.mapper.ApiDtoToServiceEntityMapper;
import com.ekart.facp.unitization.apis.controller.UnitizationController;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import javax.inject.Inject;

@Configuration
@ComponentScan({"com.ekart.facp.unitization.service.mapper"})
@Import({EnvironmentConfig.class, JettyConfig.class, HealthCheckConfig.class, DatabaseConfig.class,
        ServiceConfig.class, SwaggerConfig.class, RepositoryConfig.class, ClientServiceConfig.class})
public class ApplicationConfig {

    // Reference:
    // http://docs.spring.io/spring-javaconfig/docs/1.0.0.M4/reference/html/ch04s02.html
    @Inject
    private HealthCheckConfig healthCheckConfig;

    @Inject
    private JettyConfig jettyConfig;

    @Inject
    private ApiDtoToServiceEntityMapper apiDtoAndServiceEntityMapper;

    @Inject
    private ServiceConfig serviceConfig;



    /*Controller bean configurations*/

    @Bean
    public HealthCheckController healthCheckController() {

        return new HealthCheckController(healthCheckConfig.masterHealthCheck(), jettyConfig.elbStatisticsCollector());
    }

    @Bean
    public SpecificationController specificationController() {

        return new SpecificationController(serviceConfig.specificationService(), apiDtoAndServiceEntityMapper);
    }

    @Bean
    public SpecificationSearchController specificationSearchController() {

        return new SpecificationSearchController(serviceConfig.specificationService(), apiDtoAndServiceEntityMapper);
    }

    @Bean
    public UnitizationController unitizationController() {
        return new UnitizationController(serviceConfig.specificationClient(), serviceConfig.containerFactory(),
                apiDtoAndServiceEntityMapper);
    }
}

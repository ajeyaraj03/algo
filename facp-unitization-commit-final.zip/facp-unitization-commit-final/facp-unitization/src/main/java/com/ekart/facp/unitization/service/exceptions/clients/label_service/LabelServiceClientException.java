package com.ekart.facp.unitization.service.exceptions.clients.label_service;

import com.ekart.facp.unitization.service.exceptions.clients.ClientException;

import static com.ekart.facp.unitization.common.ErrorCode.LABEL_SERVICE_CLIENT_EXCEPTION;

/**
 * Created by anurag.gupta on 14/07/16.
 */
public class LabelServiceClientException extends ClientException {

    private static final long serialVersionUID = -8719315920559315309L;

    public LabelServiceClientException(String message, String errorCode) {
        super(message, errorCode);
    }
    public LabelServiceClientException(String message, Throwable cause) {
        super(message, LABEL_SERVICE_CLIENT_EXCEPTION.name(), cause);
    }
}


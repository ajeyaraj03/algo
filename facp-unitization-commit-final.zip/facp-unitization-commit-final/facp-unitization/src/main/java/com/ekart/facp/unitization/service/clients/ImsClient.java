package com.ekart.facp.unitization.service.clients;

import com.codahale.metrics.annotation.ExceptionMetered;
import com.codahale.metrics.annotation.Timed;
import com.ekart.facp.unitization.apis.dtos.ErrorMessage;
import com.ekart.facp.unitization.apis.mapper.ServiceEntityToClientRequestMapper;
import com.ekart.facp.unitization.common.enums.clients.ims.AttributeDefaultValues;
import com.ekart.facp.unitization.service.dtos.*;
import com.ekart.facp.unitization.service.dtos.clients.ims.request.ItemAddRequest;
import com.ekart.facp.unitization.service.dtos.clients.ims.request.ItemCreationRequest;
import com.ekart.facp.unitization.service.dtos.clients.ims.request.ItemCreationRequestAttributes;
import com.ekart.facp.unitization.service.dtos.clients.ims.request.ItemToUpdate;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.GetItemResponse;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.Item;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.ItemsCreationResponse;
import com.ekart.facp.unitization.service.exceptions.clients.ims.ImsBadRequestException;
import com.ekart.facp.unitization.service.exceptions.clients.ims.ImsClientException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import javax.ws.rs.core.MediaType;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.ekart.facp.unitization.apis.constants.ApiConstants.DELETED_VALUE;
import static com.ekart.facp.unitization.apis.constants.ApiConstants.MODIFIED_VALUE;
import static com.ekart.facp.unitization.apis.util.ClientUtil.url;
import static com.ekart.facp.unitization.common.enums.clients.ims.AttributeName.*;
import static jersey.repackaged.com.google.common.base.Preconditions.checkNotNull;
import static org.springframework.http.HttpMethod.GET;
import static org.springframework.http.HttpMethod.POST;

/**
 * Created by anurag.gupta on 01/06/16.
 */

@Timed
@ExceptionMetered
public class ImsClient {

    private final String baseUrl;
    private final RestTemplate restTemplate;
    private final ServiceEntityToClientRequestMapper mapper;
    private final ObjectMapper objectMapper;
    private static final Logger LOGGER = LoggerFactory.getLogger(ImsClient.class);

    public ImsClient(RestTemplate restTemplate, String baseUrl, ServiceEntityToClientRequestMapper mapper,
                     ObjectMapper objectMapper) {
        this.restTemplate = checkNotNull(restTemplate);
        this.baseUrl = checkNotNull(baseUrl);
        this.mapper = checkNotNull(mapper);
        this.objectMapper = checkNotNull(objectMapper);
    }

    public String createItem(String status, String processOwner, Container createItem) {
        ItemCreationRequest request = mapper.unitizationToItemCreationRequest(createItem);
        ItemCreationRequestAttributes requestAttributes = mapper.unitizationToItemCreationRequestAttributes(createItem);
        HttpEntity<ItemCreationRequest> httpRequest = new HttpEntity<>(request, newHeader());
        request.setItemRequests(Lists.newArrayList(setRequestAttributes(createItem, requestAttributes,
                status, processOwner)));
        ResponseEntity<String> response = restTemplate.exchange(url("/api/v1/{rootContainerId}/item",
                baseUrl), POST, httpRequest, String.class, createItem.getFacilityId());
        return getItemCreateResponse(response).getAffectedItems().get(0).getItemId();
    }

    public List<Item> getItemsByLabel(String rootContainerId, ItemLabel itemLabel) {

        HttpEntity<?> httpRequest = new HttpEntity<>(newHeader());
        ResponseEntity<String> response = restTemplate.exchange(
                url("api/v1/{rootContainerId}/item/labels/{labelValue}?labelType={labelType}",
                        baseUrl), GET, httpRequest, String.class, rootContainerId, itemLabel.getValue(),
                itemLabel.getType());
        return getItemFromResponse(response).getItems();
    }

    private HttpHeaders newHeader() {
        HttpHeaders header = new HttpHeaders();
        header.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON);
        return header;
    }

    //TODO: swagger client jar integration
    private ItemsCreationResponse getItemCreateResponse(ResponseEntity<String> response) {
        ItemsCreationResponse itemResponse = null;
        try {
            switch (response.getStatusCode()) {
                case CREATED:
                    itemResponse = objectMapper.readValue(response.getBody(), ItemsCreationResponse.class);
                    break;
                case BAD_REQUEST:
                    ErrorMessage errorMessage = objectMapper.readValue(response.getBody(), ErrorMessage.class);
                    //To be changed once item service starts sending error codes
                    throw new ImsBadRequestException(errorMessage.getMessage());
                default:
                    ErrorMessage defaultErrorMessage = objectMapper.readValue(response.getBody(), ErrorMessage.class);
                    throw new ImsClientException(defaultErrorMessage.getMessage(), defaultErrorMessage.getErrorCode());
            }
        } catch (IOException e) {
            throw new ImsClientException(response.getBody() +  e.getMessage() , e);
        }
        return itemResponse;
    }

    //TODO: swagger client jar integration
    private GetItemResponse getItemFromResponse(ResponseEntity<String> response) {
        GetItemResponse itemResponse = null;
        try {
            switch (response.getStatusCode()) {
                case OK:
                    itemResponse = objectMapper.readValue(response.getBody(), GetItemResponse.class);
                    break;
                case BAD_REQUEST:
                    ErrorMessage errorMessage = objectMapper.readValue(response.getBody(), ErrorMessage.class);
                    throw new ImsBadRequestException(errorMessage.getMessage(), errorMessage.getErrorCode());
                default:
                    ErrorMessage defaultErrorMessage = objectMapper.readValue(response.getBody(), ErrorMessage.class);
                    throw new ImsClientException(defaultErrorMessage.getMessage(), defaultErrorMessage.getErrorCode());
            }
        } catch (IOException e) {
            LOGGER.error("Response error: {} ", e.getMessage());
            throw new ImsClientException(response.getBody(), e);
        }
        return itemResponse;
    }

    private ItemCreationRequestAttributes setRequestAttributes(Container createItem,
                                                               ItemCreationRequestAttributes requestAttributes,
                                                               String status, String processOwner) {
        requestAttributes.setStatuses(Lists.newArrayList(new ItemStatus(processOwner, status)));
        requestAttributes.setLabels(Lists.newArrayList(createItem.getLabel()));
        setItemAttributes(createItem, requestAttributes.getAttributes());
        requestAttributes.setQuantity(AttributeDefaultValues.QUANITY.getValue());
        return requestAttributes;
    }

    private  void setItemAttributes(Container createItem, List<ItemAttribute> attributes) {
        attributes.add(new ItemAttribute(UNITIZATION_APP_ID.name(), createItem.getAppId()));
        attributes.add(new ItemAttribute(UNITIZATION_IS_TRANSIENT.name(), createItem.isTransient()));
        attributes.add(new ItemAttribute(UNITIZATION_CURRENT_NO_OF_ITEMS.name(),
                AttributeDefaultValues.CURRENT_NO_OF_ITEMS.getValue()));
    }

    public List<Item> getItemsByLabelTypeAndLabelValues(String rootContainerId, String labelType,
                                                        List<String> labelValues) {

        String labelValuesString = String.join(",", labelValues);
        HttpEntity<?> httpRequest = new HttpEntity<>(newHeader());
        ResponseEntity<String> response = restTemplate.exchange(
                url("api/v1/{rootContainerId}/item/labels/{labelValue}?labelType={labelType}",
                        baseUrl), GET, httpRequest, String.class, rootContainerId, labelValuesString,
                labelType);
        return getItemFromResponse(response).getItems();
    }

    public List<Item> getItemsByIds(String rootContainerId, List<String> ids) {

        String idString = String.join(",", ids);
        HttpEntity<?> httpRequest = new HttpEntity<>(newHeader());
        ResponseEntity<String> response = restTemplate.exchange(
                url("api/v1/{rootContainerId}/item/{itemIds}", baseUrl),
                HttpMethod.GET, httpRequest, String.class, rootContainerId, idString);
        return getItemFromResponse(response).getItems();
    }

    public void moveItems(AddRequest moveRequest,
                          List<ItemAddRequest> itemsToMove) {

        HttpEntity<?> httpRequest = new HttpEntity<>(mapper.unitizationMoveRequestToItemMoveRequest(
                moveRequest, itemsToMove), newHeader());
        ResponseEntity<String> response = restTemplate.exchange(
                url("/api/v1/{rootContainerId}/item", baseUrl), HttpMethod.PUT, httpRequest, String.class,
                moveRequest.getFacilityId());
        validateItemResponse(response);
    }

    public void updateItem(UpdateRequest updateRequest,
                           List<ItemToUpdate> itemsToUpdate) {

        HttpEntity<?> httpRequest = new HttpEntity<>(mapper.unitizationUpdateRequestToItemUpdateRequest(
                updateRequest, itemsToUpdate), newHeader());
        ResponseEntity<String> response = restTemplate.exchange(
                url("/api/v1/{rootContainerId}/item", baseUrl), HttpMethod.PUT, httpRequest, String.class,
                updateRequest.getFacilityId());
        validateItemResponse(response);
    }

    private void validateItemResponse(ResponseEntity<String> response) {

        try {
            switch (response.getStatusCode()) {
                case OK:
                    break;
                case BAD_REQUEST:
                    ErrorMessage errorMessage = objectMapper.readValue(response.getBody(), ErrorMessage.class);
                    throw new ImsBadRequestException(errorMessage.getMessage(), errorMessage.getErrorCode());
                default:
                    ErrorMessage defaultErrorMessage = objectMapper.readValue(response.getBody(), ErrorMessage.class);
                    throw new ImsClientException(defaultErrorMessage.getMessage(), defaultErrorMessage.getErrorCode());
            }
        } catch (IOException e) {
            LOGGER.error("Response error: {} ", e.getMessage());
            throw new ImsClientException(response.getBody(), e);
        }
    }

    public List<ItemAddRequest> prepareItemsToMove(List<Item> items, Item container,
                                                   Map<String, Object> modifiedAttributes,
                                                   Map<String, Object> deletedAttributes,
                                                   Map<String, com.ekart.facp.unitization
                                                           .service.dtos.clients.ims.response.ItemStatus>
                                                           modifiedStatuses) {

        Map<String, List<ItemAttribute>> itemAttributes = createAttributes(modifiedAttributes, deletedAttributes);
        return items.stream().map(elt -> new ItemAddRequest(elt.getId(), elt.getVersion(),
                container.getId(), container.getVersion(), itemAttributes,
                createModifiedStatuses(ImmutableMap.of(modifiedStatuses.get(elt.getId()).getOwner(),
                        modifiedStatuses.get(elt.getId()).getValue())))).collect(Collectors.toList());
    }

    public ItemToUpdate prepareItemToUpdate(Item item , Map<String, Object> attributes,
                                            Map<String, String> labelsToBeAdded, Map<String, String> statuses) {

        //update item in ims
        return new ItemToUpdate(item.getId(), item.getVersion(), createAttributes(attributes, ImmutableMap.of()),
                createModifiedLabels(labelsToBeAdded), createModifiedStatuses(statuses));
    }

    public ItemAddRequest prepareContainerToUpdate(Item container, Map<String, Object> modifiedAttributes,
                                                   Map<String, Object> deletedAttributes,
                                                   Map<String, com.ekart.facp.unitization.service
                                                           .dtos.clients.ims.response.ItemStatus>
                                                           modifiedStatuses) {

        Map<String, String> modifiedStatus = Maps.newHashMap();
        if (modifiedStatuses.containsKey(container.getId())) {
            modifiedStatus = ImmutableMap.of(modifiedStatuses.get(container.getId()).getOwner(),
                    modifiedStatuses.get(container.getId()).getValue());
        }
        return new ItemAddRequest(container.getId(), container.getVersion(),
                createAttributes(modifiedAttributes, deletedAttributes), createModifiedStatuses(modifiedStatus));
    }

    private Map<String, List<ItemAttribute>> createAttributes(Map<String, Object> modifiedAttributes,
                                                              Map<String, Object> deletedAttributes) {

        Map<String, List<ItemAttribute>> attributes = new HashMap<>();

        if (!modifiedAttributes.isEmpty()) {
            List<ItemAttribute> attr = Lists.newArrayListWithExpectedSize(modifiedAttributes.size());
            modifiedAttributes.forEach((k, v) -> attr.add(new ItemAttribute(k, v)));
            attributes.put(MODIFIED_VALUE, attr);
        }

        if (!deletedAttributes.isEmpty()) {
            List<ItemAttribute> attr = Lists.newArrayListWithExpectedSize(modifiedAttributes.size());
            deletedAttributes.forEach((k, v) -> attr.add(new ItemAttribute(k, v)));
            attributes.put(DELETED_VALUE, attr);
        }

        return attributes;
    }

    private Map<String, List<ItemStatus>> createModifiedStatuses(Map<String, String> modifiedStatuses) {

        Map<String, List<ItemStatus>> statuses = new HashMap<>();
        if (!modifiedStatuses.isEmpty()) {
            List<ItemStatus> itemStatuses = Lists.newArrayListWithExpectedSize(modifiedStatuses.size());
            modifiedStatuses.forEach((k, v) -> itemStatuses.add(new ItemStatus(k, v)));
            statuses.put(MODIFIED_VALUE, itemStatuses);
        }
        return statuses;
    }

    private Map<String, List<ItemLabel>> createModifiedLabels(Map<String, String> modifiedLabels) {

        Map<String, List<ItemLabel>> labels = new HashMap<>();
        if (!modifiedLabels.isEmpty()) {
            List<ItemLabel> itemLabels = Lists.newArrayListWithExpectedSize(modifiedLabels.size());
            modifiedLabels.forEach((k, v) -> itemLabels.add(new ItemLabel(k, v)));
            labels.put(MODIFIED_VALUE, itemLabels);
        }
        return labels;
    }
}






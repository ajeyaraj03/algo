package com.ekart.facp.unitization.service.entities;

import java.util.Map;

/**
 * Created by ajeya.hb on 27/06/16.
 */
public class SpecificationUpdationRequest {

    private String updatedBy;
    private Boolean reusable;
    private Boolean active;
    private String id;
    private Map<String, String> attributes;

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Boolean getReusable() {
        return reusable;
    }

    public void setReusable(Boolean reusable) {
        this.reusable = reusable;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Map<String, String> getAttributes() {
        return attributes;
    }

    public void setAttributes(Map<String, String> attributes) {
        this.attributes = attributes;
    }

    @Override
    public String toString() {
        return "SpecificationUpdationRequest{" + "updatedBy='" + updatedBy + '\'' + ", reusable=" + reusable
                + ", active=" + active + ", id='" + id + '\'' + ", attributes=" + attributes + '}';
    }
}

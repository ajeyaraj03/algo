package com.ekart.facp.unitization.service.utility;

import com.ekart.facp.unitization.common.enums.ContainerType;
import com.ekart.facp.unitization.service.UnitizationService;
import com.ekart.facp.unitization.service.DispensibleContainerService;
import com.ekart.facp.unitization.service.ReusableContainerService;

import static com.ekart.facp.unitization.common.enums.ContainerType.REUSABLE;
import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Created by anurag.gupta on 01/06/16.
 */
public class ContainerFactory {

    private final ReusableContainerService reusableContainerService;
    private final DispensibleContainerService dispensibleContainerService;

    public ContainerFactory(ReusableContainerService reusableContainerService,
                            DispensibleContainerService dispensibleContainerService) {
        this.reusableContainerService = checkNotNull(reusableContainerService);
        this.dispensibleContainerService = checkNotNull(dispensibleContainerService);
    }

    public UnitizationService getService(ContainerType containerType) {
        return  containerType == REUSABLE ? reusableContainerService : dispensibleContainerService;
    }
}

package com.ekart.facp.unitization.apis.dtos;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * Created by anurag.gupta on 15/06/16.
 */

@ApiModel
public class ContainerCreateRequest {

    @ApiModelProperty(name = "idempotence_key", value = "The idempotence key for this operation. The idempotence key "
            + "is enforced at the API level")
    @JsonProperty(value = "idempotence_key")
    @NotNull(message = "{container.idempotenceKey.notnull}")
    private String idempotenceKey;

    @ApiModelProperty(name = "container_id", value = "The parent container id for the container being created ")
    @JsonProperty(value = "container_id")
    @NotNull(message = "{container.containerId.notnull}")
    private String containerId;

    @ApiModelProperty(name = "created_by", value = "The entity which requested this operation. This can either be "
            + "an actual person or a service or a machine")
    @JsonProperty(value = "created_by")
    @NotNull(message = "{container.createdby.notnull}")
    private String createdBy;

    @ApiModelProperty(name = "type", value = "The type of entity")
    @JsonProperty(value = "type", required = true)
    @NotNull(message = "{container.type.notnull}")
    private String type;

    @ApiModelProperty(name = "created_by_document_id", value = "The document id against which the container is created")
    @JsonProperty(value = "created_by_document_id")
    @NotNull(message = "{container.createdByDocumentId.notnull}")
    private String createdByDocumentId;

    @ApiModelProperty(name = "created_by_document_type", value = "The document type against which the container is "
            + "created")
    @JsonProperty(value = "created_by_document_type")
    @NotNull(message = "{container.createdByDocumentType.notnull}")
    private String createdByDocumentType;

    @ApiModelProperty(name = "created_by_entity_id", value = "The entity id against which the container is created")
    @JsonProperty(value = "created_by_entity_id")
    @NotNull(message = "{container.createdByEntityId.notnull}")
    private String createdByEntityId;

    @ApiModelProperty(name = "created_by_entity_type", value = "The entity type against which the container is created")
    @JsonProperty(value = "created_by_entity_type")
    @NotNull(message = "{container.createdByEntityType.notnull}")
    private String createdByEntityType;

    @ApiModelProperty(name = "state_machine_id", value = "The identifier of the flow for which "
            + "the container is created")
    @JsonProperty(value = "state_machine_id")
    @NotNull(message = "{container.stateMachineId.notnull}")
    private String stateMachineId;

    @ApiModelProperty(name = "flow_context", value = "The context of the flow for which "
            + "the container is created")
    @JsonProperty(value = "flow_context")
    @NotNull(message = "{container.flowContext.notnull}")
    private String flowContext;

    @ApiModelProperty(name = "uom", value = "Units of measurement, specify none if there isnot any uom")
    @JsonProperty(value = "uom")
    @NotNull(message = "{container.uom.notnull}")
    private String uom;

    @ApiModelProperty(name = "app_id", value = "The machine which requested this operation")
    @JsonProperty(value = "app_id")
    @NotNull(message = "{container.appId.notnull}")
    private String appId;

    @ApiModelProperty(name = "facility_id", value = "The facility in which the container is created")
    @JsonProperty(value = "facility_id")
    @NotNull(message = "{container.facilityId.notnull}")
    private String facilityId;

    @ApiModelProperty(name = "attributes", value = "The attributes of the container")
    @JsonProperty(value = "attributes")
    @NotEmpty(message = "{container.attributes.notempty}")
    private List<Attribute> attributes;


    @ApiModelProperty(name = "label", value = "The label identifier for the container")
    @JsonProperty(value = "label")
    @NotNull(message = "{container.label.notnull}")
    private Label label;

    @ApiModelProperty(name = "is_transient", value = "The isTransient flag to check if any operation is "
            + "allowed on items")
    @JsonProperty(value = "is_transient")
    private boolean isTransient;

    public String getIdempotenceKey() {
        return idempotenceKey;
    }

    public void setIdempotenceKey(String idempotenceKey) {
        this.idempotenceKey = idempotenceKey;
    }

    public String getContainerId() {
        return containerId;
    }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCreatedByDocumentId() {
        return createdByDocumentId;
    }

    public void setCreatedByDocumentId(String createdByDocumentId) {
        this.createdByDocumentId = createdByDocumentId;
    }

    public String getCreatedByDocumentType() {
        return createdByDocumentType;
    }

    public void setCreatedByDocumentType(String createdByDocumentType) {
        this.createdByDocumentType = createdByDocumentType;
    }

    public String getCreatedByEntityId() {
        return createdByEntityId;
    }

    public void setCreatedByEntityId(String createdByEntityId) {
        this.createdByEntityId = createdByEntityId;
    }

    public String getCreatedByEntityType() {
        return createdByEntityType;
    }

    public void setCreatedByEntityType(String createdByEntityType) {
        this.createdByEntityType = createdByEntityType;
    }

    public String getStateMachineId() {
        return stateMachineId;
    }

    public void setStateMachineId(String stateMachineId) {
        this.stateMachineId = stateMachineId;
    }

    public String getUom() {
        return uom;
    }

    public void setUom(String uom) {
        this.uom = uom;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getFacilityId() {
        return facilityId;
    }

    public void setFacilityId(String facilityId) {
        this.facilityId = facilityId;
    }

    public List<Attribute> getAttributes() {
        return attributes;
    }

    public void setAttributes(List<Attribute> attributes) {
        this.attributes = attributes;
    }

    public Label getLabel() {
        return label;
    }

    public void setLabel(Label label) {
        this.label = label;
    }

    public boolean getIsTransient() {
        return isTransient;
    }

    public void setIsTransient(boolean isTransient) {
        this.isTransient = isTransient;
    }

    public String getFlowContext() {
        return flowContext;
    }

    public void setFlowContext(String flowContext) {
        this.flowContext = flowContext;
    }

    @Override
    public String toString() {
        return "ContainerCreateRequest{"
                + "idempotenceKey='" + idempotenceKey + '\''
                + ", containerId='" + containerId + '\''
                + ", createdBy='" + createdBy + '\''
                + ", type='" + type + '\''
                + ", createdByDocumentId='" + createdByDocumentId + '\''
                + ", createdByDocumentType='" + createdByDocumentType + '\''
                + ", createdByEntityId='" + createdByEntityId + '\''
                + ", createdByEntityType='" + createdByEntityType + '\''
                + ", stateMachineId='" + stateMachineId + '\''
                + ", uom='" + uom + '\''
                + ", appId='" + appId + '\''
                + ", facilityId='" + facilityId + '\''
                + ", attributes=" + attributes
                + ", labels=" + label
                + ", isTransient=" + isTransient
                + ", flowContext=" + flowContext
                + '}';
    }
}

package com.ekart.facp.unitization.apis.controller;

import com.codahale.metrics.annotation.ExceptionMetered;
import com.codahale.metrics.annotation.Timed;
import com.ekart.facp.unitization.apis.dtos.*;
import com.ekart.facp.unitization.apis.mapper.ApiDtoToServiceEntityMapper;
import com.ekart.facp.unitization.service.SpecificationService;
import com.ekart.facp.unitization.service.exceptions.SpecificationFoundException;
import com.ekart.facp.unitization.service.utility.TenantContext;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.eclipse.jetty.http.HttpStatus;
import org.hibernate.validator.constraints.NotEmpty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.ThreadSafe;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.ws.rs.core.MediaType;

import static com.ekart.facp.unitization.apis.constants.ApiConstants.TENANT_KEY;
import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Created by ajeya.hb on 23/03/16.
 */
@ThreadSafe
@RequestMapping("/api/v1/specifications")
@ParametersAreNonnullByDefault
@Api(protocols = "http", tags = "Unit Load Definition Management")
public class SpecificationController extends BaseController {
    private static final Logger LOGGER = LoggerFactory.getLogger(SpecificationController.class);
    private final SpecificationService specificationService;
    private final ApiDtoToServiceEntityMapper mapper;

    public SpecificationController(SpecificationService specificationService, ApiDtoToServiceEntityMapper mapper) {
        this.specificationService = checkNotNull(specificationService);
        this.mapper = checkNotNull(mapper);
    }

    @ApiOperation(nickname = "create_specification", value = "Creates new Specification")
    @ApiResponses({
            @ApiResponse(code = HttpStatus.CREATED_201, message = "The Specification created successfully",
                    response = SpecificationCreationResponse.class),
            @ApiResponse(code = HttpStatus.BAD_REQUEST_400,
                    message = "Unable  to create specification, specification may already exists (or) "
                            + "Error due business validations. ",
                    response = ErrorMessage.class),
            @ApiResponse(code = HttpStatus.INTERNAL_SERVER_ERROR_500,
                    message = "Internal server error. An unexpected error occurred",
                    response = ErrorMessage.class)})
    @Timed
    @ExceptionMetered
    @RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON,
            consumes = MediaType.APPLICATION_JSON)
    public ResponseEntity<SpecificationCreationResponse> createSpecification(@RequestBody @Valid @NotNull
                                                                             SpecificationCreationRequest
                                                                                     specificationRequest,
                                                                             @RequestHeader(value = TENANT_KEY,
                                                                                     required = true) @Valid
                                                                             @NotEmpty String tenant) {
        String specificationId = null;
        try {
            specificationId = specificationService.create(tenantContext(tenant),
                    mapper.specificationCreationRequestToSpecificationCreationRequestEntity(specificationRequest));
        } catch (SpecificationFoundException rex) {
            LOGGER.info("Resource Exists with specification id: {}", rex.getSpecificationId(), rex);
            specificationId = rex.getSpecificationId();
        }
        return created(new SpecificationCreationResponse(specificationId));
    }

    @ApiOperation(nickname = "update_specification", value = "Update Specification")
    @ApiResponses({
            @ApiResponse(code = HttpStatus.CREATED_201, message = "The Specification updated successfully",
                    response = SuccessResponse.class),
            @ApiResponse(code = HttpStatus.BAD_REQUEST_400,
                    message = "Unable  to update specification, specification may already exists (or) "
                            + "Error due to business validations. ",
                    response = ErrorMessage.class),
            @ApiResponse(code = HttpStatus.INTERNAL_SERVER_ERROR_500,
                    message = "Internal server error. An unexpected error occurred",
                    response = ErrorMessage.class)})
    @Timed
    @ExceptionMetered
    @RequestMapping(method = RequestMethod.PATCH, path = "/{specificationId}", produces = MediaType.APPLICATION_JSON,
            consumes = MediaType.APPLICATION_JSON)
    public ResponseEntity<SuccessResponse> updateSpecification(
            @PathVariable("specificationId") @Valid @NotNull String specificationId, @RequestHeader(value = TENANT_KEY,
            required = true) @Valid @NotEmpty String tenant,
            @RequestBody @Valid SpecificationUpdateRequest specificationRequest) {

        specificationService.update(tenantContext(tenant), mapper
                .specificationUpdateRequestToSpecificationUpdationEntity(specificationId,
                        specificationRequest));
        return ok(new SuccessResponse());

    }

    @ApiOperation(nickname = "remove_specification", value = "Remove Specification")
    @ApiResponses({
            @ApiResponse(code = HttpStatus.CREATED_201, message = "The Specification removed successfully",
                    response = SuccessResponse.class),
            @ApiResponse(code = HttpStatus.BAD_REQUEST_400,
                    message = "Unable  to remove specification, specification maynot exists (or) "
                            + "Error due to business validations. ",
                    response = ErrorMessage.class),
            @ApiResponse(code = HttpStatus.INTERNAL_SERVER_ERROR_500,
                    message = "Internal server error. An unexpected error occurred",
                    response = ErrorMessage.class)})
    @Timed
    @ExceptionMetered
    @RequestMapping(method = RequestMethod.DELETE, path = "/{specificationId}", produces = MediaType.APPLICATION_JSON)
    public ResponseEntity<SuccessResponse> removeSpecification(
            @PathVariable("specificationId") @Valid @NotNull String specificationId, @RequestHeader(value = TENANT_KEY,
            required = true) @Valid @NotEmpty String tenant) {

        specificationService.remove(tenantContext(tenant), specificationId);
        return ok(new SuccessResponse());

    }

    @ApiOperation(nickname = "get_specification", value = "Retrieve Specification")
    @ApiResponses({
            @ApiResponse(code = HttpStatus.OK_200, message = "The Specification retrieve successfully",
                    response = Specification.class),
            @ApiResponse(code = HttpStatus.BAD_REQUEST_400,
                    message = "Unable  retrieve specification, "
                            + "Error due to business validations. ",
                    response = ErrorMessage.class),
            @ApiResponse(code = HttpStatus.INTERNAL_SERVER_ERROR_500,
                    message = "Internal server error. An unexpected error occurred",
                    response = ErrorMessage.class)})
    @Timed
    @ExceptionMetered
    @RequestMapping(method = RequestMethod.GET, path = "/{specificationId}", produces = MediaType.APPLICATION_JSON)
    public ResponseEntity<?> getById(@PathVariable("specificationId") String specificationId,
                                     @RequestHeader(value = TENANT_KEY,
                                             required = true) @Valid @NotEmpty String tenant) {

        return ok(mapper.specificationEntityToSpecificationResponse(specificationService.get(tenantContext(tenant),
                specificationId)));

    }

    private static TenantContext tenantContext(String tenantName) {
        TenantContext tenantContext = new TenantContext(tenantName);
        return tenantContext;
    }

}

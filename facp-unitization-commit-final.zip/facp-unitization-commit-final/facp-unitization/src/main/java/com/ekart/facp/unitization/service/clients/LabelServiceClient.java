package com.ekart.facp.unitization.service.clients;

import com.codahale.metrics.annotation.ExceptionMetered;
import com.codahale.metrics.annotation.Timed;
import com.ekart.facp.unitization.apis.dtos.ErrorMessage;
import com.ekart.facp.unitization.apis.mapper.ServiceEntityToClientRequestMapper;
import com.ekart.facp.unitization.common.ErrorCode;
import com.ekart.facp.unitization.service.dtos.ItemLabel;
import com.ekart.facp.unitization.service.dtos.clients.label_service.request.LabelMapping;
import com.ekart.facp.unitization.service.dtos.clients.label_service.request.LabelMappingCreateRequest;
import com.ekart.facp.unitization.service.exceptions.clients.label_service.LabelAlreadyExists;
import com.ekart.facp.unitization.service.exceptions.clients.label_service.LabelServiceBadRequestException;
import com.ekart.facp.unitization.service.exceptions.clients.label_service.LabelServiceClientException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.List;

import static com.ekart.facp.unitization.apis.util.ClientUtil.url;
import static com.ekart.facp.unitization.common.Constants.CLIENT_NAME;
import static jersey.repackaged.com.google.common.base.Preconditions.checkNotNull;

/**
 * Created by anurag.gupta on 14/07/16.
 */

@Timed
@ExceptionMetered
public class LabelServiceClient {

    private final String baseUrl;
    private final RestTemplate restTemplate;
    private final ServiceEntityToClientRequestMapper mapper;
    private final ObjectMapper objectMapper;
    private static final Logger LOGGER = LoggerFactory.getLogger(ImsClient.class);
    public static final String TENANT_KEY = "X-Ekart-Client";


    public LabelServiceClient(RestTemplate restTemplate, String baseUrl, ServiceEntityToClientRequestMapper mapper,
                     ObjectMapper objectMapper) {
        this.restTemplate = checkNotNull(restTemplate);
        this.baseUrl = checkNotNull(baseUrl);
        this.mapper = checkNotNull(mapper);
        this.objectMapper = checkNotNull(objectMapper);
    }

    public void createLabelMapping(String tenant, String facilityId, String type, String createdBy,
                                   String idempotenceKey, List<ItemLabel> labels) {
        List<LabelMapping> labelMappings = Lists.newArrayListWithCapacity(labels.size());
        labels.stream().forEach(label -> labelMappings.add(new LabelMapping(idempotenceKey, label.getType(),
                label.getValue())));
        LabelMappingCreateRequest request = new LabelMappingCreateRequest(createdBy, labelMappings);
        HttpEntity<LabelMappingCreateRequest> httpRequest = new HttpEntity<>(request, newHeader(CLIENT_NAME));
        ResponseEntity<String> response = restTemplate.exchange(
                url("/api/v1/{facility_id}/mapping/{entity_type}", baseUrl),
                HttpMethod.POST, httpRequest, String.class, facilityId, type);
        checkLabelService(response);
    }

    private HttpHeaders newHeader(String client) {
        HttpHeaders header = new HttpHeaders();
        header.add(HttpHeaders.CONTENT_TYPE, javax.ws.rs.core.MediaType.APPLICATION_JSON);
        header.add(TENANT_KEY, client);
        return header;
    }

    private void checkLabelService(ResponseEntity<String> response) {
        try {
            switch (response.getStatusCode()) {
                case CREATED:
                    break;
                case BAD_REQUEST:
                    ErrorMessage errorMessage = objectMapper.readValue(response.getBody(), ErrorMessage.class);
                    switch (ErrorCode.valueOf(errorMessage.getErrorCode())) {
                        case LABEL_ALREADY_EXISTS:
                            throw new LabelAlreadyExists(errorMessage.getMessage());
                        default:
                            throw new LabelServiceBadRequestException(errorMessage.getMessage(),
                                    errorMessage.getErrorCode());
                    }
                default:
                    ErrorMessage defaultErrorMessage = objectMapper.readValue(response.getBody(), ErrorMessage.class);
                    throw new LabelServiceClientException(defaultErrorMessage.getMessage(),
                            defaultErrorMessage.getErrorCode());
            }
        } catch (IOException e) {
            LOGGER.error("Response error: {} ", e.getMessage());
            throw new LabelServiceClientException(response.getBody(), e);
        }
    }
}

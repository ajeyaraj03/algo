package com.ekart.facp.unitization.service.exceptions.clients.ims;

import com.ekart.facp.unitization.service.exceptions.clients.ClientException;

import static com.ekart.facp.unitization.common.ErrorCode.IMS_CLIENT_EXCEPTION;

/**
 * Created by anurag.gupta on 07/07/16.
 */
public class ImsClientException extends ClientException {

    private static final long serialVersionUID = -8719315920559315309L;

    public ImsClientException(String message, String errorCode) {
        super(message, errorCode);
    }
    public ImsClientException(String message, Throwable cause) {
        super(message, IMS_CLIENT_EXCEPTION.name(), cause);
    }
}

package com.ekart.facp.unitization.service.validators;

import java.math.BigDecimal;

/**
 * Created by avinash.r on 03/08/16.
 */
public class SpecificationRulesValidationAttributes {

    private BigDecimal weight;
    private long noOfItems;

    public BigDecimal getWeight() {
        return weight;
    }

    public void setWeight(BigDecimal weight) {
        this.weight = weight;
    }

    public long getNoOfItems() {
        return noOfItems;
    }

    public void setNoOfItems(long noOfItems) {
        this.noOfItems = noOfItems;
    }

    @Override
    public String toString() {
        return "SpecificationRulesValidationAttributes{" + "weight=" + weight + ", noOfItems=" + noOfItems + '}';
    }
}

package com.ekart.facp.unitization.service.exceptions.clients.ims;

import com.ekart.facp.unitization.service.exceptions.clients.ClientException;

import static com.ekart.facp.unitization.common.ErrorCode.IMS_BAD_REQUEST_EXCEPTION;

/**
 * Created by anurag.gupta on 07/07/16.
 */
public class ImsBadRequestException extends ClientException {

    private static final long serialVersionUID = -8719315920559315309L;

    public ImsBadRequestException(String message) {
        super(message, IMS_BAD_REQUEST_EXCEPTION.name());
    }

    public ImsBadRequestException(String message, String errorCode) {
        super(message, errorCode);
    }
}

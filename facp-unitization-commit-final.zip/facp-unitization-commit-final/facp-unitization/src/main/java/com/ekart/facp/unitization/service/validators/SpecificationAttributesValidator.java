package com.ekart.facp.unitization.service.validators;

import com.ekart.facp.unitization.service.validators.NumberOfItemsAggregator;
import com.ekart.facp.unitization.service.validators.WeightAggregator;

/**
 * Created by avinash.r on 03/08/16.
 */
public class SpecificationAttributesValidator {

    private WeightAggregator weightAggregator;
    private NumberOfItemsAggregator itemsAggregator;

    public SpecificationAttributesValidator(WeightAggregator weightAggregator,
                                            NumberOfItemsAggregator itemsAggregator) {
        this.weightAggregator = weightAggregator;
        this.itemsAggregator = itemsAggregator;
    }

    public WeightAggregator getWeightAggregator() {
        return weightAggregator;
    }

    public NumberOfItemsAggregator getItemsAggregator() {
        return itemsAggregator;
    }
}

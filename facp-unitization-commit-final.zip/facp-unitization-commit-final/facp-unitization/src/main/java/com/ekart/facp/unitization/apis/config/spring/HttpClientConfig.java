package com.ekart.facp.unitization.apis.config.spring;

import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

/**
 * Created by anurag.gupta on 09/06/16.
 */

@Configuration
public class HttpClientConfig {

    @Value("${httpClient.maxTotalConnections}")
    private int maxTotalConnections;

    @Value("${httpClient.maxConnectionsPerRoute}")
    private int maxConnectionsPerRoute;

    @Value("${httpClient.connectTimeout}")
    private int connectTimeout;

    @Value("${httpClient.connectRequestTimeout}")
    private int connectRequestTimeout;

    @Value("${httpClient.socketTimeout}")
    private int socketTimeout;

    @Bean
    public HttpClient httpClient() {

        PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager();
        connectionManager.setMaxTotal(maxTotalConnections);
        connectionManager.setDefaultMaxPerRoute(maxConnectionsPerRoute);

        RequestConfig config = RequestConfig.custom().setConnectTimeout(connectTimeout)
                .setConnectionRequestTimeout(connectRequestTimeout).setSocketTimeout(socketTimeout).build();

        return HttpClients.custom().setConnectionManager(connectionManager).setDefaultRequestConfig(config).build();

    }

    @Bean
    public RestTemplate restTemplate() {
        RestTemplate restTemplate = new RestTemplate(new HttpComponentsClientHttpRequestFactory(httpClient()));
        restTemplate.setErrorHandler(new CustomResponseErrorHandler());
        return restTemplate;
    }
}

package com.ekart.facp.unitization.service.dtos.clients.fsm;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.concurrent.Immutable;

/**
 * Created by anurag.gupta on 17/06/16.
 */
@Immutable
public final class FsmInitialStateResponse {

    private final String stateName;
    private final long version;

    @JsonCreator
    public FsmInitialStateResponse(@JsonProperty("state_name") String stateName,
                                   @JsonProperty("version") long version) {
        this.stateName = stateName;
        this.version = version;
    }

    public String getInitialState() {
        return stateName;
    }

    public long getVersion() {
        return version;
    }

    @Override
    public String toString() {
        return "FsmInitialStateResponse{" + "state_name='" + stateName + '\'' + ", version=" + version + '}';
    }
}

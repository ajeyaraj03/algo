package com.ekart.facp.unitization.service.exceptions;
import static com.ekart.facp.unitization.common.ErrorCode.SPECIFICATION_NOT_FOUND;
/**
 * Created by anuj.chaudhary on 21/04/16.
 */
public class SpecificationNotFoundException extends BaseException {

    public SpecificationNotFoundException(String message) {
        super(message, SPECIFICATION_NOT_FOUND.name());
    }
}


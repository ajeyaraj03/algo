package com.ekart.facp.unitization.service.mapper;

import com.ekart.facp.unitization.service.entities.Specification;
import com.ekart.facp.unitization.service.entities.SpecificationCreationRequest;
import org.mapstruct.Mapper;

/**
 * Created by ajeya.hb on 24/03/16.
 */
@Mapper(componentModel = "spring")
public interface ServiceEntityToDALModelMapper {

    com.ekart.facp.unitization.dal.models.Specification specificationCreateEntityToSpecificationModel(
            String id, String tenant, SpecificationCreationRequest specification, String updatedBy,
            long createdAtEpoch, long updatedAtEpoch);

    Specification specificationModelToSpecification(com.ekart.facp.unitization.dal.models.Specification
                                                            specification);

}

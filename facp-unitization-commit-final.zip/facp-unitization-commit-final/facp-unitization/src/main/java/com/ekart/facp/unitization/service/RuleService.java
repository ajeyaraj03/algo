package com.ekart.facp.unitization.service;

import java.math.BigDecimal;
import java.util.Map;

/**
 * Created by avinash.r on 13/07/16.
 */
public interface RuleService {

    boolean maxWeightRule(Map<String, String> attributes, BigDecimal totalWeight);

    boolean maxNoOfItemsRule(Map<String, String> attributes, long noOfItems);
}
